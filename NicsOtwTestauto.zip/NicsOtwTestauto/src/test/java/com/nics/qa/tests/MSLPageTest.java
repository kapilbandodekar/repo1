package com.nics.qa.tests;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.nics.qa.base.TestBase;
import com.nics.qa.pages.MSLPage;
import com.nics.qa.pages.NicsHomePage;
import com.nics.qa.pages.NicsLoginPage;
import com.nics.qa.pages.OtwdashboardPage;
import com.nics.qa.util.ExcelUtils;
import com.nics.qa.util.TestUtil;

public class MSLPageTest extends TestBase {
	
	NicsLoginPage NicsLoginPage;
	NicsHomePage nicsHomePage;
	TestUtil testUtil;
	MSLPage MSLPage;
	OtwdashboardPage OtwdashboardPage;
	
	 
	
	public MSLPageTest(){
		super();
	}
	
	@BeforeMethod(alwaysRun=true)
	public void setUp() throws InterruptedException{
		initialization();
		testUtil = new TestUtil();
		MSLPage = new MSLPage();
		NicsLoginPage = new NicsLoginPage();
		nicsHomePage = new NicsHomePage();
		//NicsLoginPage.login(prop.getProperty("username")); 
		
		//nicsCreateOtwPage=nicsHomePage.clickOnCreateOTWBtn();
	}
	
	@Test(priority = 1, groups= {"powai"}, dataProvider="CreateMSL", dataProviderClass = ExcelUtils.class)
	public void validateCreateMSLPage(String nicsID, String dsponsor, String dManager, String delegate, String infDisclosed, String  antDate, String docFilePath, String docName ) throws InterruptedException{
		
		NicsLoginPage.login(prop.getProperty("username")); 
		MSLPage.createNewMSL(nicsID,dsponsor,dManager,delegate,infDisclosed,antDate,docFilePath,docName);
		Thread.sleep(6000);
    }
	
	@Test(priority = 2, groups= {"Aej"}, dataProvider="CreateAeJMSL", dataProviderClass = ExcelUtils.class)
	public void validateCreateMSLPageAej(String nicsID, String dsponsor, String dManager, String delegate, String infDisclosed, String  antDate, String docFilePath, String docName ) throws InterruptedException{
		
		NicsLoginPage.login(prop.getProperty("AeJusername"));
		MSLPage.createNewMSL(nicsID,dsponsor,dManager,delegate,infDisclosed,antDate,docFilePath,docName);
		Thread.sleep(6000);
    }
	
	@Test(priority = 3, groups= {"Emea"}, dataProvider="CreateEmeaMSL", dataProviderClass = ExcelUtils.class)
	public void validateCreateMSLPageEmea(String nicsID, String dsponsor, String dManager, String delegate, String infDisclosed, String  antDate, String docFilePath, String docName ) throws InterruptedException{
		
		NicsLoginPage.login(prop.getProperty("emeausername")); 
		MSLPage.createNewMSL(nicsID,dsponsor,dManager,delegate,infDisclosed,antDate,docFilePath,docName);
		TestUtil.implicitwait(6);
		//Thread.sleep(6000);
    }
	
	
	@AfterMethod(alwaysRun=true)
	public void tearDown(){
		driver.quit();
	}
	

}

package com.nics.qa.tests;


import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.nics.qa.base.TestBase;
import com.nics.qa.pages.NicsHomePage;
import com.nics.qa.pages.NicsLoginPage;


public class NicsLoginPageTest extends TestBase {
	NicsLoginPage NicsLoginPage;
	NicsHomePage NicsHomepage;
	
	public NicsLoginPageTest(){
		super();
	}
	
	
	@BeforeMethod
	public void setUp(){
		initialization();
		NicsLoginPage = new NicsLoginPage();
	}
	
	@Test(priority = 1)
	public void NicsLoginPageTitletest(){
		String title = NicsLoginPage.validateLogiPageTitle();
	    Assert.assertEquals(title,"NICS");
   	}
	
	@Test(priority = 2, groups= {"powai"})
	public void NicsLoginTest() throws InterruptedException{
		NicsHomepage = NicsLoginPage.login(prop.getProperty("username"));
	}
	
	@Test(groups= {"powai"})
	public void NicsCompUserLogin() throws InterruptedException{
		NicsLoginPage.complianceLogin(prop.getProperty("compUser"));
	}
	
	@Test(groups= {"powai"})
	public void NicsBusinUserLogin() throws InterruptedException{
		NicsLoginPage.businessLogin(prop.getProperty("businUser"));
	}
	
	
	
	
	
	
	@AfterMethod
	public void tearDown(){
		driver.quit();
	}
	

}

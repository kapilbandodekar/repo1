package com.nics.qa.tests;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.nics.qa.base.TestBase;
import com.nics.qa.pages.NicsCreateOtwPage;
import com.nics.qa.pages.NicsHomePage;
import com.nics.qa.pages.NicsLoginPage;
import com.nics.qa.pages.MSLDashboardPage;

public class NicsHomePageTest extends TestBase {
	NicsLoginPage NicsLoginPage;
	NicsHomePage NicsHomePage;
	NicsCreateOtwPage NicsCreateOtwPage;
	MSLDashboardPage MSLDashboardPage;
	 
	
	public NicsHomePageTest(){
		super();
	}
	
	@BeforeMethod
	public void setUp() throws InterruptedException{
		initialization();
		NicsCreateOtwPage = new NicsCreateOtwPage();
		NicsLoginPage = new NicsLoginPage();
		NicsHomePage = NicsLoginPage.login(prop.getProperty("username")); 
		 
	}
	
	@Test(priority = 1)
	public void verifyCreateOTWTest() throws InterruptedException{
		NicsCreateOtwPage = NicsHomePage.clickOnCreateOTWBtn();
	}
	
	@Test(priority = 1)
	public void verifyMSLDashboardPageTest() throws InterruptedException{
		MSLDashboardPage=NicsHomePage.clickOnMSLLogsTab();
	}

	
	@AfterMethod
	public void tearDown(){
		driver.quit();
	}
}

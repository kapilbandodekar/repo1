package com.nics.qa.tests;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.nics.qa.base.TestBase;
import com.nics.qa.pages.NicsCreateOtwPage;
import com.nics.qa.pages.NicsHomePage;
import com.nics.qa.pages.NicsLoginPage;
import com.nics.qa.pages.OtwdashboardPage;
import com.nics.qa.util.ExcelUtils;
import com.nics.qa.util.TestUtil;

public class otwAejApprovalFlowTest extends TestBase {
	
	NicsLoginPage NicsLoginPage;
	NicsHomePage nicsHomePage;
	TestUtil testUtil;
	NicsCreateOtwPage nicsCreateOtwPage;
	OtwdashboardPage OtwdashboardPage;

	//String sheetName= "compdatadetails";
	
	
	public otwAejApprovalFlowTest(){
		super();
	}
	
	@BeforeMethod(alwaysRun=true)
	public void setUp() throws InterruptedException{
		initialization();
		 
		testUtil = new TestUtil();
		nicsCreateOtwPage = new NicsCreateOtwPage();
		NicsLoginPage = new NicsLoginPage();
		nicsHomePage = new NicsHomePage();
		OtwdashboardPage = new OtwdashboardPage();
		//NicsLoginPage.complianceLogin(prop.getProperty("compUser"));
		
		//nicsCreateOtwPage=nicsHomePage.clickOnCreateOTWBtn();
		}
	
 
	@Test(priority =1, groups= "AeJ", dataProvider = "BusiAejApproval", dataProviderClass = ExcelUtils.class )
    public void validateSendTobusiness(String nicsItemId, String otwAprover1,String otwComments) throws InterruptedException{
		
		//driver.close();*/
		//NicsLoginPage = new NicsLoginPage();
		NicsLoginPage.complianceLogin(prop.getProperty("AeJcompUser")); 
		OtwdashboardPage.clickOnSendTobusiness(nicsItemId,otwAprover1, otwComments);
		Thread.sleep(5000);
		/*String Label = OtwdashboardPage.validateOtwSuccessMsg();
        System.out.print(Label);
		Assert.assertEquals(Label, "Over the Wall Sent to Business Approver successfully.");*/
	}
	
	@Test(priority =2, groups= "AeJ")
	public void validateBusinessApprove() throws InterruptedException{
		
	//	NicsLoginPage.complianceLogin(prop.getProperty("compUser")); 
	//	OtwdashboardPage.complianceAssignBusinessApprovers(nicsItemId,otwAprover1, otwComments);
		
	       NicsLoginPage.businessLogin(prop.getProperty("AeJbusinUser"));
	      // Thread.sleep(10000);
	       OtwdashboardPage.businessApproval( );
	     //  Thread.sleep(1000);
	       TestUtil.implicitwait(150);
		//System.out.print(message);
		//Assert.assertEquals(message, "The selected wall crossing request(s) will be sent for Business Approval(s).");
		//String Label = OtwdashboardPage.validateOtwSuccessMsg();
     //   System.out.print(Label);
	//	Assert.assertEquals(Label,  "Over the Wall Approved successfully.");
	}
	
	@Test(priority =3, groups= "AeJ", dataProvider = "CompAejApproval", dataProviderClass = ExcelUtils.class )
	public void validateComplianceApprove(String otwComments) throws InterruptedException{
		
	//	NicsLoginPage.complianceLogin(prop.getProperty("compUser")); 
	//	OtwdashboardPage.complianceAssignBusinessApprovers(nicsItemId,otwAprover1, otwComments);
		
	       NicsLoginPage.complianceLogin(prop.getProperty("AeJcompUser"));  	
	       OtwdashboardPage.complianceApproval(otwComments);
	       Thread.sleep(1500);
		//System.out.print(message);
		//Assert.assertEquals(message, "The selected wall crossing request(s) will be sent for Business Approval(s).");
		String Label = OtwdashboardPage.validateOtwSuccessMsg();
        System.out.print(Label);
		Assert.assertEquals(Label,  "Over the Wall Approved successfully.");
	}
	
	
	@AfterMethod(alwaysRun=true)
	public void tearDown(){
		driver.quit();
	}
	
	

}

package com.nics.qa.tests;

import java.io.IOException;
import java.util.HashMap;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.nics.qa.base.TestBase;
import com.nics.qa.pages.NicsCreateOtwPage;
import com.nics.qa.pages.NicsHomePage;
import com.nics.qa.pages.NicsLoginPage;
import com.nics.qa.pages.OtwdashboardPage;
import com.nics.qa.util.ExcelUtils;
import com.nics.qa.util.TestUtil;

public class NicsCreateOtwPageTest extends TestBase {
	
	NicsLoginPage NicsLoginPage;
	NicsHomePage nicsHomePage;
	TestUtil testUtil;
	NicsCreateOtwPage nicsCreateOtwPage;
	OtwdashboardPage OtwdashboardPage;
	
	 
	
	public NicsCreateOtwPageTest(){
		super();
	}
	
	@BeforeMethod(alwaysRun=true)
	public void setUp() throws InterruptedException{
		initialization();
		testUtil = new TestUtil();
		nicsCreateOtwPage = new NicsCreateOtwPage();
		NicsLoginPage = new NicsLoginPage();
		nicsHomePage = new NicsHomePage();
		OtwdashboardPage = new OtwdashboardPage();
		//NicsLoginPage.login(prop.getProperty("username")); 
		
		//nicsCreateOtwPage=nicsHomePage.clickOnCreateOTWBtn();
	}
	
	
	
	
	@Test(priority =1, groups= {"powai"}, dataProvider = "CreateOTW",dataProviderClass = ExcelUtils.class)
	public void validateCreateNewOtw(String dPrjCode, String prjName, String otwDealType, String dealmanager, String detailsDisclosed, String companyName, String companyType, String walcroseeName, String wallcrossReason, String comments) throws InterruptedException, IOException {
		
		//nicsHomePage.clickOnCreateOTWBtn();
		NicsLoginPage.login(prop.getProperty("username")); 
		//nicsHomePage.clickOnCreateOTWBtn();
		nicsCreateOtwPage.createNewOtwRequest(dPrjCode,prjName,otwDealType,dealmanager,detailsDisclosed,companyName,companyType,walcroseeName,wallcrossReason,comments);
		Thread.sleep(6000);
		String Label=NicsCreateOtwPage.validateSuccessMsg();
		System.out.print(Label);
		Assert.assertEquals(Label, "Over the Wall created successfully.");
		Assert.assertTrue(NicsCreateOtwPage.verifyOtwStatusLabel(),"OTW Status is missing");	
		//TestUtil.takeScreenshotAtEndOfTest("OtwCreatepage1");
	
	}
	
	@Test(priority =2, groups= {"AeJ"}, dataProvider = "CreateAejOTW",dataProviderClass = ExcelUtils.class)
	public void validateCreateNewOtwAeJ(String dPrjCode,String prjName,String otwDealType, String dealmanager, String detailsDisclosed, String companyName, String companyType, String walcroseeName, String wallcrossReason, String comments ) throws InterruptedException, IOException {
		
		//nicsHomePage.clickOnCreateOTWBtn();
		NicsLoginPage.login(prop.getProperty("AeJusername")); 
		//nicsHomePage.clickOnCreateOTWBtn();
		nicsCreateOtwPage.createNewOtwRequest(dPrjCode,prjName,otwDealType,dealmanager,detailsDisclosed,companyName,companyType,walcroseeName,wallcrossReason,comments);
		Thread.sleep(6000);
		String Label=NicsCreateOtwPage.validateSuccessMsg();
		System.out.print(Label);
		Assert.assertEquals(Label, "Over the Wall created successfully.");
		Assert.assertTrue(NicsCreateOtwPage.verifyOtwStatusLabel(),"OTW Status is missing");	
		//TestUtil.takeScreenshotAtEndOfTest("OtwCreatepage1");
	
	}
	
	@Test(priority =3, groups= {"Emea"}, dataProvider = "CreateEmeaOTW",dataProviderClass = ExcelUtils.class)
	public void validateCreateNewOtwEmea(String dPrjCode,String prjName,String otwDealType, String dealmanager, String detailsDisclosed, String companyName, String companyType, String walcroseeName, String wallcrossReason, String comments ) throws InterruptedException, IOException {
		
		//nicsHomePage.clickOnCreateOTWBtn();
		NicsLoginPage.login(prop.getProperty("emeausername")); 
		//nicsHomePage.clickOnCreateOTWBtn();
		nicsCreateOtwPage.createNewOtwRequest(dPrjCode,prjName,otwDealType,dealmanager,detailsDisclosed,companyName,companyType,walcroseeName,wallcrossReason,comments);
		Thread.sleep(6000);
		String Label=NicsCreateOtwPage.validateSuccessMsg();
		System.out.print(Label);
		Assert.assertEquals(Label, "Over the Wall created successfully.");
		Assert.assertTrue(NicsCreateOtwPage.verifyOtwStatusLabel(),"OTW Status is missing");	
		//TestUtil.takeScreenshotAtEndOfTest("OtwCreatepage1");
	
	}
	
	@AfterMethod(alwaysRun=true)
	public void tearDown(){
		driver.quit();
	}
	
}

package com.nics.qa.pages;

import java.util.ArrayList;
import java.util.List;

 





import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.nics.qa.base.TestBase;
import com.nics.qa.util.TestUtil;

public class NicsCreateOtwPage extends TestBase{
	//TestUtil TestUtil;
	NicsHomePage NicsHomePage;
//	NicsLoginPage NicsLoginPage;
	
	@FindBy(xpath = "//label[@class='NICSPageHeading']")
	WebElement otwPageLabel;
		
	@FindBy( id = "txtDealmakerProjectCode")
	WebElement dealmakerProjectCode;
	
	@FindBy(id = "txtProjectName")
	WebElement projectName ;
	
	@FindBy(id = "ddlDealType")
	WebElement dealType ;
	
	@FindBy(id = "txtDealManager")
	WebElement dealManager ;
	
	@FindBy(xpath = "//a[starts-with(@id,'ui-id')] [@class='ui-corner-all']")
	WebElement dealManagerSelect;
	
	@FindBy(name = "txtDetailsToBeDisclosed")
	WebElement detailsToBeDisclosed;
	
	@FindBy(xpath = "//input[@id='txtStartDate']/following::img[1]") // need to identify the locator
	WebElement calStartDate; 
	
	@FindBy(xpath = "//input[@id='txtIndicativeEndDate']/following::img[1]") // need to identify the locator
	WebElement calEndDate;
	
	@FindBy(id = "btnAddCompany")
	WebElement addCompany;
	
	@FindBy(xpath = "/html/body/div/center/table/tbody/tr/td/div/table/tbody/tr/td/div/form/table[2]/tbody/tr[1]/td[5]/input[1]")
	WebElement companyName2;
	
	@FindBy(id = "btnSearchCompany")
	WebElement searchBtn ;
	
	@FindBy(xpath = "/html/body/div/center/table/tbody/tr/td/div/table/tbody/tr/td/div/form/table[4]/tbody/tr/td/table/tbody/tr[2]/td[5]/a")
	WebElement selectedcompny ;
	
	@FindBy( id = "ddlCompanyInvolvementType")
	WebElement companyInvolvementType2;
	
	@FindBy(id = "btnAdd")
	WebElement addBtn2;
	
	@FindBy(id = "btnAddOTWRequest")
	WebElement addOTWRequest;
	
	@FindBy(xpath = "/html/body/div/center/table/tbody/tr/td/div/table/tbody/tr/td/div/table[2]/tbody/tr[2]/td[2]/input[1]")
	WebElement wallcrossemployee;
	
	@FindBy(xpath="//*[@id='ui-id-3']")
	WebElement employeeNameSelected;
	
	@FindBy(id = "ddlWallCrossReason")
	WebElement WallCrossReason;
	
	@FindBy(xpath = "//input[@id='chkOTWCompany_1']")
	WebElement OTWCompany;
	
	@FindBy(xpath = "//input[@id='btnAdd']")
	WebElement addBtn3;
	
	@FindBy(xpath = "//textarea[@id='WallCrossTransaction_TransactionComment']")
	WebElement comments2;
	
	@FindBy(xpath = "//input[@id='btnSubmitOTWTransaction']")
	WebElement submit;
	
	@FindBy(xpath = "//label[@id='lblSuccessMessage']")
	static
	
	WebElement successmsg; 
	
	@FindBy(xpath = "//label[@class='NICSPageHeading']")
	static
	
	WebElement otwStatusLabel;
	
	
	public NicsCreateOtwPage(){
		PageFactory.initElements(driver, this);
	}
	
	public boolean verifyCreateOTWPageLabel(){
		return otwPageLabel.isDisplayed();
	}
	//String dPrjCode1,String prjName1,String otwDealType1, String dealmanager1, String detailsDisclosed1, String companyName1, String companyType1, String walcroseeName1, String wallcrossReason1, String comments1
	
	/* ********************************
	Method Name : Create New OTW Request
	Creation date:
	Description : To Create New OTW Request
	********************************* */
	public void createNewOtwRequest(String dPrjCode1,String prjName1,String otwDealType1, String dealmanager1, String detailsDisclosed1, String companyName1, String companyType1, String walcroseeName1, String wallcrossReason1, String comments1) throws InterruptedException
	{								
		NicsHomePage = new NicsHomePage();
		NicsHomePage.clickOnCreateOTWBtn();
		TestUtil.implicitwait(20);
		dealmakerProjectCode.sendKeys(dPrjCode1);
		TestUtil.implicitwait(10);
		projectName.sendKeys(prjName1);
		Select dealtypedropdown = new Select(dealType);
		dealtypedropdown.selectByVisibleText(otwDealType1);
		//dealtypedropdown.selectByIndex(1);;
		dealManager.sendKeys(dealmanager1);
		TestUtil.clickOn(driver, dealManagerSelect, 10); 
		detailsToBeDisclosed.sendKeys(detailsDisclosed1);
		
		calStartDate.click();
		
		
		List<WebElement>calDates=driver.findElements(By.tagName("td"));
		
		for(int i=0;i<=calDates.size()-1;i++)
		{
			WebElement x = calDates.get(i);
			String s=x.getText();
			if(s.equals("2"))
			{
				x.click();
			}
		}
		
		calEndDate.click();
		
		//for identifying month
		while(!driver.findElement(By.xpath("//span[@class='ui-datepicker-month']")).getText().contains("September")){
			
			   driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-e']")).click();	
			}
		
		List<WebElement>calDates1=driver.findElements(By.tagName("td"));
		
		for(int i=0;i<=calDates1.size()-1;i++)
		{
			WebElement x = calDates1.get(i);
			String s=x.getText();
			if(s.equals("30"))
			{
				x.click();
			}
		}
		 
		addCompany.click();
		TestUtil.implicitwait(50);
		//Thread.sleep(3000);
		ArrayList<String> wh = new ArrayList<String>(driver.getWindowHandles());
		System.out.println("No of window are " +wh.size());
		driver.switchTo().window(wh.get(1));
		//TestUtil.switchToWindows();
		Thread.sleep(1000);
		//TestUtil.implicitwait(20);
		//TestUtil.sendkeys(driver, companyName2, 32, companyName1)visibilityOfElementLocated(By.id("txtCompanyName"));  
		WebDriverWait wait = new WebDriverWait(driver, 55);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div/center/table/tbody/tr/td/div/table/tbody/tr/td/div/form/table[2]/tbody/tr[1]/td[5]/input[1]")));
	//	Thread.sleep(1000);
		//driver.findElement(By.xpath("/html/body/div/center/table/tbody/tr/td/div/table/tbody/tr/td/div/form/table[2]/tbody/tr[1]/td[5]/input[1]")).sendKeys(companyName1);
		companyName2.sendKeys(companyName1);
		
		//companyName2.sendKeys(companyName1);
		searchBtn.click();
		TestUtil.implicitwait(45);
		selectedcompny.click();
		
		TestUtil.implicitwait(30);
		companyInvolvementType2.click();
		TestUtil.implicitwait(10);
		companyInvolvementType2.sendKeys(Keys.DOWN);
		TestUtil.implicitwait(10);
		companyInvolvementType2.sendKeys(Keys.RETURN);
		//Select dealtypedropdown1 = new Select(companyInvolvementType2);
	//	dealtypedropdown1.selectByVisibleText(companyType1);
		//dealtypedropdown1.selectByIndex(1);
		addBtn2.click();
		driver.switchTo().window(wh.get(0));
		//Thread.sleep(1090);
		TestUtil.implicitwait(25);
		//TestUtil.switchBackToMainwindows();
		addOTWRequest.click();
		 
		TestUtil.implicitwait(10);
		//Thread.sleep(3000);
	    ArrayList<String> wh1 = new ArrayList<String>(driver.getWindowHandles());
	    System.out.println("No of window are " +wh1.size());
		driver.switchTo().window(wh1.get(1));
		//TestUtil.switchToWindows();
		TestUtil.implicitwait(75);
		//TestUtil.sendkeys(driver, wallcrossemployee, 35);
		driver.findElement(By.xpath("/html/body/div/center/table/tbody/tr/td/div/table/tbody/tr/td/div/table[2]/tbody/tr[2]/td[2]/input[1]")).sendKeys(walcroseeName1);
		//TestUtil.sendkeys(driver, wallcrossemployee, 90, walcroseeName1);
		//wallcrossemployee.sendKeys(walcroseeName1);
		TestUtil.clickOn(driver, employeeNameSelected, 10);
		
		
		Select dealtypedropdown2 = new Select(WallCrossReason);
		dealtypedropdown2.selectByVisibleText(wallcrossReason1);
		//dealtypedropdown2.selectByIndex(1);
		//TestUtil.switchBackToMainwindows();
		OTWCompany.click();
		addBtn3.click();
		//Thread.sleep(2000);
		TestUtil.implicitwait(20);
		driver.switchTo().window(wh1.get(0));
		
		comments2.sendKeys(comments1);
		
		submit.click();
		TestUtil.implicitwait(40);
	
	}
	
	public static boolean verifyOtwStatusLabel(){
      return otwStatusLabel.isDisplayed();
	}
	
	
	public static String validateSuccessMsg() {
		// TODO Auto-generated method stub
		return successmsg.getText();
	}

}

package com.nics.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;



import com.nics.qa.base.TestBase;

public class MSLDashboardPage extends TestBase {
	
	
	@FindBy(xpath = "//button[@class = 'OTWInputButton']")
	WebElement createOtwbtn;
	
	
	
		
	public MSLDashboardPage(){
		PageFactory.initElements(driver, this);
	}
	
	public MSLPage clickOnCreateBtn() throws InterruptedException {
		
		//createOtwbtn.click();
		driver.findElement(By.xpath("//button[@id='btnCreateMSLModal']")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("rdCreateMSLOptionNICSID")).click();
		driver.findElement(By.xpath("//input[@id='txtCreateOptionValue']")).sendKeys("21061");
		driver.findElement(By.xpath("//input[@id='btnCreateMSL']")).click();
		return new MSLPage();
	} 
	
	
}

	
	 
/* ********************************
		#Project Name : NICS
		#ModuleName: Send to business Approval, Business Approval and Compliance Approval module in OTW
		#Version : 1.0
		#Author: Kapil Bandodekar
		#Date of Creation : 21 May 2018 
		#Reviewed By:  
		#Modification History:
		#Date Of Change:
		#Version: 
		#Change Description: 
		#Modified By : 
********************************* */	
package com.nics.qa.pages;

import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.nics.qa.base.TestBase;
import com.nics.qa.util.TestUtil;

public class OtwdashboardPage extends TestBase{
	
	 NicsLoginPage NicsLoginPage;
	 
	   
	
	// Below locators are for adding Nics id and assigning business approvers when compliance logins
	
		@FindBy(xpath = "//*[@id='gridPendingTable']/tbody/tr[1]/td[1]/a")
		WebElement otwTransactionid;
			
		@FindBy(id = "btnChangeNICSID")
		WebElement addChngeBtn;
		
		@FindBy(id = "txtNICSID") // to parameterize
		
		WebElement nicsId;
		
		@FindBy(id = "btnVerify")
		
		WebElement verifybtn;
			
		@FindBy(xpath = "//table[@id='dvNICSCompany']/tbody/tr[2]/td[1]/input[1]")
		
		WebElement selectCompany;
		
		@FindBy(id = "btnAddCompanies")
		
		WebElement selectBtn;
		
		@FindBy(xpath = "//table[starts-with(@id,'tblCompanyTable')]/tbody/tr[1]/td[4]/input[@type='checkbox']")
		
		WebElement selectRemoveCompany;
		
		@FindBy(id = "btnBulkRemoveCompanies")
		
		WebElement removeBtn;
		//table[@id="tblCompanyTable_39003")/tbody/tr[2]/td[2]/img
		@FindBy(xpath = "/html/body/div[1]/center/table/tbody/tr/td/div[2]/div/form/table[2]/tbody/tr/td/table[6]/tbody/tr/td/table/tbody/tr/td/table[2]/tbody/tr/td/table/tbody/tr[2]/td[9]/table[1]/tbody/tr[2]/td[2]/img")
		
		WebElement startCal;
		
		@FindBy(xpath = "//table[@class='ui-datepicker-calendar']/tbody/tr[2]/td[5]/a")
		
		WebElement startDate;
		
		@FindBy(xpath = "//table[starts-with(@id,'tblCompanyTable')]/tbody/tr[2]/td[3]/img")
		
		WebElement endCal;
		
		@FindBy(xpath = "/html/body/div[1]/center/table/tbody/tr/td/div[2]/div/form/table[2]/tbody/tr/td/table[6]/tbody/tr/td/table/tbody/tr/td/table[2]/tbody/tr/td/table/tbody/tr[2]/td[9]/table[1]/tbody/tr[2]/td[3]/img")
		
		WebElement endDate;
		
		@FindBy(xpath= "//*[@id='ui-datepicker-div']/table/tbody/tr[3]/td[4]/a")
		WebElement endDate1;
		
		@FindBy(xpath="/html/body/div[1]/center/table/tbody/tr/td/div[2]/div/form/table[2]/tbody/tr/td/table[6]/tbody/tr/td/table/tbody/tr/td/table[2]/tbody/tr/td/table/tbody/tr[2]/td[11]/select")
		WebElement approver1;
		
		//*[@id="ddlWallCrossApprover1_39003"]
		@FindBy(id = "ddlWallCrossApprover2_38999")
		WebElement approver2;
		
		@FindBy(xpath = "//table[@id='dvOTWRequest']/tbody/tr[2]/td[1]/input[@type='checkbox']")
		
		WebElement selectRequest;
		
		@FindBy(id = "WallCrossTransaction_TransactionComment")
		
		WebElement nicsUserComments;
		
		@FindBy(xpath = "//input[@id='btnApproveOTWTransaction']")
		
		WebElement approveBtn;
		
	    @FindBy(id = "lblSuccessMessage")
		static
		
		WebElement otwsuccess;
		
		@FindBy(id = "lnkOTWDashboard")
		WebElement otwDashboard;
		
		@FindBy(xpath = "//input[@id='btnSendToBAOTWTransaction']")
		WebElement btnSendToBusiness;
		
		@FindBy(id = "btnSendEmail")
		WebElement btnSend_Email;
	
		public OtwdashboardPage(){
			PageFactory.initElements(driver, this);
		}
		
		public void  clickOnSendTobusiness(String nicsItemid,String otwAprrover1, String otwCommnts) throws InterruptedException{
			
				
			driver.findElement(By.xpath("//*[@id='gridPendingTable']/tbody/tr[1]/td[1]/a")).click();
			TestUtil.implicitwait(25);
			driver.findElement(By.id("btnChangeNICSID")).click();
			TestUtil.implicitwait(50);
			ArrayList<String> wh = new ArrayList<String>(driver.getWindowHandles());
			System.out.println("No of window are " +wh.size());
			driver.switchTo().window(wh.get(1));
			TestUtil.implicitwait(25);
			//TestUtil.implicitwait(20);
			TestUtil.sendkeys(driver, nicsId, 33, nicsItemid); 
			//driver.findElement(By.id("txtNICSID")).sendKeys(nicsItemId);
			//nicsId.sendKeys(nicsItemid);
			TestUtil.implicitwait(30);
			verifybtn.click();
			//TestUtil.implicitwait(50);
			selectCompany.click();
			selectBtn.click();
			
			driver.switchTo().window(wh.get(0));
			
			//TestUtil.implicitwait(30);
			Thread.sleep(3000);
			
			driver.findElement(By.xpath("//table[starts-with(@id,'tblCompanyTable')]/tbody/tr[1]/td[4]/input[@type='checkbox']")).click();
			//TestUtil.sendkeys(driver, selectRemoveCompany, 40);
			//selectRemoveCompany.click();
			
			removeBtn.click();
			Thread.sleep(2000);
			
			startCal.click();
			List<WebElement>calDates=driver.findElements(By.tagName("td"));
			
			for(int i=0;i<=calDates.size()-1;i++)
			{
				WebElement x = calDates.get(i);
				String s=x.getText();
				if(s.equals("7"))
				{
					x.click();
				}
			}
			
			Thread.sleep(2000);
			endDate.click();
			Thread.sleep(2000);
			//endDate1.click();
			
			//driver.findElement(By.xpath("//*[@id="ui-datepicker-div"]/table/tbody/tr[3]/td[4]/a"));
			
			while(!driver.findElement(By.xpath("//span[@class='ui-datepicker-month']")).getText().contains("September")){
				
				   driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-e']")).click();	
				}
			
			List<WebElement>calDates1=driver.findElements(By.tagName("td"));
			
			for(int i=0;i<=calDates1.size()-1;i++)
			{
				WebElement x = calDates1.get(i);
				String s=x.getText();
				if(s.equals("28"))
				{
					x.click();
				}
			}
			Thread.sleep(2000);
			
			/*Select dealtypedropdown = new Select(approver1);
			dealtypedropdown.selectByVisibleText(text);*/
			approver1.click();
			Thread.sleep(1000);
			approver1.sendKeys(Keys.DOWN);
			Thread.sleep(1000);
			approver1.sendKeys(Keys.RETURN);
			
			
			
			
			TestUtil.implicitwait(20);
			selectRequest.click();
			TestUtil.implicitwait(20);
			nicsUserComments.sendKeys(otwCommnts);
			TestUtil.implicitwait(10);
			btnSendToBusiness.click();
			
		  	//TestUtil.implicitwait(30);
		    WebDriverWait wait = new WebDriverWait(driver, 50);
			wait.until(ExpectedConditions.alertIsPresent());
	     	//driver.switchTo().alert().accept();
			Alert alert = driver.switchTo().alert();
				String message = alert.getText();
				System.out.println(message);
				alert.accept();
				
				
				/*String Label = validateOtwSuccessMsg();
		        System.out.print(Label);
				Assert.assertEquals(Label, "Over the Wall Sent to Business Approver successfully.");*/
				//TestUtil.implicitwait(98);
				Thread.sleep(28550);
		    ArrayList<String> wh1 = new ArrayList<String>(driver.getWindowHandles());
		    
		    System.out.println(wh1);
		    System.out.print("No of window are " +wh1.size());
		   // String s = wh1.get(2);
		     
		    driver.switchTo().window(wh1.get(2));
		    System.out.println(wh1.get(2));
		    //Thread.sleep(7500);
		    TestUtil.implicitwait(95);
			driver.manage().window().maximize();
			Thread.sleep(3500);

			JavascriptExecutor jst = (JavascriptExecutor)driver;
			jst.executeScript("window.scrollBy(0,-200)", "");
			 
			//WebDriverWait wait2 = new WebDriverWait(driver, 50);
		//	wait2.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='btnSendEmail']")));
			TestUtil.implicitwait(95);
			//Thread.sleep(3500);
			btnSend_Email.click();
			
			
			
			
			TestUtil.implicitwait(90);
			//Thread.sleep(6500);
			WebDriverWait wait1 = new WebDriverWait(driver, 50);
			wait1.until(ExpectedConditions.alertIsPresent());
			Alert alert1 = driver.switchTo().alert();
			alert1.accept();
			
			
			TestUtil.implicitwait(20);
		    //Thread.sleep(2000);
		    //Thread.sleep(10000);
			//Alert alert2 = driver.switchTo().alert();
			//alert2.accept();
			
			driver.switchTo().window(wh1.get(0));
			Thread.sleep(3000);
		
		}
		
		public void complianceApproval(String otwCommnts) throws InterruptedException{
			
			driver.findElement(By.xpath("//*[@id='gridPendingTable']/tbody/tr[1]/td[1]/a")).click();	
			Thread.sleep(2100);
			selectRequest.click();
			nicsUserComments.sendKeys(otwCommnts);
			Thread.sleep(2000);
			
			approveBtn.click();
			Thread.sleep(2000);
			Alert alert1 = driver.switchTo().alert();
			alert1.accept();
			Thread.sleep(2000);
			
			
		}
		
		/* ********************************
		#Project Name : NICS
		#ModuleName: Business Approval module in OTW
		#Version : 1.0
		#Author: Kapil Bandodekar
		#Date of Creation :
		#Reviewed By:  
		#Modification History:
		#Date Of Change:
		#Version: 
		#Change Description: 
		#Modified By : 
		 ********************************* */		
		
		public void businessApproval()  throws InterruptedException{
			
			TestUtil.implicitwait(90);
			driver.findElement(By.xpath("//table[@id='gridOTWPendingApproval']/tbody/tr[1]/td[3]/a")).click();
			Thread.sleep(3200);
			driver.findElement(By.xpath("//textarea[@id='txtRequestComment']")).sendKeys("business approval");
			driver.findElement(By.xpath("//input[@id='btnApproveRequest']")).click();
			Thread.sleep(2000);
			
			
		}


		public  String validateAlertMessage() {
			Alert alert = driver.switchTo().alert();
			String message = alert.getText();
			System.out.println(message);
			alert.accept();
			return message;
		}
		
		/*public void validateEmailNotification(){
			ArrayList<String> wh = new ArrayList<String>(driver.getWindowHandles());
			System.out.println("No of window are " +wh.size());
			driver.switchTo().window(wh.get(1));
			btnSendEmail.click();
			Alert alert1 = driver.switchTo().alert();
			alert1.accept();
						
		}*/
		
		public String validateOtwSuccessMsg() {
			// TODO Auto-generated method stub
			return otwsuccess.getText();
		}


		
		
}

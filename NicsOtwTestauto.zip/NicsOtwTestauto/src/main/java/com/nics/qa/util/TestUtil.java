package com.nics.qa.util;

import java.io.File;
import java.io.IOException;
 
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.nics.qa.base.TestBase;


public class TestUtil extends TestBase   {
	
	
  public static long PAGE_LOAD_TIMEOUT = 60;
  public static long IMPLICIT_WAIT1 = 40;
  
  
  public void switchToWindows(){
	  ArrayList<String> wh = new ArrayList<String>(driver.getWindowHandles());
		//System.out.println("No of window are " +wh.size());
		driver.switchTo().window(wh.get(1));
  }
  
  public void switchBackToMainwindows(){
	  ArrayList<String> wh = new ArrayList<String>(driver.getWindowHandles());
		//System.out.println("No of window are " +wh.size());
		driver.switchTo().window(wh.get(0));
  }
  

  
 /* public static Map<String,String> getExcelData(String fileName, String sheetName) throws InvalidFormatException {

		HashMap<String,String> hs = new HashMap<String, String>();
		DataFormatter formatter = new DataFormatter();
		try(FileInputStream fs = new FileInputStream(fileName)) {
			//FileInputStream fs = new FileInputStream(fileName);
			Workbook wb = WorkbookFactory.create(fs);
			Sheet sh = (Sheet) wb.getSheet(sheetName);
			int totalNoOfCols = sh.getRow(0).getPhysicalNumberOfCells();
			int totalNoOfRows = sh.getPhysicalNumberOfRows();
			System.out.println("no of rows : "+totalNoOfRows);
			System.out.println("no of columns : "+totalNoOfCols);

			for(int i=0;i<totalNoOfRows;i++)
			{
				for(int j=1;j<totalNoOfCols;j++){
					String Key = formatter.formatCellValue(sh.getRow(i).getCell(j-1));
					//String Key = sh.getRow(i).getCell(j-1).getStringCellValue();
					//String Value = sh.getRow(i).getCell(j).getStringCellValue();
					String Value = formatter.formatCellValue(sh.getRow(i).getCell(j));
					/*System.out.println("Key----> "+Key);
					System.out.println("Value----> "+Value);*/
				/*	if(Key != "")
					{
						hs.put(Key,Value);
						System.out.println("Input Key: " +Key+" Value from Excel:: "+Value);
					}
					else
						break;
				}
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return hs;
	}*/


	public static void takeScreenshotAtEndOfTest(String result) throws IOException {
		File File = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String filename =  new SimpleDateFormat("yyyyMMddhhmmss'.txt'").format(new Date());
		FileUtils.copyFile(File, new File("H://Kapil//Selenium Test Data//"+ result + filename + "screenshot.png"));
		}
	
	public static void selectStartDateByJS(WebElement element,String calStartDate){
		JavascriptExecutor js =((JavascriptExecutor)driver);
		js.executeScript("arguments[0].setAttribute('value','"+calStartDate+"');",element);
		
	}

	public static void sendkeys(WebDriver driver, WebElement element,int timeoutseconds,String value) {
		new WebDriverWait(driver, timeoutseconds).until(ExpectedConditions.visibilityOf(element));
		 element.sendKeys(value);
	}
	
		
	public static void clickOn(WebDriver driver, WebElement element,int timeout) {
		new WebDriverWait(driver,timeout).until(ExpectedConditions.elementToBeClickable(element));
		element.click();
	}
	
	public static void implicitwait(int IMPLICIT_WAIT ){
		driver.manage().timeouts().implicitlyWait(IMPLICIT_WAIT, TimeUnit.SECONDS);
	}
	
	public void sendEmailJava() throws EmailException {
		
		Email email = new SimpleEmail();
		email.setHostName("smtp.googlemail.com");
		email.setSmtpPort(465);
		email.setAuthenticator(new DefaultAuthenticator("username", "password"));
		email.setSSLOnConnect(true);
		email.setFrom("user@gmail.com");
		email.setSubject("TestMail");
		email.setMsg("This is a test mail ... :-)");
		email.addTo("foo@bar.com");
		email.send();
	}
	
}

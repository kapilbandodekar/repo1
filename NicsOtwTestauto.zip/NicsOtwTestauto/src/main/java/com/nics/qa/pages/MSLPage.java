package com.nics.qa.pages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.nics.qa.base.TestBase;
import com.nics.qa.util.TestUtil;

public class MSLPage extends TestBase {
	
	NicsHomePage NicsHomePage;
	
	@FindBy(xpath = "/html/body/header/div/div[2]/div/div[3]/ul/li[5]/a")
	WebElement marketSoundLogTab;
	
	@FindBy(xpath = "//button[@id='btnCreateMSLModal']")
	WebElement createBtn;
	
	@FindBy(id = "rdCreateMSLOptionNICSID")
	WebElement nicsIDRadiobtn;
	
	@FindBy(xpath = "//input[@id='txtCreateOptionValue']")
	WebElement nicsIDTextArea;
	
	@FindBy(xpath = "//button[@id='btnCreateMSL']")
	WebElement createMSLBtn;
	
	@FindBy(xpath = "/html/body/div[1]/form/div[2]/div[2]/div[5]/div[2]/span/span[1]/span/span[1]")
	WebElement dealSponsor;
	
	@FindBy(xpath = "/html/body/span/span/span[1]/input")	
	WebElement dealSponsorManagerTextArea;
	
	@FindBy(xpath = "/html/body/div[1]/form/div[2]/div[2]/div[6]/div[2]/span/span[1]/span/span[1]")
	WebElement dealManager;
	
	@FindBy(xpath = "/html/body/div[1]/form/div[3]/div[2]/div[1]/div[2]/span/span[1]/span")
	WebElement delegateTextArea;
	
	@FindBy(xpath = "/html/body/div[1]/form/div[3]/div[2]/div[4]/div[2]/textarea")
	WebElement informationDisclosed;
	
	@FindBy(xpath = "//span[@class='input-group-addon datefieldicon']/preceding::input[@id='AnticipatedEndDate']")
	WebElement anticipatedEndDate;
	
	@FindBy(xpath = "/html/body/div[1]/form/div[4]/div[2]/div/div[2]/div/table/tbody/tr/td[1]/input")
	WebElement companyDetail;
	
	@FindBy(xpath = "/html/body/div[1]/form/div[5]/div[2]/div[1]/button[1]")
	WebElement uploadDoc;
	
	@FindBy(xpath = "/html/body/div[1]/div[1]/div/div/form/div[1]/div[3]/div[2]/input")
	WebElement browse;
	
	@FindBy(xpath = "/html/body/div[1]/div[1]/div/div/form/div[2]/button[2]")
	WebElement upload1;
	
	@FindBy(id = "btnUploadthirdparty")
	WebElement uploadSoundRecipientDetails;
	
	@FindBy(xpath = "/html/body/div[1]/div[4]/div/div/form/div[1]/div/div[2]/input")
	WebElement brwse;
	
	
	@FindBy(xpath = "//button[@id='btnViewUploadThirdParty']")
	WebElement upload2;
	
	@FindBy(xpath = "//button[@id='btnActivate']")
	WebElement saveAsActive;
	
	
	
	
	public MSLPage(){
		PageFactory.initElements(driver, this);
	}
	
	
	public void createNewMSL(String nicsID, String dsponsor, String dManager, String delegate, String infDisclosed, String  antDate, String docFilePath, String docName ) throws InterruptedException{
		
		//NicsHomePage = new NicsHomePage();
		//NicsHomePage.clickOnMSLLogsTab();
		marketSoundLogTab.click();
		Thread.sleep(3000);
		//TestUtil.implicitwait(30);
		createBtn.click();
		//TestUtil.implicitwait(50);
		Thread.sleep(5000);
		nicsIDRadiobtn.click();
		
		nicsIDTextArea.sendKeys(nicsID);
		createMSLBtn.click();
		//TestUtil.implicitwait(40);
		Thread.sleep(3200);
		
		dealSponsor.click();
		//TestUtil.implicitwait(20);
		Thread.sleep(2000);
		dealSponsorManagerTextArea.sendKeys(dsponsor);
		//TestUtil.implicitwait(30);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span/span/span/input")).sendKeys(Keys.DOWN);
		//TestUtil.implicitwait(30);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span/span/span/input")).sendKeys(Keys.RETURN);
		
		dealManager.click();
		dealSponsorManagerTextArea.sendKeys(dManager);
		//TestUtil.implicitwait(30);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span/span/span/input")).sendKeys(Keys.DOWN);
		//TestUtil.implicitwait(30);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span/span/span/input")).sendKeys(Keys.RETURN);
		
		delegateTextArea.sendKeys(delegate);
		//TestUtil.implicitwait(30);
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/span/span/span/ul/li")).sendKeys(Keys.DOWN);
		//TestUtil.implicitwait(30);
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/span/span/span/ul/li")).sendKeys(Keys.RETURN);
		//TestUtil.implicitwait(30);
		Thread.sleep(3000);
		
		
		informationDisclosed.sendKeys(infDisclosed);
		//TestUtil.implicitwait(40);
		Thread.sleep(4000);
		
		anticipatedEndDate.sendKeys(antDate);
		anticipatedEndDate.sendKeys(Keys.ENTER);
		//TestUtil.implicitwait(40);
		Thread.sleep(3500);
		
		companyDetail.click();
		uploadDoc.click();
		//TestUtil.implicitwait(50);
		Thread.sleep(5000);
		
		
		browse.sendKeys(docFilePath);
	    //TestUtil.implicitwait(30);
		Thread.sleep(2500);
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/div/form/div[1]/div[2]/div[2]/input")).sendKeys(docName);
		//TestUtil.implicitwait(20);
		Thread.sleep(2000);
		upload1.click();
		//TestUtil.implicitwait(40);
		Thread.sleep(4000);
		Alert alert = driver.switchTo().alert();
		//TestUtil.implicitwait(20);
		Thread.sleep(2000);
		alert.accept();
		
		Thread.sleep(3500);
		//TestUtil.implicitwait(40);
		uploadSoundRecipientDetails.click();
		
		//TestUtil.implicitwait(80);
		Thread.sleep(8000);
		brwse.sendKeys("H:\\Kapil\\NICS project\\Market Sounding Logs(MSL)\\MS Recipient Upload.xlsx");
		Thread.sleep(5000);
		
		
		upload2.click();
		//TestUtil.implicitwait(50);
		Thread.sleep(5000);
		
		saveAsActive.click();
		//TestUtil.implicitwait(20);
		Thread.sleep(2000);
		Alert alert1 = driver.switchTo().alert();
		String s= alert1.getText();
		System.out.println(s);
		alert1.accept();
		
		
		
		//driver.findElement(By.id("txtUser")).sendKeys("jaykumar");
		//driver.findElement(By.id("btnImpersonate")).click();
		//Thread.sleep(5000);
		//driver.findElement(By.xpath("//div/ul/li[5]/a")).click();
		//Thread.sleep(2500);
		//driver.findElement(By.xpath("//button[@id='btnCreateMSLModal']")).click();
		//Thread.sleep(5000);

		//driver.findElement(By.id("rdCreateMSLOptionNICSID")).click();
		//driver.findElement(By.xpath("//input[@id='txtCreateOptionValue']")).sendKeys("21061");
		//driver.findElement(By.xpath("//button[@id='btnCreateMSL']")).click();
		///Thread.sleep(3000);
		//driver.findElement(By.xpath("/html/body/div[1]/form/div[2]/div[2]/div[5]/div[2]/span/span[1]/span/span[1]")).click();
		//driver.findElement(By.xpath("/html/body/span/span/span[1]/input")).sendKeys("gholekas");
	/*	Thread.sleep(3000);
		driver.findElement(By.xpath("//span/span/span/input")).sendKeys(Keys.DOWN);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span/span/span/input")).sendKeys(Keys.RETURN);*/
		//driver.findElement(By.xpath("/html/body/div[1]/form/div[2]/div[2]/div[6]/div[2]/span/span[1]/span/span[1]")).click();
		//driver.findElement(By.xpath("/html/body/span/span/span[1]/input")).sendKeys("jaykumar");
	/*	Thread.sleep(3000);
		driver.findElement(By.xpath("//span/span/span/input")).sendKeys(Keys.DOWN);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span/span/span/input")).sendKeys(Keys.RETURN);
		*/
		//driver.findElement(By.xpath("/html/body/div[1]/form/div[3]/div[2]/div[1]/div[2]/span/span[1]/span")).sendKeys("chandea");
	/*	Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/span/span/span/ul/li")).sendKeys(Keys.DOWN);
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/span/span/span/ul/li")).sendKeys(Keys.RETURN);
		Thread.sleep(3000); */
		//driver.findElement(By.xpath("/html/body/div[1]/form/div[3]/div[2]/div[4]/div[2]/textarea")).sendKeys("TestInformation");
		
		//Thread.sleep(4000);
		
		//WebElement AnticipatedEndDate = driver.findElement(By.xpath("//span[@class='input-group-addon datefieldicon']/preceding::input[@id='AnticipatedEndDate']"));
		//AnticipatedEndDate.click();
		
		//driver.findElement(By.xpath("//span[@class='input-group-addon datefieldicon']/preceding::input[@id='AnticipatedEndDate']")).sendKeys("28 Sep 2018");
		//driver.findElement(By.xpath("//span[@class='input-group-addon datefieldicon']/preceding::input[@id='AnticipatedEndDate']")).sendKeys(Keys.ENTER);
		//Thread.sleep(3500);
					                              
		//driver.findElement(By.xpath("/html/body/div[1]/form/div[4]/div[2]/div/div[2]/div/table/tbody/tr/td[1]/input")).click();
		
		//driver.findElement(By.xpath("/html/body/div[1]/form/div[5]/div[2]/div[1]/button[1]")).click();
		
		//Thread.sleep(5000);
		//WebElement browse= driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/div/form/div[1]/div[3]/div[2]/input"));
		
		//browse.sendKeys("H:\\Kapil\\NICS project\\Market Sounding Logs(MSL)\\Test document.txt");
		
		//Thread.sleep(2500);
		
		//driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/div/form/div[1]/div[2]/div[2]/input")).sendKeys("test Document");
		
		//Thread.sleep(2000);
		
		
		//driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/div/form/div[2]/button[2]")).click();
		//Thread.sleep(4000);
		
		//Alert alert = driver.switchTo().alert();
		//Thread.sleep(2000);
		//alert.accept();
		
		//Thread.sleep(3500);
		
		//driver.findElement(By.id("btnUploadthirdparty")).click();
		//Thread.sleep(8000);
		
		//WebElement brwse = driver.findElement(By.xpath("/html/body/div[1]/div[4]/div/div/form/div[1]/div/div[2]/input"));
		//brwse.sendKeys("H:\\Kapil\\NICS project\\Market Sounding Logs(MSL)\\MS Recipient Upload.xlsx");
		
		//Thread.sleep(5000);
			
		//driver.findElement(By.xpath("//button[@id='btnViewUploadThirdParty']")).click();	
		
		//Thread.sleep(5000);
		//H:\\Kapil\\NICS project\\Market Sounding Logs(MSL)\\MSL_Testing\\3rd party uploading doc\\MSL uploading file\\New folder\\MS Recipient Upload.xlsx
		
		//driver.findElement(By.xpath("//input[@id='DoNotSendEmail']")).click();
		
		//driver.findElement(By.xpath("//button[@id='btnActivate']")).click();
		
		//Alert alert1 = driver.switchTo().alert();
		//String s= alert1.getText();
		//System.out.println(s);
		//alert1.accept();
		
	}
}
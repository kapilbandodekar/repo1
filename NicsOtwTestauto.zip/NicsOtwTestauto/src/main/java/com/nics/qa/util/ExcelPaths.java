package com.nics.qa.util;

public class ExcelPaths {
	
	public static String otwdetails ="H:\\Kapil\\Selenium Test Data\\OTWCreateTestdata.xlsx";
	public static String busidata ="H:\\Kapil\\Selenium Test Data\\OTWCreateTestdata.xlsx";
	public static String compdata ="H:\\Kapil\\Selenium Test Data\\OTWCreateTestdata.xlsx";
	public static String mslDetails ="H:\\Kapil\\Selenium Test Data\\OTWCreateTestdata.xlsx";

}

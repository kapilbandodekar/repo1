package com.nics.qa.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class test {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.ie.driver","C:\\Temp\\Drivers\\IEDriverServer.exe");
		WebDriver driver= new InternetExplorerDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("http://int-intranet.nomuranow.com/corporate/compliance/NICSOTW/Base/Impersonate");
		
		driver.manage().window().maximize();
		
		driver.findElement(By.id("txtUser")).sendKeys("jaykumar");
		driver.findElement(By.id("btnImpersonate")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div/ul/li[5]/a")).click();
		Thread.sleep(2500);
		driver.findElement(By.xpath("//button[@id='btnCreateMSLModal']")).click();
		Thread.sleep(5000);
		/*ArrayList<String> wh1 = new ArrayList<String>(driver.getWindowHandles());
		System.out.println("No of window are " +wh1.size());
		driver.switchTo().window(wh1.get(1));*/
		driver.findElement(By.id("rdCreateMSLOptionNICSID")).click();
		driver.findElement(By.xpath("//input[@id='txtCreateOptionValue']")).sendKeys("21061");
		driver.findElement(By.xpath("//button[@id='btnCreateMSL']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[1]/form/div[2]/div[2]/div[5]/div[2]/span/span[1]/span/span[1]")).click();
		driver.findElement(By.xpath("/html/body/span/span/span[1]/input")).sendKeys("gholekas");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span/span/span/input")).sendKeys(Keys.DOWN);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span/span/span/input")).sendKeys(Keys.RETURN);
		driver.findElement(By.xpath("/html/body/div[1]/form/div[2]/div[2]/div[6]/div[2]/span/span[1]/span/span[1]")).click();
		driver.findElement(By.xpath("/html/body/span/span/span[1]/input")).sendKeys("jaykumar");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span/span/span/input")).sendKeys(Keys.DOWN);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span/span/span/input")).sendKeys(Keys.RETURN);
		
		driver.findElement(By.xpath("/html/body/div[1]/form/div[3]/div[2]/div[1]/div[2]/span/span[1]/span")).sendKeys("chandea");
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/span/span/span/ul/li")).sendKeys(Keys.DOWN);
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/span/span/span/ul/li")).sendKeys(Keys.RETURN);
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[1]/form/div[3]/div[2]/div[4]/div[2]/textarea")).sendKeys("TestInformation");
		
		Thread.sleep(4000);
		
		//WebElement AnticipatedEndDate = driver.findElement(By.xpath("//span[@class='input-group-addon datefieldicon']/preceding::input[@id='AnticipatedEndDate']"));
		//AnticipatedEndDate.click();
		
		driver.findElement(By.xpath("//span[@class='input-group-addon datefieldicon']/preceding::input[@id='AnticipatedEndDate']")).sendKeys("28 Sep 2018");
		driver.findElement(By.xpath("//span[@class='input-group-addon datefieldicon']/preceding::input[@id='AnticipatedEndDate']")).sendKeys(Keys.ENTER);
		Thread.sleep(3500);
					                              
		driver.findElement(By.xpath("/html/body/div[1]/form/div[4]/div[2]/div/div[2]/div/table/tbody/tr/td[1]/input")).click();
		
		driver.findElement(By.xpath("/html/body/div[1]/form/div[5]/div[2]/div[1]/button[1]")).click();
		
		Thread.sleep(5000);
		WebElement browse= driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/div/form/div[1]/div[3]/div[2]/input"));
		
		browse.sendKeys("H:\\Kapil\\NICS project\\Market Sounding Logs(MSL)\\Test document.txt");
		
		Thread.sleep(2500);
		
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/div/form/div[1]/div[2]/div[2]/input")).sendKeys("test Document");
		
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/div/form/div[2]/button[2]")).click();
		Thread.sleep(4000);
		
		Alert alert = driver.switchTo().alert();
		Thread.sleep(2000);
		alert.accept();
		
		Thread.sleep(3500);
		
		driver.findElement(By.xpath("/html/body/div[1]/form/div[6]/div[2]/div[1]/button[1]")).click();
		Thread.sleep(3500);
		
		driver.findElement(By.id("ExtensionNumber")).sendKeys("9999999999");
				 
		driver.findElement(By.id("btnSearchCompany")).click();
		Thread.sleep(4000);
		
		
		driver.findElement(By.id("txtESMI")).sendKeys("4386523");
		driver.findElement(By.id("btnSearchClientCompany")).click();
		
		driver.findElement(By.name("radClientCompany")).click();
		driver.findElement(By.id("btnSaveCompany")).click();
			
		
		
		Thread.sleep(3500);
		driver.findElement(By.id("IndividualContactedName")).sendKeys("Vinay Sakpal");
		driver.findElement(By.id("IndividualPosition")).sendKeys("Team Member");
		
		driver.findElement(By.id("CountryID_chosen")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div/form/div[1]/div[7]/div[2]/div/div/div/input")).sendKeys("UNITED KINGDOM");
		
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div/form/div[1]/div[7]/div[2]/div/div/div/input")).sendKeys(Keys.DOWN);
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div/form/div[1]/div[7]/div[2]/div/div/div/input")).sendKeys(Keys.ENTER);
		
		
		
		
		/*driver.findElement(By.id("btnUploadthirdparty")).click();
		Thread.sleep(8000);
		
		WebElement brwse = driver.findElement(By.xpath("/html/body/div[1]/div[4]/div/div/form/div[1]/div/div[2]/input"));
		brwse.sendKeys("H:\\Kapil\\NICS project\\Market Sounding Logs(MSL)\\MS Recipient Upload.xlsx");
		
		Thread.sleep(5000);
			
		driver.findElement(By.xpath("//button[@id='btnViewUploadThirdParty']")).click();	*/
		
		Thread.sleep(5000);
		//H:\\Kapil\\NICS project\\Market Sounding Logs(MSL)\\MSL_Testing\\3rd party uploading doc\\MSL uploading file\\New folder\\MS Recipient Upload.xlsx
		
		//driver.findElement(By.xpath("//input[@id='DoNotSendEmail']")).click();
		
		driver.findElement(By.xpath("//button[@id='btnActivate']")).click();
		Alert alert1 = driver.switchTo().alert();
		String s= alert1.getText();
		System.out.println(s);
		alert1.accept();
		
		 
		
		
		
		
	
	
	
	
	
	
	
	}
}

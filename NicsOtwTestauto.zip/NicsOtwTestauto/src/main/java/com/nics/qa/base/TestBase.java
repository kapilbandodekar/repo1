package com.nics.qa.base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.nics.qa.util.TestUtil;

public class TestBase {
	
		public static WebDriver driver;
		public static Properties prop;
		static DesiredCapabilities capabilities ;
	
	public TestBase(){
	try {
			prop = new Properties();
			FileInputStream ip = new FileInputStream("H:/Kapil/RADAR/NicsOtwTestauto/src/main/java/com/"
					+ "nics/qa/config/config.properties");
			
			prop.load(ip);
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
public static void initialization(){
	
	String browserName = prop.getProperty("browser");
	
	if(browserName.equals("ie")){
		System.setProperty("webdriver.ie.driver","C:\\Temp\\Drivers\\IEDriverServer.exe");
		driver = new InternetExplorerDriver();
	}
	else if(browserName.equals("chrome")){
		System.setProperty("webdriver.chrome.driver","C:\\Temp\\Drivers\\chromedriver.exe");
		driver = new InternetExplorerDriver();
	}
	
	driver.manage().window().maximize();
	driver.manage().deleteAllCookies();
	driver.manage().timeouts().pageLoadTimeout(TestUtil.PAGE_LOAD_TIMEOUT,TimeUnit.SECONDS);
	//driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT1, TimeUnit.SECONDS);
//	DesiredCapabilities.internetExplorer();
//	capabilities.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
	driver.get(prop.getProperty("url"));
	
	
}
	
}

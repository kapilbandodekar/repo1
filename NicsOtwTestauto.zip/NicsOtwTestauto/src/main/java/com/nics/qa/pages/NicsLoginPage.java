package com.nics.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nics.qa.base.TestBase;
import com.nics.qa.util.TestUtil;

public class NicsLoginPage extends TestBase {
	
	//Page Factory -- OR
	@FindBy(id = "txtUser")
	WebElement nicsUser;
	
	@FindBy(id = "btnImpersonate")
	WebElement impersonateBtn;

	
	public NicsLoginPage(){
		PageFactory.initElements(driver, this);
	}
	
	public String validateLogiPageTitle(){
		return driver.getTitle();
	}
	
	/* ********************************
	Method Name : Home Page Login
	Creation date:
	Description : Login to Nics 
	********************************* */
	
	public NicsHomePage login(String un) throws InterruptedException  {
		nicsUser.sendKeys(un);
		impersonateBtn.click();
		Thread.sleep(4000);
		 
		return new NicsHomePage();
	}
	
	/* ********************************
	Method Name : Home Page Login
	Creation date:
	Description : Login to Nics by Complaince User
	********************************* */
	
	public OtwdashboardPage complianceLogin(String comUser) throws InterruptedException{
		nicsUser.sendKeys(comUser);
		impersonateBtn.click();
		Thread.sleep(6500);
		
		return new OtwdashboardPage();
		
	}
	
	/* ********************************
	Method Name : Home Page Login
	Creation date:
	Description : Login to Nics by Business User
	********************************* */
	
	public OtwdashboardPage businessLogin(String businUser) throws InterruptedException{
		nicsUser.sendKeys(businUser);
		impersonateBtn.click();
		Thread.sleep(7505);
		//TestUtil.implicitwait(70);
		return new OtwdashboardPage();
		
	}
	
	
	
}

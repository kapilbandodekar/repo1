package com.nics.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


import com.nics.qa.base.TestBase;

public class NicsHomePage extends TestBase {
	
	
	@FindBy(xpath = "//button[@class = 'OTWInputButton']")
	WebElement createOtwbtn;
	
	
	
		
	public NicsHomePage(){
		PageFactory.initElements(driver, this);
	}
	
	 
	public NicsCreateOtwPage clickOnCreateOTWBtn() throws InterruptedException {
		
		//createOtwbtn.click();
		driver.findElement(By.xpath("//button[@class = 'OTWInputButton']")).click();
		Thread.sleep(7000);
		return new NicsCreateOtwPage();
	} 
	
	public MSLDashboardPage clickOnMSLLogsTab() throws InterruptedException{
		
		driver.findElement(By.xpath("/html/body/header/div/div[2]/div/div[3]/ul/li[5]/a")).click();
		Thread.sleep(6000);
		return new MSLDashboardPage();
	
	}
	
}

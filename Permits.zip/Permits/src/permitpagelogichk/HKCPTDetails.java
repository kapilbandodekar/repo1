package permitpagelogichk;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import utils.ReusableMethods;
import utils.StaticProvider;
import permitpageelementshk.CPTPages;

public class HKCPTDetails extends ReusableMethods {
	@Test(dataProvider = "HKCPT", dataProviderClass = StaticProvider.class)
	public static void main(String Ename, String CENum, String RAType, String HRNeeded, String HRSponsar, String AssignRA, String AssignHRNeeded, String AddCPTTemp, String	CPTCourseName, String CPTHr, String	CPTLoc, String CPTSearchAttend, String CPTEName, String CPTCrName, String HRCompleted1, String CourseProvider, String HRCompleted2) {
		// TODO Auto-generated method stub
		
		//Add Employee
		
		driver.findElement(CPTPages.addEmpTab).click();
		permitWait(2);
		driver.findElement(CPTPages.addEmpName).sendKeys(Ename);
		permitWait(2);
		driver.findElement(CPTPages.addEmpName).sendKeys(Keys.DOWN);
		permitWait(1);
		driver.findElement(CPTPages.addEmpName).sendKeys(Keys.RETURN);
		permitWait(1);
		driver.findElement(CPTPages.ceNumber).clear();
		driver.findElement(CPTPages.ceNumber).sendKeys(CENum);
		driver.findElement(CPTPages.deRegisterRadio).click();
		permitWait(1);
		
		driver.findElement(CPTPages.addNewRA).click();
		permitWait(2);
		driver.findElement(CPTPages.selectRAType).sendKeys(RAType);
		driver.findElement(CPTPages.cptHoursNeeded).sendKeys(HRNeeded);
		driver.findElement(CPTPages.sponsoredRadio).click();
		permitWait(1);
		driver.findElement(CPTPages.sponsoredHours).sendKeys(HRSponsar);
		permitWait(2);
		driver.findElement(CPTPages.licDate).click();
		permitWait(1);
		driver.findElement(CPTPages.licDateSelect).click();
		permitWait(1);
		driver.findElement(CPTPages.cptAssignementSave).click();
		permitWait(2);
		
		WebElement regActOkButton = driver.findElement(CPTPages.raOkButton);
		if(regActOkButton != null){
			regActOkButton.click();
			System.out.println("Regulated Activities Saved Successfully");
			}
		else{
			System.out.println("Alert! Regulated Activities not Saved");
			}
		permitWait(2);
		
		driver.findElement(CPTPages.addNewAdditionalCPT).click();
		permitWait(2);
		driver.findElement(CPTPages.cptAssignFromDate).click();
		permitWait(1);
		driver.findElement(CPTPages.cptAssignFromDateSelect).click();
		driver.findElement(CPTPages.cptAssignToDate).click();
		permitWait(1);
		driver.findElement(CPTPages.cptAssignToDateSelect).click();
		driver.findElement(CPTPages.cptAssignRAType).sendKeys(AssignRA);
		driver.findElement(CPTPages.cptAssignHrNeeded).sendKeys(AssignHRNeeded);
		driver.findElement(CPTPages.cptAssignLicDate).click();
		driver.findElement(CPTPages.cptAssignLicDateSelect).click();
		permitWait(1);
		driver.findElement(CPTPages.cptAssignSave).click();
		permitWait(2);
		
		WebElement assignCPTOkButton = driver.findElement(CPTPages.cptAssignOkButton);
		if(assignCPTOkButton != null){
			assignCPTOkButton.click();
			System.out.println("Additional CPT Assigned Successfully");
			}
		else{
			System.out.println("Alert! Additional CPT not Assigned");
			}
		
		
		permitWait(1500);
		driver.findElement(CPTPages.cptAssignClose).click();
		permitWait(2);
		driver.findElement(CPTPages.cptAddEmpSave).click();
		permitWait(2);
		WebElement empOkButton = driver.findElement(CPTPages.addEmpOkButton);
		if(empOkButton != null){
			empOkButton.click();
			System.out.println("Employee CPT Added Successfully");
			}
		else{
			System.out.println("Alert! Employee CPT not Added");
			}		

		
		
		//Add CPT Details
		driver.findElement(CPTPages.addCPTTab).click();
		permitWait(2);
		driver.findElement(CPTPages.addCPTTemplate).sendKeys(AddCPTTemp);
		driver.findElement(CPTPages.addCPTCourseName).clear();
		driver.findElement(CPTPages.addCPTCourseName).sendKeys(CPTCourseName);
		driver.findElement(CPTPages.addCPTCourseDate).click();
		permitWait(1500);
		driver.findElement(CPTPages.addCPTCourseMonth).click();
		driver.findElement(CPTPages.addCPTCourseMonth).sendKeys(Keys.DOWN);
		driver.findElement(CPTPages.addCPTCourseMonth).sendKeys(Keys.DOWN);
		driver.findElement(CPTPages.addCPTCourseMonth).sendKeys(Keys.TAB);
		permitWait(1);
		driver.findElement(CPTPages.addCPTCourseDateSelect).click();
		driver.findElement(CPTPages.addCPTHour).clear();
		driver.findElement(CPTPages.addCPTHour).sendKeys(CPTHr);
		driver.findElement(CPTPages.addCPTSponsor).click();
		driver.findElement(CPTPages.addCPTAdditionalHR).click();
		driver.findElement(CPTPages.addCPTLocation).sendKeys(CPTLoc);
		driver.findElement(CPTPages.addCPTSearchAttend).sendKeys(CPTSearchAttend);
		permitWait(2);
		driver.findElement(CPTPages.addCPTSearchAttend).sendKeys(Keys.DOWN);
		driver.findElement(CPTPages.addCPTSearchAttend).sendKeys(Keys.RETURN);
		permitWait(1);
		driver.findElement(CPTPages.addAttendbutton).click();
		driver.findElement(CPTPages.addCPTUpdateHr).click();
		permitWait(1);
		driver.findElement(CPTPages.addCPTUpdateYes).click();
		permitWait(2);
		
		WebElement updateCPTOk = driver.findElement(CPTPages.addCPTUpdateOk);
		if(updateCPTOk != null){
			updateCPTOk.click();
			System.out.println("CPT Details Updated Successfully");
			}
		else{
			System.out.println("Alert! CPT Details Updated");
			}
		permitWait(1);
		
		
		driver.findElement(CPTPages.addCPTUpload).click();
		permitWait(2);
		WebElement uploadCPTOk = driver.findElement(CPTPages.addCPTUplaodOK);
		if(uploadCPTOk != null){
			uploadCPTOk.click();
			System.out.println("CPT Details Uploaded Successfully");
			}
		else{
			System.out.println("Alert! CPT Details Uploaded");
			}
		permitWait(1);
		
		//Current CPT Details
		driver.findElement(CPTPages.currentCPTTab).click();
		permitWait(2);
		driver.findElement(CPTPages.curCPTEmpName).sendKeys(CPTEName);
		permitWait(1);
		driver.findElement(CPTPages.curCPTEmpName).sendKeys(Keys.DOWN);
		permitWait(1);
		driver.findElement(CPTPages.curCPTEmpName).sendKeys(Keys.RETURN);
		permitWait(2);
		driver.findElement(CPTPages.addNewCPTCourse).click();
		permitWait(2);
		driver.findElement(CPTPages.cptCourseName).sendKeys(CPTCrName);
		driver.findElement(CPTPages.courseDate).click();
		driver.findElement(CPTPages.courseDateSelect).click();
		driver.findElement(CPTPages.hoursCompleted).sendKeys(HRCompleted1);
		driver.findElement(CPTPages.courseProvider).sendKeys(CourseProvider);
		driver.findElement(CPTPages.cptCourseSave).click();
		permitWait(2);
		
		WebElement cptOk1 = driver.findElement(CPTPages.cptCourseOkButton);
		if(cptOk1 != null){
			cptOk1.click();
			System.out.println("CPT Details Saved Successfully");
			}
		else{
			System.out.println("Alert! CPT Details not Saved");
			}
		permitWait(1);
		
		permitWait(2);
		driver.findElement(CPTPages.sponsorHrsRow).click();
		permitWait(1);
		driver.findElement(CPTPages.addNewCPTCourse).click();
		permitWait(2);
		driver.findElement(CPTPages.cptCourseName).sendKeys(CPTCrName);
		driver.findElement(CPTPages.courseDate).click();
		driver.findElement(CPTPages.courseDateSelect).click();
		driver.findElement(CPTPages.hoursCompleted).sendKeys(HRCompleted2);
		driver.findElement(CPTPages.courseProvider).sendKeys(CourseProvider);
		driver.findElement(CPTPages.cptCourseSave).click();
		permitWait(2);
		
		WebElement cptOk2 = driver.findElement(CPTPages.cptCourseOkButton);
		if(cptOk2 != null){
			cptOk2.click();
			System.out.println("CPT Details(Sponsor) Saved Successfully");
			}
		else{
			System.out.println("Alert! CPT Details(Sponsor) not Saved");
			}
		permitWait(1);

		driver.findElement(CPTPages.cptStatusNew).getText();
		
		permitWait(1);
		try {
			TakeSnapShot(driver,"H://Permit//Screenshot//Auto Image//CPTDetails.png");
			System.out.println("Screenshot Taken Successfully");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
}
	@BeforeTest
	public void beforeTest() throws InterruptedException
	{
		OpenBrowser();
		permitWait(2);
		driver.findElement(CPTPages.cptMenu).click();
		permitWait(1);
		driver.findElement(CPTPages.cptDetailsMenu).click();
		permitWait(3);
    }
	@AfterTest
	public void afterTest() 
	{
		//driver.quit();
	}
}

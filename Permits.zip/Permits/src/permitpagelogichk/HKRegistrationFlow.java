package permitpagelogichk;

import java.awt.AWTException;
import java.awt.Robot;

import com.sun.glass.events.KeyEvent;

import java.awt.datatransfer.StringSelection;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import permitpageelementshk.HKRegistrationModule;
import permitpageelementssg.SGRegistrationModule;
import utils.ReusableMethods;
import utils.StaticProvider;

public class HKRegistrationFlow extends ReusableMethods {
	@Test(dataProvider = "HKRegistration", dataProviderClass = StaticProvider.class)
	public static void main(String Gender, String FName, String	LName, String HireType, String CorpTitle, String FuncTitle, String OptDesc, String EmpDetStatus, String RegHandBy, String EmpDetComment,
			                String LicRole, String SubType, String AppType, String RATypeList, String NMList, String AppStatus, String Reason, String PayDetails, String PayDesc, String PayAmt, String	PayType, String	SFCRegHandBy, String SFCComment,
			                String EntCE, String RegRAType, String RegLicRole, String SfcSub, String RegLicCat, String RegCENum, String	RegAppStatus, String RegLicStatus, String ResOffNIHK, String RegCom,
			                String OtherRA, String OtherType, String OtherNum, String OtherStatus, String OtherCom,
			                String PaperName, String PaperCom, String ExLicReqCom, String ExamParty, String	ExResult, String ExResitResult, String ExCom,
			                String CessType, String CessLeaveType, String CessReason, String CessStatusUser, String CessComment, String	DocDesc)throws InterruptedException, AWTException {
		// TODO Auto-generated method stub
				
		/* Registration Employee Details*/
		
		driver.findElement(HKRegistrationModule.empDetailsMenu).click();
		driver.findElement(HKRegistrationModule.gender).sendKeys(Gender);
		driver.findElement(HKRegistrationModule.fName).sendKeys(FName);
		driver.findElement(HKRegistrationModule.lName).sendKeys(LName);
		driver.findElement(HKRegistrationModule.typeOfHire).sendKeys(HireType);
		driver.findElement(HKRegistrationModule.empStartDate).click();
		driver.findElement(HKRegistrationModule.dateSelect).click();
		driver.findElement(HKRegistrationModule.corpTitle).sendKeys(CorpTitle);
		driver.findElement(HKRegistrationModule.funTitleOption).sendKeys(FuncTitle);
		driver.findElement(HKRegistrationModule.optionDesc).sendKeys(OptDesc);
		driver.findElement(HKRegistrationModule.sfcRegReq).click();
		permitWait(1);
		driver.findElement(HKRegistrationModule.empDetailsStatus).sendKeys(EmpDetStatus);
		driver.findElement(HKRegistrationModule.regHandBy).sendKeys(RegHandBy);
		driver.findElement(HKRegistrationModule.empDetailscomments).sendKeys(EmpDetComment);
		driver.findElement(HKRegistrationModule.empDetailsSave).click();
		permitWait(2);
		WebElement okButton = driver.findElement(HKRegistrationModule.okClick);
		if(okButton != null){
			okButton.click();
			System.out.println("SFC Employee Details Saved Successfully");
			}
		else{
			System.out.println("Alert! Employee Details Data not Saved");
		    }
		
		//Registration SFC Submission
		driver.findElement(HKRegistrationModule.sfcSubMenu).click();
		permitWait(2);
		driver.findElement(HKRegistrationModule.addSubButton).click();
		permitWait(1);
		driver.findElement(HKRegistrationModule.licenseRole).sendKeys(LicRole);
		driver.findElement(HKRegistrationModule.subType).sendKeys(SubType);
		driver.findElement(HKRegistrationModule.appType).sendKeys(AppType);
		driver.findElement(HKRegistrationModule.appDescAddIcon).click();
		permitWait(2);
		driver.findElement(HKRegistrationModule.raTypeList).sendKeys(RATypeList);
		driver.findElement(HKRegistrationModule.basedOverseas).click();
		driver.findElement(HKRegistrationModule.nomuraList).sendKeys(NMList);
		driver.findElement(HKRegistrationModule.compNoteDate).click();
		driver.findElement(HKRegistrationModule.compNoteDateSelect).click();
		driver.findElement(HKRegistrationModule.restEmailSent).click();
		permitWait(1);
		driver.findElement(HKRegistrationModule.restEmailSentDate).click();
		driver.findElement(HKRegistrationModule.restEmailSentDateSelect).click();
		driver.findElement(HKRegistrationModule.relFormSent).click();
		permitWait(1);
		driver.findElement(HKRegistrationModule.relFormSentDate).click();
		driver.findElement(HKRegistrationModule.relFormSentDateSelect).click();
		permitWait(1);
		driver.findElement(HKRegistrationModule.relFormSentOption).click();
		
		driver.findElement(HKRegistrationModule.relFormRec).click();
		permitWait(1);
		driver.findElement(HKRegistrationModule.relFormRecDate).click();
		driver.findElement(HKRegistrationModule.relFormRecDateSelect).click();
		
		driver.findElement(HKRegistrationModule.suppDocRec).click();
		permitWait(1);
		driver.findElement(HKRegistrationModule.suppDocRecDate).click();
		driver.findElement(HKRegistrationModule.suppDocRecDateSelect).click();
		permitWait(1);
		driver.findElement(HKRegistrationModule.supportDocRecOption).click();
		permitWait(2);
		driver.findElement(HKRegistrationModule.dueDili).click();
		permitWait(2);
		//driver.findElement(RegistrationModule.dueDiliOption).click();
		//permitwait(3);
		//driver.findElement(RegistrationModule.dueDiliDate).click();
		//driver.findElement(RegistrationModule.dueDiliDateSelect).click();
		/*
		driver.findElement(RegistrationModule.signoffROCheck).click();
		permitwait(1);
		driver.findElement(RegistrationModule.roName).sendKeys("somil");
		permitwait(1);
		driver.findElement(RegistrationModule.roName).sendKeys(Keys.DOWN);
		permitwait(1);
		driver.findElement(RegistrationModule.roName).sendKeys(Keys.RETURN);
		permitwait(1);
		driver.findElement(RegistrationModule.signoffAuthCheck).click();
		permitwait(1);
		driver.findElement(RegistrationModule.authName).sendKeys("jayanth");
		permitwait(2);
		driver.findElement(RegistrationModule.authName).sendKeys(Keys.DOWN);
		permitwait(1);
		driver.findElement(RegistrationModule.authName).sendKeys(Keys.RETURN);
		//driver.findElement(RegistrationModule.authSelect).click();
		permitwait(1);
		driver.findElement(RegistrationModule.signoffDirCheck).click();
		permitwait(2);
		driver.findElement(RegistrationModule.dirName).sendKeys("divyang");
		permitwait(2);
		driver.findElement(RegistrationModule.authName).sendKeys(Keys.DOWN);
		permitwait(1);
		driver.findElement(RegistrationModule.authName).sendKeys(Keys.RETURN);
		*/
		//driver.findElement(RegistrationModule.dirSelect).click();
		driver.findElement(HKRegistrationModule.onlineSubDate).click();
		driver.findElement(HKRegistrationModule.onlineSubDateSelect).click();
		driver.findElement(HKRegistrationModule.originalSubDate).click();
		driver.findElement(HKRegistrationModule.OriginalSubDateSelect).click();
		driver.findElement(HKRegistrationModule.appStatus).sendKeys(AppStatus);
		permitWait(2);
		driver.findElement(HKRegistrationModule.sfcAckRec).click();
		permitWait(1);
		driver.findElement(HKRegistrationModule.sfcEnqRaised).click();
		permitWait(2);
		/*
		driver.findElement(RegistrationModule.sfcInfoAddButton).click();
		permitwait(1);
		driver.findElement(RegistrationModule.sfcReqDate).click();
		driver.findElement(RegistrationModule.sfcReqDateSelect).click();
		driver.findElement(RegistrationModule.sfcEnqRaisedInfo).sendKeys("This is Test Information");
		permitwait(2);
		driver.findElement(RegistrationModule.infoSentDate).click();
		permitwait(2);
		driver.findElement(RegistrationModule.infoSendDateSelect).click();
		driver.findElement(RegistrationModule.sfcInfoSaveButton).click();
		permitwait(2);
		driver.findElement(RegistrationModule.okClick).click();
		permitwait(1);
		*/
		driver.findElement(HKRegistrationModule.withdrawInfo).click();
		permitWait(1);
		driver.findElement(HKRegistrationModule.reason).sendKeys(Reason);
		permitWait(1);
		JavascriptExecutor jst = (JavascriptExecutor)driver;
		jst.executeScript("window.scrollBy(0,250)", "");
		permitWait(2);
		driver.findElement(HKRegistrationModule.withdrawDate).click();
		driver.findElement(HKRegistrationModule.withdrawDateSelect).click();
		permitWait(1);
		driver.findElement(HKRegistrationModule.paymentDetails).sendKeys(PayDetails);
		permitWait(2);
		driver.findElement(HKRegistrationModule.paymentDesc).sendKeys(PayDesc);
		driver.findElement(HKRegistrationModule.paymentAmt).sendKeys(PayAmt);
		driver.findElement(HKRegistrationModule.paymentDate).click();
		driver.findElement(HKRegistrationModule.paymentDateSelect).click();
		permitWait(1);
		driver.findElement(HKRegistrationModule.paymentType).sendKeys(PayType);
		driver.findElement(HKRegistrationModule.sfcregHandBy).sendKeys(SFCRegHandBy);
		
		permitWait(2);
		
		/*
		driver.findElement(RegistrationModule.sfcApproveGrantAdd).click();
		permitwait(1);
		driver.findElement(RegistrationModule.sfcAppGrantType).sendKeys("RO Status Granted");
		permitwait(1);
		driver.findElement(RegistrationModule.sfcAppGrantDate).click();
		driver.findElement(RegistrationModule.sfcAppGrantDateSelect).click();
		driver.findElement(RegistrationModule.appNoteSentEmp).sendKeys("Yes");
		permitwait(1);
		driver.findElement(RegistrationModule.noteSentDate).click();
		driver.findElement(RegistrationModule.noteSentDateSelect).click();
		driver.findElement(RegistrationModule.sfcAppletterRec).sendKeys("Yes");
		driver.findElement(RegistrationModule.appLetterRecDate).click();
		driver.findElement(RegistrationModule.appLeteerRecDateSelect).click();
		driver.findElement(RegistrationModule.sfcAppSave).click();
		permitwait(2);
		driver.findElement(RegistrationModule.okClick).click();
		permitwait(1);
		*/
		driver.findElement(HKRegistrationModule.sfcSubComments).sendKeys(SFCComment);
		permitWait(1);
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("window.scrollBy(0,250)", "");
		permitWait(1);
		driver.findElement(HKRegistrationModule.sfcSubSave).click();
		permitWait(3);
		WebElement sfcOk = driver.findElement(HKRegistrationModule.okClick);
		if(sfcOk != null){
			sfcOk.click();
			System.out.println("SFC Employee Details Saved Successfully");
			}
		else{
			System.out.println("Alert! Employee Details Data not Saved");
			}

		/* SFC Registration Details*/
	
		driver.findElement(HKRegistrationModule.sfcRegMenu).click();
		permitWait(2);
		driver.findElement(HKRegistrationModule.addNewRegDetails).click();
		permitWait(1);
		driver.findElement(HKRegistrationModule.entCENumber).sendKeys(EntCE);
		permitWait(1);
		driver.findElement(HKRegistrationModule.regRAType).sendKeys(RegRAType);
		driver.findElement(HKRegistrationModule.regLicenseRole).sendKeys(RegLicRole);
		driver.findElement(HKRegistrationModule.regDate).click();
		driver.findElement(HKRegistrationModule.regDateSelect).click();
		driver.findElement(HKRegistrationModule.regCessationDate).click();
		driver.findElement(HKRegistrationModule.regCessationDateSelect).click();
		driver.findElement(HKRegistrationModule.sfcSubmission).sendKeys(SfcSub);
		driver.findElement(HKRegistrationModule.regTableSave).click();
		permitWait(2);
		driver.findElement(HKRegistrationModule.regTableOKButton).click();
		permitWait(2);
		driver.findElement(HKRegistrationModule.regLicCat).sendKeys(RegLicCat);
		driver.findElement(HKRegistrationModule.regCENum).sendKeys(RegCENum);
		driver.findElement(HKRegistrationModule.regLicDate).click();
		driver.findElement(HKRegistrationModule.regLicDateSelect).click();
		driver.findElement(HKRegistrationModule.regAppStatus).sendKeys(RegAppStatus);
		driver.findElement(HKRegistrationModule.regLicStatus).sendKeys(RegLicStatus);
		driver.findElement(HKRegistrationModule.resOfficerNIHK).sendKeys(ResOffNIHK);
		driver.findElement(HKRegistrationModule.regComment).sendKeys(RegCom);
		permitWait(1);
		driver.findElement(HKRegistrationModule.regSave).click();
		permitWait(2);
			
		WebElement regFinalOk = driver.findElement(HKRegistrationModule.regOKButton);
		if(regFinalOk != null){
			regFinalOk.click();
			System.out.println("SFC Registration Details Saved Successfully");
			}
		else{
			System.out.println("Alert! SFC Registration Details Data not Saved");
			}
		
		
		/* Other Registration*/
		
		driver.findElement(HKRegistrationModule.othRegMenu).click();
		permitWait(2);
		driver.findElement(HKRegistrationModule.othRegAdd).click();
		permitWait(1);
		driver.findElement(HKRegistrationModule.othRegRA).sendKeys(OtherRA);
		driver.findElement(HKRegistrationModule.othRegType).sendKeys(OtherType);
		driver.findElement(HKRegistrationModule.othRegNum).sendKeys(OtherNum);
		driver.findElement(HKRegistrationModule.othRegSubDate).click();
		driver.findElement(HKRegistrationModule.othRegSubDateSelect).click();
		driver.findElement(HKRegistrationModule.othRegDate).click();
		driver.findElement(HKRegistrationModule.othRegDateSelect).click();
		driver.findElement(HKRegistrationModule.othRegCessDate).click();
		driver.findElement(HKRegistrationModule.othRegCessDateSelect).click();
		driver.findElement(HKRegistrationModule.othRegStatus).sendKeys(OtherStatus);
		driver.findElement(HKRegistrationModule.othRegComments).sendKeys(OtherCom);
		driver.findElement(HKRegistrationModule.othRegSave).click();
		permitWait(2);
		WebElement otheRegFinalOk = driver.findElement(HKRegistrationModule.othRegOKButton);
		if(otheRegFinalOk != null){
			otheRegFinalOk.click();
			System.out.println("Other Registration Details Saved Successfully");
			}
		else{
			System.out.println("Alert! Other Registration Details Data not Saved");
			}
		
	
		/* Exams */
		
		driver.findElement(HKRegistrationModule.examMenu).click();
		permitWait(3);
		driver.findElement(HKRegistrationModule.exAdd).click();
		permitWait(2);
		driver.findElement(HKRegistrationModule.exPName).sendKeys(PaperName);
		driver.findElement(HKRegistrationModule.exPComments).sendKeys(PaperCom);
		driver.findElement(HKRegistrationModule.exCompPass).click();
		permitWait(1);
		driver.findElement(HKRegistrationModule.exLicDeadDate).click();
		driver.findElement(HKRegistrationModule.exLicDeadDateSelect).click();
		driver.findElement(HKRegistrationModule.exExtLicReq).click();
		permitWait(1);
		driver.findElement(HKRegistrationModule.exExtLicReqComment).sendKeys(ExLicReqCom);
		driver.findElement(HKRegistrationModule.exExtGrantSFC).click();
		permitWait(1);
		driver.findElement(HKRegistrationModule.exExtGrantSDate).click();
		driver.findElement(HKRegistrationModule.exExtGrantSDateSelect).click();
		driver.findElement(HKRegistrationModule.exExtGrantEDate).click();
		driver.findElement(HKRegistrationModule.exExtGrantEDateSelect).click();
		driver.findElement(HKRegistrationModule.exReminderEmail).click();
		permitWait(1);
		driver.findElement(HKRegistrationModule.exOtherParties).sendKeys(ExamParty);
		permitWait(1);
		driver.findElement(HKRegistrationModule.exOtherParties).sendKeys(Keys.DOWN);
		permitWait(1);
		driver.findElement(HKRegistrationModule.exOtherParties).sendKeys(Keys.RETURN);
		permitWait(1);
		//driver.findElement(RegistrationModule.exOtherPartiesSelect).click();
		driver.findElement(HKRegistrationModule.exExamExmpt).click();
		permitWait(1);
		driver.findElement(HKRegistrationModule.exDeadlineDate).click();
		driver.findElement(HKRegistrationModule.exDeadlineDateSelect).click();
		driver.findElement(HKRegistrationModule.exDate).click();
		driver.findElement(HKRegistrationModule.exDateSelect).click();
		driver.findElement(HKRegistrationModule.exResult).sendKeys(ExResult);
		permitWait(1);
		driver.findElement(HKRegistrationModule.exResitDate).click();
		driver.findElement(HKRegistrationModule.exResitDateSelect).click();
		driver.findElement(HKRegistrationModule.exResitResult).sendKeys(ExResitResult);
		driver.findElement(HKRegistrationModule.exPSave).click();
		permitWait(2);
		WebElement examOK1 = driver.findElement(HKRegistrationModule.exOKButton1);
		if(examOK1 != null){
			examOK1.click();
			System.out.println("Exam Data Saved Successfully");
			}
		else{
			System.out.println("Alert! Exam Data not Saved");
			}
		permitWait(2);
		JavascriptExecutor jsp = (JavascriptExecutor)driver;
		jsp.executeScript("window.scrollBy(0,250)", "");
		
		driver.findElement(HKRegistrationModule.exComments).sendKeys(ExCom);
		
		driver.findElement(HKRegistrationModule.exSave).click();
		permitWait(2);
		WebElement examOK2 = driver.findElement(HKRegistrationModule.exOKButton2);
		if(examOK2 != null){
			examOK2.click();
			System.out.println("SFC Exam details saved successfully");
			}
		else{
			System.out.println("Alert! SFC Exam details not Saved");
			}
		
		
		/*Cessation Details*/
		
		driver.findElement(HKRegistrationModule.cessMenu).click();
		permitWait(3);
		driver.findElement(HKRegistrationModule.cessNotType).sendKeys(CessType);
		driver.findElement(HKRegistrationModule.cessNotRecDate).click();
		driver.findElement(HKRegistrationModule.cessNotRecDateSelect).click();
		driver.findElement(HKRegistrationModule.cessLastDate).click();
		driver.findElement(HKRegistrationModule.cessLastDateSelect).click();
		driver.findElement(HKRegistrationModule.cessTermDate).click();
		driver.findElement(HKRegistrationModule.cessTermDateSelect).click();
		driver.findElement(HKRegistrationModule.cessLeaverType).sendKeys(CessLeaveType);
		driver.findElement(HKRegistrationModule.cessReason).sendKeys("Resignation");
		driver.findElement(HKRegistrationModule.cessWithSFC).click();
		driver.findElement(HKRegistrationModule.cessEditIcon).click();
		permitWait(2);
		driver.findElement(HKRegistrationModule.cessDate).click();
		driver.findElement(HKRegistrationModule.cessDateSelect).click();
		permitWait(1);
		JavascriptExecutor jsk = (JavascriptExecutor)driver;
		jsk.executeScript("window.scrollBy(0,250)", "");
		permitWait(1);
		
		driver.findElement(HKRegistrationModule.cessEditSave).click();
		permitWait(2);
				
		WebElement cessOk1 = driver.findElement(HKRegistrationModule.cessEditOk);
		if(cessOk1 != null){
			cessOk1.click();
			System.out.println("Cessation Data Saved Successfully");
			}
		else{
			System.out.println("Alert! Cessation Data Not Saved");
			}
		
		permitWait(1);
		driver.findElement(HKRegistrationModule.cessFormStatus).click();
		driver.findElement(HKRegistrationModule.cessFormStatusUser).sendKeys(CessStatusUser);
		permitWait(1);
		driver.findElement(HKRegistrationModule.cessFormStatusUser).sendKeys(Keys.DOWN);
		permitWait(1);
		driver.findElement(HKRegistrationModule.cessFormStatusUser).sendKeys(Keys.RETURN);
		driver.findElement(HKRegistrationModule.cessFormSubDate).click();
		driver.findElement(HKRegistrationModule.cessForSubDateSelect).click();
		permitWait(1);
		
		
		driver.findElement(HKRegistrationModule.cessStatus).sendKeys("Completed");
		driver.findElement(HKRegistrationModule.cessSFCRevokDate).click();
		driver.findElement(HKRegistrationModule.cessSFCRevokDateSelect).click();
		driver.findElement(HKRegistrationModule.cessComments).sendKeys("Test Cessation Details");
		driver.findElement(HKRegistrationModule.cessSave).click();
		permitWait(2);
		WebElement cessOk2 = driver.findElement(HKRegistrationModule.cessOkButton);
		if(cessOk2 != null){
			cessOk2.click();
			System.out.println("Cessation Details Saved Successfully");
			}
		else{
			System.out.println("Alert! Cessation Details Not Saved");
			}
		
		
		
		/*Document*/
		
		driver.findElement(HKRegistrationModule.docMenu).click();
		permitWait(2);
		driver.findElement(HKRegistrationModule.docAddNew).click();
		permitWait(1);
			
		String sel = "H:\\Sample Docs\\SampleText.txt";
		driver.findElement(HKRegistrationModule.docSelectFile).click();
		 
		robotclass(sel);
		
		
		permitWait(1);
		driver.findElement(HKRegistrationModule.docDescription).sendKeys(DocDesc);
		driver.findElement(HKRegistrationModule.docDate).click();
		driver.findElement(HKRegistrationModule.docDateSelect).click();
		driver.findElement(HKRegistrationModule.docupload).click();
		permitWait(5);
		WebElement docOk = driver.findElement(HKRegistrationModule.docOkbutton);
		if(docOk != null){
			docOk.click();
			System.out.println("Document Uploaded Successfully");
			}
		else{
			System.out.println("Alert! Document Not Uploaded Successfully");
			}
    
	}
	private static void robotclass(String sel) throws InterruptedException, AWTException {
		StringSelection selection = new StringSelection(sel);
		System.out.println("File path ---> "+selection);
		permitWait(1);
		java.awt.Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection,null);
		permitWait(1);
		Robot robot = new Robot(); 
		permitWait(1);
		robot.keyPress(KeyEvent.VK_ENTER);
		permitWait(1);
		robot.keyRelease(KeyEvent.VK_ENTER);
		permitWait(1);
		robot.keyPress(KeyEvent.VK_CONTROL);
		permitWait(1);
		robot.keyPress(KeyEvent.VK_V);
		permitWait(1);
		// Release CTRL+V
		robot.keyRelease(KeyEvent.VK_CONTROL);
		permitWait(1);
		robot.keyRelease(KeyEvent.VK_V);
		permitWait(1);
		robot.keyPress(KeyEvent.VK_ENTER);
		permitWait(1);
		robot.keyRelease(KeyEvent.VK_ENTER);
		permitWait(1);
	}
@BeforeTest
	public void beforeTest() throws InterruptedException
	{
	OpenBrowser();
	permitWait(3);
	
	/* Registration Employee Details*/
	driver.findElement(HKRegistrationModule.regMenu).click();
	permitWait(2);
	driver.findElement(SGRegistrationModule.regulator).sendKeys("SFC");
	permitWait(1);
	driver.findElement(HKRegistrationModule.searchEmp).sendKeys("Amol Chande");
	permitWait(2);
	driver.findElement(HKRegistrationModule.selectEmp).click();
	permitWait(4);
	}
@AfterTest
public void afterTest() 
{
	//driver.quit();
}
}

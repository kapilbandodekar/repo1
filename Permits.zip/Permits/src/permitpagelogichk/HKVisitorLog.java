package permitpagelogichk;

import java.awt.AWTException;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import utils.ReusableMethods;
import utils.StaticProvider;
import permitpageelementshk.VisitorLogHK;

public class HKVisitorLog extends ReusableMethods{
	@Test(dataProvider = "HKVisitorLog", dataProviderClass = StaticProvider.class)
	public static void main(String Vname,String	ROfficerNIHK, String TeamMember, String	LICStatus, String HomeContact, String HKContact, String OtherPartyTo, String OtherPartyCc) throws InterruptedException, AWTException {
	driver.findElement(VisitorLogHK.addNewVisit).click();
	permitWait(3);
	driver.findElement(VisitorLogHK.visitorName).sendKeys(Vname);
	permitWait(2);
	driver.findElement(VisitorLogHK.visitorName).sendKeys(Keys.DOWN);
	driver.findElement(VisitorLogHK.visitorName).sendKeys(Keys.RETURN);
	permitWait(1);
	driver.findElement(VisitorLogHK.visitFromDate).click();
	driver.findElement(VisitorLogHK.visitFromDateSelect).click();
	driver.findElement(VisitorLogHK.visitToDate).click();
	driver.findElement(VisitorLogHK.visitToDateSelect).click();
	permitWait(1);
	driver.findElement(VisitorLogHK.roNIHK).sendKeys(ROfficerNIHK);
	driver.findElement(VisitorLogHK.teamMemberNIHK).sendKeys(TeamMember);
	permitWait(1);
	driver.findElement(VisitorLogHK.teamMemberNIHK).sendKeys(Keys.DOWN);
	driver.findElement(VisitorLogHK.teamMemberNIHK).sendKeys(Keys.RETURN);
	driver.findElement(VisitorLogHK.licStatus).sendKeys(LICStatus);
	driver.findElement(VisitorLogHK.contactPersonHome).sendKeys(HomeContact);
	permitWait(1);
	driver.findElement(VisitorLogHK.contactPersonHome).sendKeys(Keys.DOWN);
	driver.findElement(VisitorLogHK.contactPersonHome).sendKeys(Keys.RETURN);
	driver.findElement(VisitorLogHK.contactPersonHK).sendKeys(HKContact);
	permitWait(1);
	driver.findElement(VisitorLogHK.contactPersonHK).sendKeys(Keys.DOWN);
	driver.findElement(VisitorLogHK.contactPersonHK).sendKeys(Keys.RETURN);
	driver.findElement(VisitorLogHK.otherPartiesTO).sendKeys(OtherPartyTo);
	permitWait(1);
	driver.findElement(VisitorLogHK.otherPartiesTO).sendKeys(Keys.DOWN);
	driver.findElement(VisitorLogHK.otherPartiesTO).sendKeys(Keys.RETURN);
	driver.findElement(VisitorLogHK.otherPartiesCC).sendKeys(OtherPartyCc);
	permitWait(1);
	driver.findElement(VisitorLogHK.vlSubmit).click();
	permitWait(3);
	WebElement visitOk = driver.findElement(VisitorLogHK.vlOkButton);
	if(visitOk != null){
		visitOk.click();
		System.out.println("Visit Details Saved Successfully");
		}
	else{
		System.out.println("Alert! Visit Details not Saved");
		}
	
	
	permitWait(1);
	}
	@BeforeTest
	public void beforeTest() throws InterruptedException
	{
		OpenBrowser();
		permitWait(2);
		driver.findElement(VisitorLogHK.visitLogMenuHK).click();
		driver.findElement(VisitorLogHK.visitLogNIHKMenu).click();
		driver.navigate().to("http://int-intranet.nomuranow.com/CMPL/REG/#/sfcVisitorLogDet");
		permitWait(2);
    }
	@AfterTest
	public void afterTest() 
	{
		//driver.quit();
	}
}

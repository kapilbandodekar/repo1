package permitpageelementssg;

import org.openqa.selenium.By;

public class MasEaPo {

	public static By masEAPOMenu = By.xpath("html/body/div[2]/div/div[1]/nav/div/ul/li[4]/a");
	public static By addNametab = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div/ul/li[1]/a");
	public static By firstName = By.id("firstname");
	public static By middleName = By.id("middlename");
	public static By lastName = By.id("lastname");
	public static By alias = By.id("othername");
	public static By nomuraUID = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div/div[1]/div/div[2]/form/div[5]/div/input");
	public static By addNameSave = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div/div[1]/div/div[2]/form/div[6]/div/button[1]");
	public static By addNameOk = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	
	public static By enfoActionTab = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div/ul/li[2]/a");
	public static By enfoActSearchName = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div/div[2]/div/div[2]/div[1]/form/div/div/input");
	public static By enfoActregulator = By.id("regulator");
	public static By enfoActionDate = By.id("dateOfEnforcement");
	public static By enfoActionDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[3]/a");
	public static By enfoActionDetails = By.id("detailsOfEnforcement");
	public static By enfoActionLink = By.id("enforcementLink");
	public static By enfoActionSave = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div/div[2]/div/div[2]/div[2]/form/div[6]/div/button[1]");
	public static By enforActionOk = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	
	public static By proOrderTab = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div/ul/li[3]/a");
	public static By proOrderSearchName = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div/div[3]/div/div[2]/div[1]/form/div/div/input");
	public static By proOrderRegulator = By.id("prohibitionRegulator");
	public static By proOrderDate = By.id("dateOfProhibition");
	public static By proOrderDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[4]/a");
	public static By proOrderNRIC = By.id("nricPassportFinProhibition");
	public static By proOrderEffectDate = By.id("effectiveDateOfProhibition");
	public static By proOrderEffectDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[5]/a");
	public static By proOrderEndDate = By.id("endDateOfProhibition");
	public static By proOrderEndDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[4]/td[2]/a");
	public static By proOrderDuration = By.id("durationOfProhibition");
	public static By proOrderDetails = By.id("detailsOfProhibition");
	public static By proOrderLink = By.id("prohibitionLink");
	public static By proOrderSave = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div/div[3]/div/div[2]/div[2]/form/div[10]/div/button[1]");
	public static By proOrderOk = By.xpath("html/body/div[1]/div/div/div/div[3]/button");

	
}

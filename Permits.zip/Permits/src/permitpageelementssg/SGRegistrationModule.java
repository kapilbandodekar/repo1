package permitpageelementssg;

import org.openqa.selenium.By;

public class SGRegistrationModule {
	
	public static By spoof = By.xpath("html/body/div[1]/div/div/div[2]/div[2]/ul/li[3]/a/span");
	public static By searchUser = By.xpath("html/body/div[1]/div/div/div/div[2]/input");
	public static By selectUser = By.xpath("html/body/div[1]/div/div/div/div[2]/ul/li[1]");
	public static By regMainMenu = By.xpath("html/body/div[2]/div/div[1]/nav/div/ul/li[2]/a");
	public static By searchEmp = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[1]/div[2]/div/div/div[1]/table/tbody/tr[1]/td[2]/input");
	public static By regulator = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[1]/div[2]/div/div/div[1]/table/tbody/tr[1]/td[3]/select");
	
	//Employee Details
	public static By empDetailstab = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/ul/li[2]/a");
	public static By cessationDate = By.id("cessationDate");
	public static By cessationDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[3]/a");
	public static By nameNRIC = By.id("passportName");
	public static By dobDate = By.id("dob");
	public static By dobDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[5]/a");
	public static By genderRadio = By.cssSelector("input[name='gender'][value='M']");
	public static By typeOfHire = By.id("hireType");
	public static By nationality = By.cssSelector("input[name='nationality'][value='Singapore Citizen']");
	public static By nricNo = By.id("nricNo");
	public static By passportNo = By.id("passportNo");
	public static By finNo = By.id("finNo");
	public static By basedOverseas = By.cssSelector("input[name='basedOverseas'][value='Y']");
	public static By address1 = By.id("address1");
	public static By address2 = By.id("address2");
	public static By postCodeSG = By.id("sgPostalCode");
	public static By emailAddress = By.id("emailId");
	public static By contactHome = By.id("homeContactNo");
	public static By contactMobile = By.id("mobileNo");
	public static By compNotiDate = By.id("companyNotifiedDate");
	public static By compNotiDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[5]/a");
	public static By rnfRegistration = By.cssSelector("input[name='rnfRegistrationRequired'][value='Y']");
	public static By uniqueRegSelect = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[2]/div/form/div[20]/div/table/tbody/tr[1]/td[1]/label/input");
	public static By spouseRadio = By.cssSelector("input[Name='haveSpouse'][value='N']");
	public static By comments = By.cssSelector("textarea[name='empDetTabComments']");
	public static By empDetailsSave = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[2]/div/form/div[26]/div/button");
	public static By empDetailsOk = By.xpath("html/body/div[1]/div/div/div/div[3]/button");

	//Outside Business
	public static By obiTab = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/ul/li[3]/a");
	public static By addNewOBI1 = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/button[1]");
	public static By entityName1 = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[1]/div/input");
	public static By placeOfIncorp1 = By.cssSelector("input[name='incPlace']");
	public static By natureOfBusiness1 = By.cssSelector("input[name='businessNature']");
	public static By businessInterests = By.cssSelector("input[name='businessInterest']");
	public static By acqBusinessDate = By.id("businessInterestAcqDate");
	public static By acqBusinessDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[3]/td[4]/a");
	public static By cessBusinessDate = By.id("businessCessIntrDate");
	public static By cessBusinessDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[4]/td[3]/a");
	public static By saveOBI1 = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[7]/div/button[1]");
	public static By obiOkButton1 = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	public static By addNewOBI2 = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/button[2]");
	public static By entityName2 = By.cssSelector("input[name='obiEntityName']");
	public static By placeOfIncorp2 = By.cssSelector("input[name='obiIncPlace']");
	public static By natureOfBusiness2 = By.cssSelector("input[name='obiBusinessNature']");
	public static By obiFromDate = By.id("obiFromDate");
	public static By obiFromDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[3]/a");
	public static By obiToDate = By.id("obiToDate");
	public static By obiToDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[4]/td[4]/a");
	public static By percentageInEntity = By.cssSelector("input[name='obiPercentShare']");
	public static By saveOBI2 = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[4]/form/div[7]/div/button[1]");
	public static By obiOkButton2 = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	public static By obiComments = By.cssSelector("textarea[name='OBTabcomments']");
	public static By obiSave = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/form/div[2]/div/button");
	public static By obiOkButton = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	
	//RNF Registration
	public static By rnfTab = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/ul/li[4]/a");
	public static By addNewREGDetails = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[4]/div/button[1]");
	public static By typeOfRA = By.id("raType");
	public static By regDate = By.id("regDateRnf");
	public static By regDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[4]/a");
	public static By cessDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[4]/div/div[4]/form/div[3]/div/input");
	public static By cessDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[3]/td[2]/a");
	public static By rnfComment1= By.cssSelector("input[name='regDetComments']");
	public static By rnfSave1 = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[4]/div/div[4]/form/div[5]/div/button[1]");
	public static By rnfOkButton1 = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	public static By rnfClose1 = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[4]/div/div[4]/form/div[5]/div/button[3]");
	public static By addNewCerDetails = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[4]/div/button[2]");
	public static By cerDescription = By.id("certDescription");
	public static By passDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[4]/div/div[6]/form/div[3]/div/input");
	public static By passDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[4]/a");
	public static By expireDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[4]/div/div[6]/form/div[4]/div/input");
	public static By expireDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[4]/td[3]/a");
	public static By rnfRemark = By.cssSelector("input[name='remarks']");
	public static By rnfSave2 = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[4]/div/div[6]/form/div[6]/div/button[1]");
	public static By rnfOkButton2 = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	public static By rnfClose2 = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[4]/div/div[6]/form/div[6]/div/button[3]");
	public static By rnfNo = By.id("rnfNo");
	public static By rnfSubDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[4]/div/form/div[2]/div/input");
	public static By rnfSubDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[4]/td[2]/a");
	public static By rnfAppointDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[4]/div/form/div[3]/div/input");
	public static By rnfAppointDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[4]/td[5]/a");
	public static By licenseType = By.id("licenseType");
	public static By licenseStatus = By.id("licStatusId"); 
	public static By rnfSave = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[4]/div/form/div[7]/div/button");
	public static By rnfComments = By.cssSelector("textarea[name='regTabComments']");
	public static By rnfOkButton = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	
	//Other Registration
	public static By othRegTab = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/ul/li[5]/a");
	public static By addNewOthReg = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[5]/div/button");
	public static By regauthority = By.id("otherRegAutority");
	public static By regtype = By.id("otherRegType");
	public static By regNo = By.cssSelector("input[name='otherRegNo']");
	public static By subDate = By.id("submissionDateOther");
	public static By subDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[4]/a");
	public static By othRegDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[5]/div/div[2]/form/div[7]/div/input");
	public static By othRegDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[4]/td[2]/a");
	public static By othRegStatus = By.cssSelector("input[name='otherRegsStatus']");
	public static By othRegComments1 = By.cssSelector("input[name='otherRegDetComments']");
	public static By othRegSave1 = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[5]/div/div[2]/form/div[10]/div/button[1]");
	public static By othRegOkButton1 = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	public static By othRegClose = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[5]/div/div[2]/form/div[10]/div/button[3]");
	public static By othRegLicStatus = By.id("otherLicStatusId");
	public static By othRegComments2= By.cssSelector("textarea[name='otherRegTabcomments']");
	public static By othRegSave2 = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[5]/div/form/div[3]/div/button");
	public static By othRegOkButton2 = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	
	//Breach_Misconduct_Fit&Proper
	public static By brMisTab = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/ul/li[6]/a");
	public static By breachType = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[6]/div/uib-accordion/div/div[1]/div[2]/div/div[1]/div/select");
	public static By brIncidentDate = By.id("incidentDateGE");
	public static By brIncidentDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[1]/a");
	public static By brDate = By.id("dateOfBreachGE");
	public static By brDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[3]/td[3]/a");
	public static By brDetails = By.id("detailsOfBreachGE");
	public static By brDisAction = By.id("disciplinaryActionBreachGE");
	public static By brDisActDate = By.id("dateOfDisplinaryActionGE");
	public static By brDisActDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[4]/td[2]/a");
	public static By brComments = By.id("commentsGE");
	public static By brSave = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[6]/div/uib-accordion/div/div[1]/div[2]/div/form[1]/div/div[7]/div/button[1]");
	public static By brOkButton = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	
	public static By misAccordion = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[6]/div/uib-accordion/div/div[2]/div[1]");
	public static By misIncDesc = By.id("incidentDescriptionMisconduct");
	public static By misIncDate = By.id("incidentDateMisconduct");
	public static By misIncDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[3]/a");
	public static By misDetails = By.id("detailsOfMisconduct");
	public static By misDicAction = By.id("disciplinaryActionMisconduct");
	public static By misReportToReg = By.cssSelector("input[name='138'][value='Y']");
	public static By misRepToRegDate = By.id("reportedDateMisconduct");
	public static By misRepToRegDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[4]/td[3]/a");
	public static By misRemarks = By.id("misconductComments");
	public static By misSave = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[6]/div/uib-accordion/div/div[2]/div[2]/div/div/form/div[8]/div/button[1]");
	public static By misOkButton = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	
	public static By fitAccordion = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[6]/div/uib-accordion/div/div[3]/div[1]");
	public static By fitIncDescription = By.id("incidentDescriptionFitProper");
	public static By fitIncDate = By.id("incidentDateFitProper");
	public static By fitIncDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[3]/td[3]/a");
	public static By fitIncDetails = By.id("detailsOfFitNProper");
	public static By fitDisAction = By.id("disciplinaryActionFitProper");
	public static By fitIncType = By.cssSelector("input[name='146'][value='EXT']");
	public static By fitExtIncDetails = By.id("extIncidentFitProper");
	public static By fitReportToReg = By.cssSelector("input[name='147'][value='Y']");
	public static By fitRepToRegDate = By.id("reportedDateFitProper");
	public static By fitRepToRegDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[4]/td[2]/a");
	public static By fitComments = By.id("commentsFitProper");
	public static By fitSave = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[6]/div/uib-accordion/div/div[3]/div[2]/div/div/form/div[10]/div/button[1]");
	public static By fitOkButton = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
			
	//Documents
	public static By docMenu = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/ul/li[7]/a");
	public static By docAddNew = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/div[3]/button");
	public static By docSelectFile = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/div[3]/div/form/div[1]/div/div/span/label"); 
	//public static By docDescription = By.cssSelector("input[name='documentDesc']");
	public static By docDescription = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/div[3]/div/form/div[2]/div/input");
	public static By docDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/div[3]/div/form/div[3]/div/input");
	public static By docDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[3]/a");
	public static By docupload = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/div[3]/div/form/div[4]/div/button[1]");
	public static By docOkbutton =  By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	
	
}

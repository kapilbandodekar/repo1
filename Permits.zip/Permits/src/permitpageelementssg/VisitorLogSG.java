package permitpageelementssg;

import org.openqa.selenium.By;

public class VisitorLogSG {

	public static By vLogMainMenu = By.xpath("html/body/div[2]/div/div[1]/nav/div/ul/li[6]/a");
	public static By  myVLMenu = By.xpath("html/body/div[2]/div/div[1]/nav/div/ul/li[6]/ul/li[1]/a");
	public static By addNewVisit = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/button");
	public static By nameOfVisitor = By.cssSelector("input[name='visitorName']"); 
	public static By visitDateFrom = By.id("visitDateFrom");
	public static By visitDateFromSelect = By.xpath("html/body/div[6]/table/tbody/tr[3]/td[2]/a");
	public static By visitDateTo = By.id("visitDateTo");
	public static By visitDateToSelect =  By.xpath("html/body/div[6]/table/tbody/tr[4]/td[2]/a");
	public static By highestEduQualification = By.id("educationQualification");
	public static By internalMeeting = By.cssSelector("input[name='internalMeeting'][value='Y']");
	public static By externalMeeting = By.cssSelector("input[name='externalMeeting'][value='Y']");
	public static By conductRAActivity = By.cssSelector("input[name='tradeDeal'][value='Y']");
	public static By roTradeStartDate = By.xpath("html/body/div[1]/div/div/div/div[2]/form/div[12]/div[2]/table/tbody/tr/td[2]/div/input");
	public static By roTradeStartDateSelect = By.xpath("html/body/div[6]/table/tbody/tr[3]/td[5]/a");
	public static By roTradeEndDate = By.xpath("html/body/div[1]/div/div/div/div[2]/form/div[12]/div[2]/table/tbody/tr/td[3]/div/input");
	public static By roTradeEndDateSelect = By.xpath("html/body/div[6]/table/tbody/tr[3]/td[7]/a");
	public static By sgChairPerson = By.cssSelector("input[name='sgChPerson']");
	public static By teamMemberAddIcon = By.xpath("html/body/div[1]/div/div/div/div[2]/form/div[16]/div/table/thead/tr[1]/th/span");
	public static By teamMemberSearch = By.xpath("html/body/div[1]/div/div/div/div[2]/form/div[16]/div/table/tbody/tr/td[2]/input");
	public static By licenseHome = By.cssSelector("input[name='homeCountryLicense'][value='Y']");
	public static By licenseEntity = By.id("licenseEntity");
	public static By selectLicenseChkbox = By.xpath("html/body/div[1]/div/div/div/div[2]/form/div[19]/div/table/tbody/tr[1]/td/label/input");
	public static By contactPersonHome = By.cssSelector("input[name='contactPerHome'");
	public static By contactPersonSG = By.cssSelector("input[name='contactPerSG']");
	public static By otherDetails = By.cssSelector("input[name='otherDetails']");
	public static By Submit = By.xpath("html/body/div[1]/div/div/div/div[3]/button[2]");
	public static By Save = By.xpath("html/body/div[1]/div/div/div/div[3]/button[1]");
	public static By vlSGOkButton = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	
}

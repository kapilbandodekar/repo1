package permitpageelementsaej;

import org.openqa.selenium.By;

public class OJKRegistrationModule {

	
	public static By spoof = By.xpath("html/body/div[1]/div/div/div[2]/div[2]/ul/li[3]/a/span");
	public static By searchUser = By.xpath("html/body/div[1]/div/div/div/div[2]/input");
	public static By selectUser = By.xpath("html/body/div[1]/div/div/div/div[2]/ul/li[1]");
	public static By regMainMenu = By.xpath("html/body/div[2]/div/div[1]/nav/div/ul/li[2]/a");
	public static By searchEmp = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[1]/div[2]/div/div/div[1]/table/tbody/tr[1]/td[2]/input");
	public static By regulator = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[1]/div[2]/div/div/div[1]/table/tbody/tr[1]/td[3]/select");

	//Employee Details
	public static By empDetailsTab = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/ul/li[2]/a");
	public static By nameTitle = By.id("salutation");
	public static By nameLName = By.name("ojkLastName");
	public static By nameFName = By.name("ojkFirstName");
	public static By dob = By.id("ojkBirthDate");
	public static By dobSelect = By.xpath("/html/body/div[4]/table/tbody/tr[3]/td[2]/a");
	                                       //html/body/div[4]/table/tbody/tr[3]/td[2]/a
	public static By passportNo = By.name("ojkPassportNumber");
	public static By empDetailsComment = By.name("ojkEmpDetailsTabComments");
	public static By empDetailsSave = By.xpath("/html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[2]/div/form/div[7]/div/button");
	
	public static By empDetailsOk = By.xpath("html/body/div[1]/div/div/div/div[3]/button"); 
	
	//OJK Registration
	public static By ojkRegTab = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/ul/li[3]/a");
	public static By ojkRegAddNew = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/button");
	public static By licenseNo = By.id("ojkLicenseNumber");
	public static By raType = By.id("ojkRaType");
	public static By licRole = By.id("ojkLicenseRole");
	public static By ojkRegDate = By.id("ojkRegDate");
	public static By ojkRegDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[2]/a");
	public static By ojkExpiryDate = By.id("ojkExpiryDate");
	public static By ojkExpiryDateSelect = By.xpath("/html/body/div[4]/table/tbody/tr[3]/td[2]/a");
	public static By ojkRenewalDate = By.id("ojkRenewalDate");
	public static By ojkRenewalDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[3]/td[5]/a");
	public static By ojkRegComment = By.name("ojkRegTabComments");
	public static By ojkSave = By.xpath("/html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[8]/div/button[1]");
	public static By ojkOkButton = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	
	//OJK Document Documents
	public static By docMenu = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/ul/li[7]/a");
	public static By docAddNew = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/div[3]/button");
	public static By docSelectFile = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/div[3]/div/form/div[1]/div/div/span/label"); 
	//public static By docDescription = By.cssSelector("input[name='documentDesc']");
	public static By docDescription = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/div[3]/div/form/div[2]/div/input");
	public static By docDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/div[3]/div/form/div[3]/div/input");
	public static By docDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[3]/a");
	public static By docupload = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/div[3]/div/form/div[4]/div/button[1]");
	public static By docOkbutton =  By.xpath("html/body/div[1]/div/div/div/div[3]/button");
}

package permitpageelementsaej;

import org.openqa.selenium.By;

public class SEBIRegistrationModule {

	public static By spoof = By.xpath("/html/body/div[1]/div/div/div[2]/div[2]/ul/li[3]/a/span");										
	public static By searchUser = By.xpath("html/body/div[1]/div/div/div/div[2]/input");
	public static By selectUser = By.xpath("html/body/div[1]/div/div/div/div[2]/ul/li[1]");
	public static By regMainMenu = By.xpath("html/body/div[2]/div/div[1]/nav/div/ul/li[2]/a");
	public static By searchEmp = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[1]/div[2]/div/div/div[1]/table/tbody/tr[1]/td[2]/input");
	public static By regulator = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[1]/div[2]/div/div/div[1]/table/tbody/tr[1]/td[3]/select");

	
	//Employee Details
	
	public static By empDetailsTab = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/ul/li[2]/a");
	public static By nameTitle = By.id("salutation");
	public static By nameLName = By.name("sebiLastName");
	public static By nameFName = By.name("sebiFirstName");
	public static By dob = By.id("sebiBirthDate");
	public static By dobSelect = By.xpath("/html/body/div[4]/table/tbody/tr[3]/td[2]/a");
	public static By passportNo = By.name("sebiPassportNumber");
	public static By panNo = By.name("sebiPanNumber");
	public static By buDescription = By.name("sebiBUDesc");
	public static By empDetailsComment = By.name("sebiEmpDetailsTabComments");
	public static By empDetailsSave = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[2]/div/form/div[9]/div/button");
	public static By empDetailsOk = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	
	//SEBI Registration
	public static By sebiRegTab = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/ul/li[3]/a");
	public static By sebiRegAddNew = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/button");
	public static By licenseNo = By.id("sebiLicenseNumber");
	public static By raType = By.id("sebiRaType");
	public static By sebiRegDate = By.id("sebiRegDate");
	public static By sebiRegDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[2]/a");
	public static By sebiCessDate = By.id("sebiCessationDate");
	public static By sebiCessDateSelect = By.xpath("/html/body/div[4]/table/tbody/tr[5]/td[4]/a");
	public static By sebiRenewalDate = By.id("sebiRenewalDate");
	public static By sebiRenewalDateSelect = By.xpath("/html/body/div[4]/table/tbody/tr[5]/td[3]/a");
	public static By sebiRegComment = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[6]/div/textarea");
	public static By sebiSave = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[7]/div/button[1]");
	public static By sebiOkButton = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	
	// SEBI Documents
		public static By docMenu = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/ul/li[7]/a");
		public static By docAddNew = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/div[3]/button");
		public static By docSelectFile = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/div[3]/div/form/div[1]/div/div/span/label"); 
		//public static By docDescription = By.cssSelector("input[name='documentDesc']");
		public static By docDescription = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/div[3]/div/form/div[2]/div/input");
		public static By docDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/div[3]/div/form/div[3]/div/input");
		public static By docDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[3]/a");
		public static By docupload = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/div[3]/div/form/div[4]/div/button[1]");
		public static By docOkbutton =  By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	
	
}

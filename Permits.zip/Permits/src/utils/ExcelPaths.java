package utils;

public class ExcelPaths {

	public static String addMasEaPo = "H:\\Permit\\Automation Files\\Singapore.xlsx";
	
	public static String addSGVisit = "H:\\Permit\\Automation Files\\Singapore.xlsx";
	
	public static String addSGReg = "H:\\Permit\\Automation Files\\Singapore.xlsx";
	
    public static String addCPT = "H:\\Permit\\Automation Files\\HongKong.xlsx";
	
	public static String addHKVisit = "H:\\Permit\\Automation Files\\HongKong.xlsx";
	
	public static String addHKReg = "H:\\Permit\\Automation Files\\HongKong.xlsx";
	
	public static String addAeJ = "H:\\Permit\\Automation Files\\AeJ.xlsx";
	
}

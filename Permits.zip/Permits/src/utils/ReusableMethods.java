package utils;

import java.io.File;
import java.util.Scanner;
//import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
//import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import permitpageelementsaej.ASICRegistrationModule;
import permitpageelementssg.SGRegistrationModule;


//import com.sun.jna.platform.FileUtils;

public class ReusableMethods {
	public static WebDriver driver;
	public static Scanner in;
	
	public static void OpenBrowser() throws InterruptedException
	{
		System.out.println("*******************");
		System.out.println("launching IE browser");
		System.setProperty("webdriver.ie.driver", "C:/Temp/Selenium/IEDriverServer.exe");
		driver = new InternetExplorerDriver();
		driver.manage().window().maximize();
		driver.get("http://int-intranet.nomuranow.com/CMPL/REG/#/home");
		Thread.sleep(3500);
	}
	
	@SuppressWarnings("resource")
	public static void Spoof() throws InterruptedException
	{
		
		try{
		driver.findElement(SGRegistrationModule.spoof).click();
		Thread.sleep(3000);
		String country;
		Scanner in = new Scanner(System.in);
		System.out.println("********************");
		System.out.println("Enter Country to Spoof In");
		Thread.sleep(3000);  
	    country = in.nextLine();
		Thread.sleep(3000);
		if("singapore".equalsIgnoreCase(country)){
		driver.findElement(SGRegistrationModule.searchUser).sendKeys("lipika mahunta");	
		}
		else if("india".equalsIgnoreCase(country)){
			driver.findElement(SGRegistrationModule.searchUser).sendKeys("Sunny patil");	
		}
		else if("australia".equalsIgnoreCase(country)){
			driver.findElement(ASICRegistrationModule.searchUser).sendKeys("Johanna finlayson");
		}
		else if("indonesia".equalsIgnoreCase(country)){
			driver.findElement(SGRegistrationModule.searchUser).sendKeys("pamursita respat");
		}
		else if("korea".equalsIgnoreCase(country)){
			driver.findElement(SGRegistrationModule.searchUser).sendKeys("danbee koh");
		}
		else if("malaysia".equalsIgnoreCase(country)){
			driver.findElement(SGRegistrationModule.searchUser).sendKeys("james Ee");
		}
		else if("taiwan".equalsIgnoreCase(country)){
			driver.findElement(SGRegistrationModule.searchUser).sendKeys("sunny wang");
		}
		else if("thailand".equalsIgnoreCase(country)){
			driver.findElement(SGRegistrationModule.searchUser).sendKeys("penphup");
		}
		else{
		System.out.println("Alert! Wrong country entered...");
		driver.close();
		}  	
		Thread.sleep(8000);
		driver.findElement(SGRegistrationModule.selectUser).click();
		//driver.findElement(SGRegistrationModule.searchUser).sendKeys(Keys.DOWN);
		//Thread.sleep(8000);
		//driver.findElement(SGRegistrationModule.searchUser).sendKeys(Keys.RETURN);
		WebDriverWait wait=new WebDriverWait(driver,150);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SGRegistrationModule.regMainMenu));
		}finally{
			if(in!=null){
			in.close();
		}
		}
	}

	 public static void TakeSnapShot(WebDriver webdriver,String fileWithPath) throws Exception{

	    TakesScreenshot scrShot =((TakesScreenshot)webdriver);
        File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
        File DestFile=new File(fileWithPath);
        FileUtils.copyFile(SrcFile, DestFile);
	    }

	 public static void permitWait(int T) {
		 driver.manage().timeouts().implicitlyWait(T, TimeUnit.SECONDS); 
	 }
 
}
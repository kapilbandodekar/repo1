package utils;

import java.io.*;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;

public class StaticProvider 
{
	public static String[][] readExcelData(String sheetName, String filePath,
			String tableName) {
		String[][] testData = null;
		Workbook workBook = null;
		try 
		{
			InputStream inputStream = getInputFileStream(filePath);
			if (filePath.toLowerCase().endsWith("xlsx") == true) 
			{
				workBook = new XSSFWorkbook(inputStream);
			} 
			else if (filePath.toLowerCase().endsWith("xls") == true) 
			{
				workBook = new HSSFWorkbook(inputStream);
			}
			inputStream.close();
			Sheet sheet = workBook.getSheet(sheetName);
			Cell[] boundaryCells = findCell(sheet, tableName);
			Cell startCell = boundaryCells[0];
			Cell endCell = boundaryCells[1];
			int startRow = startCell.getRowIndex() + 1;
			int endRow = endCell.getRowIndex() - 1;
			int startCol = startCell.getColumnIndex() + 1;
			int endCol = endCell.getColumnIndex() - 1;
			System.out.println("Excel Array created with row size: "
					+ (endRow - startRow + 1) + " :: Column size: "
					+ (endCol - startCol + 1));
			testData = new String[endRow - startRow + 1][endCol - startCol + 1];
			for (int i = startRow; i < endRow + 1; i++) 
			{
				for (int j = startCol; j < endCol + 1; j++) 
				{
					if (sheet.getRow(i).getCell(j) == null) 
					{
						testData[i - startRow][j - startCol] = "";
					} 
					else 
					{
						testData[i - startRow][j - startCol] = sheet.getRow(i)
								.getCell(j).getStringCellValue();
					}
				}
			}
		} 
		catch (FileNotFoundException e) 
		{
			System.out.println("Could not read the Excel sheet");
			e.printStackTrace();
		}
		catch (IOException e) 
		{
			System.out.println("Could not read the Excel sheet");
			e.printStackTrace();
		}
		catch (Exception e) 
		{
			System.out.println("Exception in read the Excel sheet:"
					+ e.getMessage());
			e.printStackTrace();
		}
		return testData;
	}

	private static InputStream getInputFileStream(String fileName)
			throws FileNotFoundException 
	{
		ClassLoader loader = StaticProvider.class.getClassLoader();
		InputStream inputStream = loader.getResourceAsStream(fileName);
		if (inputStream == null) {
			inputStream = new FileInputStream(new File(fileName));
		}
		return inputStream;
	}

	public static Cell[] findCell(Sheet sheet, String text) 
	{
		String pos = "start";
		Cell[] cells = new Cell[2];
		for (Row row : sheet) {
			for (Cell cell : row) {
				cell.setCellType(Cell.CELL_TYPE_STRING);
				if (text.equals(cell.getStringCellValue())) {
					if (pos.equalsIgnoreCase("start")) {
						cells[0] = (Cell) cell;
						pos = "end";
					} else {
						cells[1] = (Cell) cell;
					}
				}

			}
		}
		return cells;
	}

	public void updateAlfrescoArticleID(String sheetName, String filePath,
			String previousArticleID, String currentArticleID) 
	{
		try 
		{
			InputStream inp = new FileInputStream(filePath);
			Workbook wb = WorkbookFactory.create(inp);
			Sheet sheet = wb.getSheet(sheetName);
			for (Row row : sheet) 
			{
				for (Cell cell : row) 
				{
					cell.setCellType(Cell.CELL_TYPE_STRING);
					if (previousArticleID.equals(cell.getStringCellValue())) 
					{
						cell.setCellValue(currentArticleID);
					}
				}
			}
			// Write the output to a file
			FileOutputStream fileOut = new FileOutputStream(filePath);
			wb.write(fileOut);
			fileOut.close();
		} 
		catch (FileNotFoundException e) 
		{
			Reporter.log("Could not find the Excel sheet");
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			Reporter.log("Could not read the Excel sheet");
			e.printStackTrace();
		} 
		catch (Exception e) 
		{
			Reporter.log("Exception occured in updateAlfrescoArticleID: "
					+ e.getMessage());
			e.printStackTrace();
		}
	}
	
	public void write2DArrayToExcel(String[][] array, String sheetName,String filePath) 
	{
		InputStream inp = null;
		Workbook wb = null;
		Sheet sheet = null;
		try 
		{
			inp = new FileInputStream(System.getProperty("user.dir") + filePath);
			wb = WorkbookFactory.create(inp);
		} 
		catch (FileNotFoundException e) 
		{
			wb = new HSSFWorkbook();
		} 
		catch (Exception e) 
		{
			Reporter.log("Could not find the Excel sheet");
			e.printStackTrace();
		}
		try 
		{
			sheet = wb.createSheet(sheetName);
			for (int i = 0; i < array.length; i++) 
			{
				Row row = sheet.createRow(i);
				for (int j = 0; j < array[0].length; j++) 
				{
					Cell cell = row.createCell(j);
					cell.setCellType(Cell.CELL_TYPE_STRING);
					cell.setCellValue(array[i][j]);
				}
			}
			// Write the output to a file
			FileOutputStream fileOut = new FileOutputStream(System.getProperty("user.dir") + filePath);
			wb.write(fileOut);
			fileOut.close();
		} 
		catch (IOException e) 
		{
			Reporter.log("Could not read the Excel sheet");
			e.printStackTrace();
		} 
		catch (Exception e) 
		{
			Reporter.log("Exception occured in write2DArrayToExcel: "+ e.getMessage());
			e.printStackTrace();
		}
	}

//Data Provider
	@DataProvider(name="SGRegistration")
	public static Object[][] addSGReg()
	{
		Object[][] testData=readExcelData("SGRegData",ExcelPaths.addSGReg,"SGRegistration");  
		return testData;
	}
	
	@DataProvider(name="SGVisitorLog")
	public static Object[][] addSGVisit()
	{
		Object[][] testData=readExcelData("SGVisitData",ExcelPaths.addSGVisit,"SGVLog");  
		return testData;
	}	
	
	
	@DataProvider(name="SGMasEAPO")
	public static Object[][] addMasEaPo()
	{
		Object[][] testData=readExcelData("MasEaPoData",ExcelPaths.addMasEaPo,"SGMasEAPO");  
		return testData;
	}
	
	@DataProvider(name="HKRegistration")
	public static Object[][] addHKReg()
	{
		Object[][] testData=readExcelData("HKRegData",ExcelPaths.addHKReg,"HKRegistration");  
		return testData;
	}
	
	@DataProvider(name="HKVisitorLog")
	public static Object[][] addHKVisit()
	{
		Object[][] testData=readExcelData("HKVisitData",ExcelPaths.addHKVisit,"HKVisitorLog");  
		return testData;
	}	
	
	@DataProvider(name="HKCPT")
	public static Object[][] addCPT()
	{
		Object[][] testData=readExcelData("HKCPTDetails",ExcelPaths.addCPT,"HKCPT");  
		return testData;
	}
	
	@DataProvider(name="AeJIndia")
	public static Object[][] addIndia()
	{
		Object[][] testData=readExcelData("India",ExcelPaths.addAeJ,"SEBIRegistration");  
		return testData;
	}
	
	@DataProvider(name="AeJKorea")
	public static Object[][] addKorea()
	{
		Object[][] testData=readExcelData("Korea",ExcelPaths.addAeJ,"KOFIARegistration");  
		return testData;
	}
	
	@DataProvider(name="AeJThailand")
	public static Object[][] addThailand()
	{
		Object[][] testData=readExcelData("Thailand",ExcelPaths.addAeJ,"SECTHRegistration");  
		return testData;
	}
	
	@DataProvider(name="AeJIndonesia")
	public static Object[][] addIndonesia()
	{
		Object[][] testData=readExcelData("Indonesia",ExcelPaths.addAeJ,"OJKRegistration");  
		return testData;
	}
	
	@DataProvider(name="AeJTaiwan")
	public static Object[][] addTaiwan()
	{
		Object[][] testData=readExcelData("Taiwan",ExcelPaths.addAeJ,"SFBRegistration");  
		return testData;
	}
	
	@DataProvider(name="AeJMalaysia")
	public static Object[][] addMalaysia()
	{
		Object[][] testData=readExcelData("Malaysia",ExcelPaths.addAeJ,"SCMRegistration");  
		return testData;
	}
	
	@DataProvider(name="AeJAustralia")
	public static Object[][] addAustralia()
	{
		Object[][] testData=readExcelData("Australia",ExcelPaths.addAeJ,"ASICRegistration");  
		return testData;
	}
}


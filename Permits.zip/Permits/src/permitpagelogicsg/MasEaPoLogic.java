package permitpagelogicsg;

import java.awt.AWTException;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import utils.StaticProvider;
import permitpageelementssg.MasEaPo;
//import permitsgpageelements.SGRegistrationModule;
import utils.ReusableMethods;


public class MasEaPoLogic extends ReusableMethods{
	@Test(dataProvider = "SGMasEAPO", dataProviderClass = StaticProvider.class)
	public static void main(String F_Name, String M_Name, String L_Name, String Alias, String NomID, String	Enfo_SearchName, String Enfo_Reg, String Enfo_Details, String Enfo_Link, String Pro_SearchName, String Pro_Regulator, String Pro_NRIC, String Pro_Duration, String Pro_Details, String Pro_Link) throws InterruptedException, AWTException {
	driver.findElement(MasEaPo.addNametab).click();
	driver.findElement(MasEaPo.firstName).sendKeys(F_Name);
	driver.findElement(MasEaPo.middleName).sendKeys(M_Name);
	driver.findElement(MasEaPo.lastName).sendKeys(L_Name);
	driver.findElement(MasEaPo.alias).sendKeys(Alias);
	driver.findElement(MasEaPo.nomuraUID).sendKeys(NomID);
	permitWait(1);
	driver.findElement(MasEaPo.nomuraUID).sendKeys(Keys.DOWN);
	driver.findElement(MasEaPo.nomuraUID).sendKeys(Keys.RETURN);
	permitWait(1);;
	driver.findElement(MasEaPo.addNameSave).click();
	permitWait(3);
	
	WebElement addNameOk = driver.findElement(MasEaPo.addNameOk);
	if(addNameOk != null){
		addNameOk.click();
	System.out.println("Employee Details Saved Successfully");
	}
    else{
	System.out.println("Alert! Employee Details not Saved");
	}
	permitWait(2);
	
	driver.findElement(MasEaPo.enfoActionTab).click();
	permitWait(1);
	driver.findElement(MasEaPo.enfoActSearchName).sendKeys(Enfo_SearchName);
	permitWait(1);
	driver.findElement(MasEaPo.enfoActSearchName).sendKeys(Keys.DOWN);
	driver.findElement(MasEaPo.enfoActSearchName).sendKeys(Keys.RETURN);
	permitWait(1);
	driver.findElement(MasEaPo.enfoActregulator).sendKeys(Enfo_Reg);
	driver.findElement(MasEaPo.enfoActionDate).click();
	driver.findElement(MasEaPo.enfoActionDateSelect).click();
	driver.findElement(MasEaPo.enfoActionDetails).sendKeys(Enfo_Details);
	driver.findElement(MasEaPo.enfoActionLink).sendKeys(Enfo_Link);
	driver.findElement(MasEaPo.enfoActionSave).click();
	permitWait(3);

	WebElement enfoActOk = driver.findElement(MasEaPo.enforActionOk);
	if(enfoActOk != null){
		enfoActOk.click();
	System.out.println("Enforcement Action Saved Successfully");
	}
    else{
	System.out.println("Alert! Enforcement Action not Saved");
	}
	permitWait(1);
	
	driver.findElement(MasEaPo.proOrderTab).click();
	permitWait(1);
	driver.findElement(MasEaPo.proOrderSearchName).sendKeys(Pro_SearchName);
	permitWait(1);
	driver.findElement(MasEaPo.proOrderSearchName).sendKeys(Keys.DOWN);
	driver.findElement(MasEaPo.proOrderSearchName).sendKeys(Keys.RETURN);
	permitWait(1);
	driver.findElement(MasEaPo.proOrderRegulator).sendKeys(Pro_Regulator);
	driver.findElement(MasEaPo.proOrderDate).click();
	driver.findElement(MasEaPo.proOrderDateSelect).click();
	driver.findElement(MasEaPo.proOrderNRIC).sendKeys(Pro_NRIC);
	driver.findElement(MasEaPo.proOrderEffectDate).click();
	driver.findElement(MasEaPo.proOrderEffectDateSelect).click();
	driver.findElement(MasEaPo.proOrderEndDate).click();
	driver.findElement(MasEaPo.proOrderEndDateSelect).click();
	driver.findElement(MasEaPo.proOrderDuration).sendKeys(Pro_Duration);
	driver.findElement(MasEaPo.proOrderDetails).sendKeys(Pro_Details);
	driver.findElement(MasEaPo.proOrderLink).sendKeys(Pro_Link);
	driver.findElement(MasEaPo.proOrderSave).click();
	permitWait(3);
	WebElement proOrderOk = driver.findElement(MasEaPo.proOrderOk);
	if(proOrderOk != null){
		proOrderOk.click();
	System.out.println("Prohibition Order Saved Successfully");
	}
    else{
	System.out.println("Alert! Prohibition Order not Saved");
	}
	
	}
	@BeforeTest
	public void beforeTest() throws InterruptedException
	{
		OpenBrowser();
		permitWait(2);
		Spoof();
		/*driver.findElement(SGRegistrationModule.spoof).click();
		permitWait(2);
		driver.findElement(SGRegistrationModule.searchUser).sendKeys("lipika mahunta");
		permitWait(5);
		driver.findElement(SGRegistrationModule.selectUser).click();
		//driver.findElement(SGRegistrationModule.searchUser).sendKeys(Keys.DOWN);
		//permitWait(1);
		//driver.findElement(SGRegistrationModule.searchUser).sendKeys(Keys.RETURN);
		WebDriverWait wait=new WebDriverWait(driver,100);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SGRegistrationModule.regMainMenu));
		permitWait(2);
		*/
		driver.findElement(MasEaPo.masEAPOMenu).click();
		permitWait(2);
		
	}
	
	@AfterTest
	public void afterTest() 
	{
		//driver.quit();
	}
}

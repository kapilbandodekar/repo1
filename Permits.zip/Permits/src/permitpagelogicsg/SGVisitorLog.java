package permitpagelogicsg;

import java.awt.AWTException;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

//import permitsgpageelements.SGRegistrationModule;

import permitpageelementssg.VisitorLogSG;
import utils.ReusableMethods;
import utils.StaticProvider;

public class SGVisitorLog extends ReusableMethods {
	@Test(dataProvider = "SGVisitorLog", dataProviderClass = StaticProvider.class)
	public static void main(String VName, String Qualification, String SGPerson, String	TeamMember, String LicEntity, String ContactHome, String ContactSG, String OtherDetails) throws InterruptedException, AWTException {
	
	driver.findElement(VisitorLogSG.addNewVisit).click();
	permitWait(2);
	driver.findElement(VisitorLogSG.nameOfVisitor).sendKeys(VName);
	permitWait(1);
	driver.findElement(VisitorLogSG.nameOfVisitor).sendKeys(Keys.DOWN);
	driver.findElement(VisitorLogSG.nameOfVisitor).sendKeys(Keys.RETURN);
	permitWait(1);
	driver.findElement(VisitorLogSG.visitDateFrom).click();
	driver.findElement(VisitorLogSG.visitDateFromSelect).click();
	driver.findElement(VisitorLogSG.visitDateTo).click();
	driver.findElement(VisitorLogSG.visitDateToSelect).click();
	driver.findElement(VisitorLogSG.highestEduQualification).sendKeys(Qualification);
	driver.findElement(VisitorLogSG.internalMeeting).click();
	driver.findElement(VisitorLogSG.externalMeeting).click();
	driver.findElement(VisitorLogSG.conductRAActivity).click();
	permitWait(1);
	driver.findElement(VisitorLogSG.roTradeStartDate).click();
	driver.findElement(VisitorLogSG.roTradeStartDateSelect).click();
	permitWait(1);
	driver.findElement(VisitorLogSG.roTradeEndDate).click();
	driver.findElement(VisitorLogSG.roTradeEndDateSelect).click();
	driver.findElement(VisitorLogSG.sgChairPerson).sendKeys(SGPerson);
	permitWait(1);
	driver.findElement(VisitorLogSG.sgChairPerson).sendKeys(Keys.DOWN);
	driver.findElement(VisitorLogSG.sgChairPerson).sendKeys(Keys.RETURN);
	permitWait(1);
	driver.findElement(VisitorLogSG.teamMemberAddIcon).click();
	permitWait(1);
	driver.findElement(VisitorLogSG.teamMemberSearch).sendKeys(TeamMember);
	permitWait(1);
	driver.findElement(VisitorLogSG.teamMemberSearch).sendKeys(Keys.DOWN);
	driver.findElement(VisitorLogSG.teamMemberSearch).sendKeys(Keys.RETURN);
	driver.findElement(VisitorLogSG.licenseHome).click();
	permitWait(1);
	driver.findElement(VisitorLogSG.licenseEntity).sendKeys(LicEntity);
	permitWait(1);
	driver.findElement(VisitorLogSG.selectLicenseChkbox).click();
	driver.findElement(VisitorLogSG.contactPersonHome).sendKeys(ContactHome);
	permitWait(1);
	driver.findElement(VisitorLogSG.contactPersonHome).sendKeys(Keys.DOWN);
	driver.findElement(VisitorLogSG.contactPersonHome).sendKeys(Keys.RETURN);
	driver.findElement(VisitorLogSG.contactPersonSG).sendKeys(ContactSG);
	permitWait(1);
	driver.findElement(VisitorLogSG.contactPersonSG).sendKeys(Keys.DOWN);
	driver.findElement(VisitorLogSG.contactPersonSG).sendKeys(Keys.RETURN);
	driver.findElement(VisitorLogSG.otherDetails).sendKeys(OtherDetails);
	driver.findElement(VisitorLogSG.Submit).click();
	permitWait(2);
	WebElement okButton = driver.findElement(VisitorLogSG.vlSGOkButton);
	if(okButton != null){
		okButton.click();
	System.out.println("Visitor Log Submitted Successfully");
	}
    else{
	System.out.println("Alert! Visitor Log not Submitted");
	}
	permitWait(1);;
	driver.quit();

}

@BeforeTest
public void beforeTest() throws InterruptedException
{
	OpenBrowser();
	permitWait(2);
	Spoof();
	/*
	driver.findElement(SGRegistrationModule.spoof).click();
	permitWait(2);
	driver.findElement(SGRegistrationModule.searchUser).sendKeys("lipika mahunta");
	permitWait(1);
	driver.findElement(SGRegistrationModule.searchUser).sendKeys(Keys.DOWN);
	driver.findElement(SGRegistrationModule.searchUser).sendKeys(Keys.RETURN);
	WebDriverWait wait=new WebDriverWait(driver,100);
	wait.until(ExpectedConditions.visibilityOfElementLocated(SGRegistrationModule.regMainMenu));
	permitWait(2);
	*/
	driver.findElement(VisitorLogSG.vLogMainMenu).click();
	permitWait(3);
	driver.findElement(VisitorLogSG.myVLMenu).click();
	permitWait(2);
}

@AfterTest
public void afterTest() 
{
	//driver.quit();
}
}
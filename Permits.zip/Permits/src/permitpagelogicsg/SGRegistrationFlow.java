package permitpagelogicsg;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.datatransfer.StringSelection;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.sun.glass.events.KeyEvent;

import permitpageelementssg.SGRegistrationModule;
import utils.ReusableMethods;
import utils.StaticProvider;

public class SGRegistrationFlow extends ReusableMethods{
	@Test(dataProvider = "SGRegistration", dataProviderClass = StaticProvider.class)
	public static void main(String NRICName, String	HireType, String NRICNo, String	PassportNo, String FINNo, String Add1, String Add2, String PCode, String HomeContact, String MobContact, String	EmpCom, String EntName, String IncorpPlace, String BussNature, String BussInterest, String PercentEnt, String OBICom, String RAType, String	RNFCom1, String	CDescription, String RNFRemark, String RNFNo, String LICType, String LICStatus, String RNFCom, String	REGAuth, String	REGType, String	REGNo, String RegStatus, String	REGCom1, String	REGLICStatus, String REGCom2, String BreachType, String	BRDetails, String BRAction, String BRCom, String MISDesc, String MISDetails, String	MISAction, String MISReamark, String FITDesc, String FITDetails, String	FITAction, String FITEXTDetails, String	FITCom, String DocDesc)
			throws InterruptedException, AWTException {
				
		//Employee Details
		driver.findElement(SGRegistrationModule.empDetailstab).click();
		permitWait(1);
		driver.findElement(SGRegistrationModule.cessationDate).click();
		permitWait(1);
		driver.findElement(SGRegistrationModule.cessationDateSelect).click();
		driver.findElement(SGRegistrationModule.nameNRIC).sendKeys(NRICName);
		driver.findElement(SGRegistrationModule.dobDate).click();
		permitWait(1);
		driver.findElement(SGRegistrationModule.dobDateSelect).click();
		driver.findElement(SGRegistrationModule.genderRadio).click();
		driver.findElement(SGRegistrationModule.typeOfHire).sendKeys(HireType);
		driver.findElement(SGRegistrationModule.nationality).click();
		driver.findElement(SGRegistrationModule.nricNo).sendKeys(NRICNo);
		driver.findElement(SGRegistrationModule.passportNo).sendKeys(PassportNo);
		driver.findElement(SGRegistrationModule.finNo).sendKeys(FINNo);
		driver.findElement(SGRegistrationModule.basedOverseas).click();
		driver.findElement(SGRegistrationModule.address1).sendKeys(Add1);
		driver.findElement(SGRegistrationModule.address2).sendKeys(Add2);
		driver.findElement(SGRegistrationModule.postCodeSG).sendKeys(PCode);
		driver.findElement(SGRegistrationModule.contactHome).sendKeys(HomeContact);
		driver.findElement(SGRegistrationModule.contactMobile).sendKeys(MobContact);
		driver.findElement(SGRegistrationModule.compNotiDate).click();
		permitWait(1);
		driver.findElement(SGRegistrationModule.compNotiDateSelect).click();
		driver.findElement(SGRegistrationModule.rnfRegistration).click();
		driver.findElement(SGRegistrationModule.uniqueRegSelect).click();
		driver.findElement(SGRegistrationModule.spouseRadio).click();
		driver.findElement(SGRegistrationModule.comments).sendKeys(EmpCom);
		driver.findElement(SGRegistrationModule.empDetailsSave).click();
		permitWait(2);
		WebElement empTabOk = driver.findElement(SGRegistrationModule.empDetailsOk);
		if(empTabOk != null){
		empTabOk.click();
		System.out.println("Employee Details Saved Successfully");
		}
	    else{
		System.out.println("Alert! Employee Details not Saved");
		}
		permitWait(1);
		
		//Outside Business
		driver.findElement(SGRegistrationModule.obiTab).click();
		permitWait(2);
		driver.findElement(SGRegistrationModule.addNewOBI1).click();
		permitWait(2);
		driver.findElement(SGRegistrationModule.entityName1).sendKeys(EntName);
		driver.findElement(SGRegistrationModule.placeOfIncorp1).sendKeys(IncorpPlace);
		driver.findElement(SGRegistrationModule.natureOfBusiness1).sendKeys(BussNature);
		driver.findElement(SGRegistrationModule.businessInterests).sendKeys(BussInterest);
		driver.findElement(SGRegistrationModule.acqBusinessDate).click();
		driver.findElement(SGRegistrationModule.acqBusinessDateSelect).click();
		driver.findElement(SGRegistrationModule.cessBusinessDate).click();
		driver.findElement(SGRegistrationModule.cessBusinessDateSelect).click();
		driver.findElement(SGRegistrationModule.saveOBI1).click();
		permitWait(2);
		WebElement obi1Ok = driver.findElement(SGRegistrationModule.obiOkButton1);
		if(obi1Ok != null){
		obi1Ok.click();
		System.out.println("OBI Details 1 Saved Successfully");
		}
	    else{
		System.out.println("Alert! OBI Details 1 not Saved");
		}
		permitWait(2);
			
		driver.findElement(SGRegistrationModule.addNewOBI2).click();
		permitWait(1);
		driver.findElement(SGRegistrationModule.entityName2).sendKeys(EntName);
		driver.findElement(SGRegistrationModule.placeOfIncorp2).sendKeys(IncorpPlace);
		driver.findElement(SGRegistrationModule.natureOfBusiness2).sendKeys(BussNature);
		driver.findElement(SGRegistrationModule.obiFromDate).click();
		driver.findElement(SGRegistrationModule.obiFromDateSelect).click();
		driver.findElement(SGRegistrationModule.obiToDate).click();
		driver.findElement(SGRegistrationModule.obiToDateSelect).click();
		driver.findElement(SGRegistrationModule.percentageInEntity).sendKeys(PercentEnt);
		driver.findElement(SGRegistrationModule.saveOBI2).click();
		permitWait(2);
		WebElement obi2Ok = driver.findElement(SGRegistrationModule.obiOkButton2);
		if(obi2Ok != null){
		obi2Ok.click();
		System.out.println("OBI Details 1 Saved Successfully");
		}
	    else{
		System.out.println("Alert! OBI Details 1 not Saved");
		}
		permitWait(1);
		
		driver.findElement(SGRegistrationModule.obiComments).sendKeys(OBICom);
		driver.findElement(SGRegistrationModule.obiSave).click();
		permitWait(2);
		WebElement obiOk = driver.findElement(SGRegistrationModule.obiOkButton);
		permitWait(2);
		if(obiOk!=null){
		obiOk.click();
		System.out.println("OBI Detials Saved Successfully");
		}
	    else{
		System.out.println("ALert! OBI Details not Saved");	
		}
		
		//RNF Registration
		driver.findElement(SGRegistrationModule.rnfTab).click();
		permitWait(3);
		driver.findElement(SGRegistrationModule.addNewREGDetails).click();
		permitWait(1);
		driver.findElement(SGRegistrationModule.typeOfRA).sendKeys(RAType);
		driver.findElement(SGRegistrationModule.regDate).click();
		driver.findElement(SGRegistrationModule.regDateSelect).click();
		driver.findElement(SGRegistrationModule.cessDate).click();
		driver.findElement(SGRegistrationModule.cessDateSelect).click();
		driver.findElement(SGRegistrationModule.rnfComment1).sendKeys(RNFCom1);
		driver.findElement(SGRegistrationModule.rnfSave1).click();
		permitWait(1);
		WebElement rnfOk1 = driver.findElement(SGRegistrationModule.rnfOkButton1);
		permitWait(1);
		if(rnfOk1!=null){
		rnfOk1.click();
		System.out.println("Registration Detials Saved Successfully");
		}
	    else{
		System.out.println("ALert! Registration Details not Saved");	
		}
		permitWait(1);
		
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("window.scrollBy(0,250)", "");
		
		driver.findElement(SGRegistrationModule.addNewCerDetails).click();
		permitWait(1);
		driver.findElement(SGRegistrationModule.cerDescription).sendKeys(CDescription);
		driver.findElement(SGRegistrationModule.passDate).click();
		driver.findElement(SGRegistrationModule.passDateSelect).click();
		driver.findElement(SGRegistrationModule.expireDate).click();
		driver.findElement(SGRegistrationModule.expireDateSelect).click();
		driver.findElement(SGRegistrationModule.rnfRemark).sendKeys(RNFRemark);
		driver.findElement(SGRegistrationModule.rnfSave2).click();
		permitWait(1);
		WebElement rnfOk2 = driver.findElement(SGRegistrationModule.rnfOkButton2);
		permitWait(1);
		if(rnfOk2!=null){
		rnfOk2.click();
		System.out.println("Certification Detials Saved Successfully");
		}
	    else{
		System.out.println("ALert! Certification Details not Saved");	
		}
		permitWait(1);
		JavascriptExecutor jsd = (JavascriptExecutor)driver;
		jsd.executeScript("window.scrollBy(0,250)", "");
		
		driver.findElement(SGRegistrationModule.rnfNo).sendKeys(RNFNo);
		driver.findElement(SGRegistrationModule.rnfSubDate).click();
		driver.findElement(SGRegistrationModule.rnfSubDateSelect).click();
		driver.findElement(SGRegistrationModule.rnfAppointDate).click();
		driver.findElement(SGRegistrationModule.rnfAppointDateSelect).click();
		driver.findElement(SGRegistrationModule.licenseType).sendKeys(LICType);
		driver.findElement(SGRegistrationModule.licenseStatus).sendKeys(LICStatus);
		driver.findElement(SGRegistrationModule.rnfComments).sendKeys(RNFCom);
		driver.findElement(SGRegistrationModule.rnfSave).click();
		permitWait(1);
		WebElement rnfOk = driver.findElement(SGRegistrationModule.rnfOkButton);
		permitWait(1);
		if(rnfOk!=null){
		rnfOk.click();
		System.out.println("RNF Registration Details Saved Successfully");	
		}
        else{
	    System.out.println("Alert! RNF Registration Details not Saved");
        }
		
		//Other Registration
		driver.findElement(SGRegistrationModule.othRegTab).click();
		permitWait(2);
		driver.findElement(SGRegistrationModule.addNewOthReg).click();
		driver.findElement(SGRegistrationModule.regauthority).sendKeys(REGAuth);
		permitWait(1);
		driver.findElement(SGRegistrationModule.regtype).sendKeys(REGType);
		driver.findElement(SGRegistrationModule.regNo).sendKeys(REGNo);
		driver.findElement(SGRegistrationModule.subDate).click();
		driver.findElement(SGRegistrationModule.subDateSelect).click();
		driver.findElement(SGRegistrationModule.othRegDate).click();
		driver.findElement(SGRegistrationModule.othRegDateSelect).click();
		driver.findElement(SGRegistrationModule.othRegStatus).sendKeys(RegStatus);
		driver.findElement(SGRegistrationModule.othRegComments1).sendKeys(REGCom1);
		driver.findElement(SGRegistrationModule.othRegSave1).click();
		permitWait(1);
		WebElement othRegOk1 = driver.findElement(SGRegistrationModule.othRegOkButton1);
		permitWait(1);
		if(othRegOk1!=null){
		othRegOk1.click();
			System.out.println("Other Registration Details 1 Saved Successfully");	
			}
	    else{
		    System.out.println("Alert! RNF Registration Details 1 not Saved");
	        }
		JavascriptExecutor jsf = (JavascriptExecutor)driver;
		jsf.executeScript("window.scrollBy(0,150)", "");
		permitWait(1);
		driver.findElement(SGRegistrationModule.othRegLicStatus).sendKeys(REGLICStatus);
		driver.findElement(SGRegistrationModule.othRegComments2).sendKeys(REGCom2);
		driver.findElement(SGRegistrationModule.othRegSave2).click();
		permitWait(1);
		WebElement othRegOk2 = driver.findElement(SGRegistrationModule.othRegOkButton2);
		permitWait(1);
		if(othRegOk2!=null){
		othRegOk2.click();
			System.out.println("Other Registration Details 2 Saved Successfully");	
			}
	    else{
		    System.out.println("Alert! RNF Registration Details 2 not Saved");
	        }
		
		//Breach_Misconduct
		driver.findElement(SGRegistrationModule.brMisTab).click();
		permitWait(2);
		driver.findElement(SGRegistrationModule.breachType).sendKeys(BreachType);
		permitWait(1);
		driver.findElement(SGRegistrationModule.brIncidentDate).click();
		driver.findElement(SGRegistrationModule.brIncidentDateSelect).click();
		driver.findElement(SGRegistrationModule.brDate).click();
		driver.findElement(SGRegistrationModule.brDateSelect).click();
		driver.findElement(SGRegistrationModule.brDetails).sendKeys(BRDetails);
		driver.findElement(SGRegistrationModule.brDisAction).sendKeys(BRAction);
		driver.findElement(SGRegistrationModule.brDisActDate).click();
		driver.findElement(SGRegistrationModule.brDisActDateSelect).click();
		driver.findElement(SGRegistrationModule.brComments).sendKeys(BRCom);
		driver.findElement(SGRegistrationModule.brSave).click();
		permitWait(1);
		WebElement brOk = driver.findElement(SGRegistrationModule.brOkButton);
		permitWait(1);
		if(brOk!=null){
		brOk.click();
			System.out.println("Breach Details Saved Successfully");	
			}
	    else{
		    System.out.println("Alert! Breach Details not Saved");
	        }
		permitWait(1);
		JavascriptExecutor jsg = (JavascriptExecutor)driver;
		jsg.executeScript("window.scrollBy(0,150)", "");
		
		driver.findElement(SGRegistrationModule.misAccordion).click();
		permitWait(1);
		driver.findElement(SGRegistrationModule.misIncDesc).sendKeys(MISDesc);
		driver.findElement(SGRegistrationModule.misIncDate).click();
		driver.findElement(SGRegistrationModule.misIncDateSelect).click();
		driver.findElement(SGRegistrationModule.misDetails).sendKeys(MISDetails);
		driver.findElement(SGRegistrationModule.misDicAction).sendKeys(MISAction);
		permitWait(1);
		driver.findElement(SGRegistrationModule.misReportToReg).click();
		permitWait(1);
		driver.findElement(SGRegistrationModule.misRepToRegDate).click();
		driver.findElement(SGRegistrationModule.misRepToRegDateSelect).click();
		driver.findElement(SGRegistrationModule.misRemarks).sendKeys(MISReamark);
		driver.findElement(SGRegistrationModule.misSave).click();
		permitWait(1);
		WebElement misOk = driver.findElement(SGRegistrationModule.misOkButton);
		permitWait(1);
		if(misOk!=null){
		misOk.click();
			System.out.println("Misconduct Details Saved Successfully");	
			}
	    else{
		    System.out.println("Alert! Misconduct Details not Saved");
	        }
		permitWait(1);
		JavascriptExecutor jsh = (JavascriptExecutor)driver;
		jsh.executeScript("window.scrollBy(0,150)", "");
		
		driver.findElement(SGRegistrationModule.fitAccordion).click();
		permitWait(1);
		driver.findElement(SGRegistrationModule.fitIncDescription).sendKeys(FITDesc);
		driver.findElement(SGRegistrationModule.fitIncDate).click();
		driver.findElement(SGRegistrationModule.fitIncDateSelect).click();
		driver.findElement(SGRegistrationModule.fitIncDetails).sendKeys(FITDetails);
		driver.findElement(SGRegistrationModule.fitDisAction).sendKeys(FITAction);
		driver.findElement(SGRegistrationModule.fitIncType).click();
		permitWait(1);
		driver.findElement(SGRegistrationModule.fitExtIncDetails).sendKeys(FITEXTDetails);
		driver.findElement(SGRegistrationModule.fitReportToReg).click();
		permitWait(1);
		driver.findElement(SGRegistrationModule.fitRepToRegDate).click();
		driver.findElement(SGRegistrationModule.fitRepToRegDateSelect).click();
		driver.findElement(SGRegistrationModule.fitComments).sendKeys(FITCom);
		driver.findElement(SGRegistrationModule.fitSave).click();
		permitWait(1);
		WebElement fitOk = driver.findElement(SGRegistrationModule.fitOkButton);
		permitWait(1);
		if(fitOk!=null){
		fitOk.click();
			System.out.println("Fit & Proper Details Saved Successfully");	
			}
	    else{
		    System.out.println("Alert! Fit & Proper Details not Saved");
	        }
		
		//Document
		driver.findElement(SGRegistrationModule.docMenu).click();
		permitWait(2);
		driver.findElement(SGRegistrationModule.docAddNew).click();
		permitWait(1);
			
		String sel = "H:\\Sample Docs\\SampleText.txt";
		driver.findElement(SGRegistrationModule.docSelectFile).click();
		 
		robotclass(sel);
				
		permitWait(3);
		driver.findElement(SGRegistrationModule.docDescription).sendKeys(DocDesc);
		driver.findElement(SGRegistrationModule.docDate).click();
		driver.findElement(SGRegistrationModule.docDateSelect).click();
		driver.findElement(SGRegistrationModule.docupload).click();
		permitWait(5);
		WebElement docOk = driver.findElement(SGRegistrationModule.docOkbutton);
		if(docOk != null){
			docOk.click();
			System.out.println("Document Uploaded Successfully");
			}
		else{
			System.out.println("Alert! Document Not Uploaded Successfully");
			}
		driver.close();
	    }

	private static void robotclass(String sel) throws InterruptedException, AWTException {
		StringSelection selection = new StringSelection(sel);
		System.out.println("File path ---> "+selection);
		permitWait(1);
		java.awt.Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection,null);
		permitWait(1);
		Robot robot = new Robot(); 
		permitWait(1);
		robot.keyPress(KeyEvent.VK_ENTER);
		permitWait(1);
		robot.keyRelease(KeyEvent.VK_ENTER);
		permitWait(1);
		robot.keyPress(KeyEvent.VK_CONTROL);
		permitWait(1);
		robot.keyPress(KeyEvent.VK_V);
		permitWait(1);
		// Release CTRL+V
		robot.keyRelease(KeyEvent.VK_CONTROL);
		permitWait(1);
		robot.keyRelease(KeyEvent.VK_V);
		permitWait(1);
		robot.keyPress(KeyEvent.VK_ENTER);
		permitWait(1);
		robot.keyRelease(KeyEvent.VK_ENTER);
		permitWait(1);
	}	
	
	@BeforeTest
	public void beforeTest() throws InterruptedException
	{
		OpenBrowser();
		permitWait(2);
		Spoof();
		/*driver.findElement(SGRegistrationModule.spoof).click();
		permitWait(2);
		driver.findElement(SGRegistrationModule.searchUser).sendKeys("lipika mahunta");
		permitWait(1);
		driver.findElement(SGRegistrationModule.searchUser).sendKeys(Keys.DOWN);
		driver.findElement(SGRegistrationModule.searchUser).sendKeys(Keys.RETURN);
		WebDriverWait wait=new WebDriverWait(driver,100);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SGRegistrationModule.regMainMenu));
		permitWait(2);
		*/
		driver.findElement(SGRegistrationModule.regMainMenu).click();
		permitWait(2);
		driver.findElement(SGRegistrationModule.regulator).sendKeys("MAS");
		permitWait(1);
		driver.findElement(SGRegistrationModule.searchEmp).sendKeys("matthew her");
		permitWait(1);
		driver.findElement(SGRegistrationModule.searchEmp).sendKeys(Keys.DOWN);
		permitWait(1);
		driver.findElement(SGRegistrationModule.searchEmp).sendKeys(Keys.RETURN);
		permitWait(7);
	}

	@AfterTest
	public void afterTest() 
	{
		//driver.quit();
	}
}

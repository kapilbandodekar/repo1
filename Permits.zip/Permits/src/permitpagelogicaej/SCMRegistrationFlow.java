package permitpagelogicaej;

import java.awt.AWTException;

import org.openqa.selenium.Keys;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import permitpageelementsaej.SCMRegistrationModule;
import permitpageelementsaej.OJKRegistrationModule;
import permitpageelementshk.HKRegistrationModule;
import permitpageelementssg.SGRegistrationModule;
import utils.ReusableMethods;
import utils.StaticProvider;

public class SCMRegistrationFlow extends ReusableMethods{
		
			@Test(dataProvider = "AeJMalaysia", dataProviderClass = StaticProvider.class)
			public static void main(String Title, String LName, String FName, String PassNum, String Nricno,String Nationlity,String Addrss1,String Addrss2,String Pstcode, String Homecntno, String Mobilecntno,String EmpComment, String LicNum, String RAType, String LicRole, String RegComment)
					throws InterruptedException, AWTException { 
		   //Employee Details
				driver.findElement(SCMRegistrationModule.empDetailsTab).click();
				permitWait(2);
				driver.findElement(SCMRegistrationModule.nameTitle).sendKeys(Title);
				//permitWait(1);
				driver.findElement(SCMRegistrationModule.nameLName).sendKeys(LName);
				driver.findElement(SCMRegistrationModule.nameFName).sendKeys(FName);
			//	driver.findElement(ASICRegistrationModule.dob).click();
				//driver.findElement(ASICRegistrationModule.dobSelect).click();
				driver.findElement(SCMRegistrationModule.passportNo).sendKeys(PassNum);
				driver.findElement(SCMRegistrationModule.nricNo).sendKeys(Nricno);
				driver.findElement(SCMRegistrationModule.nationality).click();
				driver.findElement(SCMRegistrationModule.address1).sendKeys(Addrss1);
				driver.findElement(SCMRegistrationModule.address2).sendKeys(Addrss2);
				driver.findElement(SCMRegistrationModule.postalCode).sendKeys(Pstcode);
				driver.findElement(SCMRegistrationModule.homeContact).sendKeys(Homecntno);
				driver.findElement(SCMRegistrationModule.mobileContact).sendKeys(Mobilecntno);
				
				driver.findElement(SCMRegistrationModule.empDetailsComment).sendKeys(EmpComment);
				driver.findElement(SCMRegistrationModule.empDetailsSave).click();
				permitWait(3);
				driver.findElement(SCMRegistrationModule.empDetailsOk).click();
				permitWait(1);
		   //SEBI Registration
				driver.findElement(SCMRegistrationModule.scmRegTab).click();
				permitWait(3);
				driver.findElement(SCMRegistrationModule.scmRegAddNew).click();
				permitWait(2);
				driver.findElement(SCMRegistrationModule.licenseNo).sendKeys(LicNum);
				driver.findElement(SCMRegistrationModule.raType).sendKeys(RAType);
				permitWait(3);
				driver.findElement((SCMRegistrationModule.licRole)).sendKeys(LicRole);
				driver.findElement(SCMRegistrationModule.scmRegDate).click();
				permitWait(1);
				driver.findElement(SCMRegistrationModule.scmRegDateSelect).click();
				driver.findElement(SCMRegistrationModule.scmCessDate).click();
				permitWait(1);
				driver.findElement(SCMRegistrationModule.scmCessDateSelect).click();
				driver.findElement(SCMRegistrationModule.scmRegComment).sendKeys(RegComment);
		        permitWait(1);
				driver.findElement(SCMRegistrationModule.scmSave).click();
				permitWait(3);
				driver.findElement(SCMRegistrationModule.scmOkButton).click();
				
		}
			@BeforeTest
			public void beforeTest() throws InterruptedException
			{
				OpenBrowser();
				permitWait(2);
				Spoof();
				/*driver.findElement(SGRegistrationModule.spoof).click();
				permitWait(2);
				driver.findElement(SGRegistrationModule.searchUser).sendKeys("lipika mahunta");
				permitWait(1);
				driver.findElement(SGRegistrationModule.searchUser).sendKeys(Keys.DOWN);
				driver.findElement(SGRegistrationModule.searchUser).sendKeys(Keys.RETURN);
				WebDriverWait wait=new WebDriverWait(driver,100);
				wait.until(ExpectedConditions.visibilityOfElementLocated(SGRegistrationModule.regMainMenu));
				permitWait(2);
				*/
				driver.findElement(SGRegistrationModule.regMainMenu).click();
				permitWait(2);
				driver.findElement(SGRegistrationModule.regulator).sendKeys("SCM");
				permitWait(1);
				driver.findElement(SGRegistrationModule.searchEmp).sendKeys("Shikha Sharma");
				permitWait(2);
				driver.findElement(HKRegistrationModule.selectEmp).click();
				//driver.findElement(SGRegistrationModule.searchEmp).sendKeys(Keys.DOWN);
				//permitWait(1);
				//driver.findElement(SGRegistrationModule.searchEmp).sendKeys(Keys.RETURN);
				permitWait(7);
			}

			@AfterTest
			public void afterTest() 
			{
				//driver.quit();
			}
}

package permitpagelogicaej;

import java.awt.AWTException;

import org.openqa.selenium.Keys;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import permitpageelementsaej.SEBIRegistrationModule;
import permitpageelementshk.HKRegistrationModule;
import permitpageelementssg.SGRegistrationModule;
import utils.ReusableMethods;
import utils.StaticProvider;

public class SEBIRegistrationFlow extends ReusableMethods{
	@Test(dataProvider = "AeJIndia", dataProviderClass = StaticProvider.class)
	public static void main(String Title, String LName, String FName, String PassNum, String PanNum, String	BUDesc, String EmpComment, String LicNum, String RAType, String	RegComment)
			throws InterruptedException, AWTException { 
   //Employee Details
		driver.findElement(SEBIRegistrationModule.empDetailsTab).click();
		permitWait(1);
		driver.findElement(SEBIRegistrationModule.nameTitle).sendKeys(Title);
		driver.findElement(SEBIRegistrationModule.nameLName).sendKeys(LName);
		driver.findElement(SEBIRegistrationModule.nameFName).sendKeys(FName);
		driver.findElement(SEBIRegistrationModule.dob).click();
		driver.findElement(SEBIRegistrationModule.dobSelect).click();
		driver.findElement(SEBIRegistrationModule.passportNo).sendKeys(PassNum);
		driver.findElement(SEBIRegistrationModule.panNo).sendKeys(PanNum);
		driver.findElement(SEBIRegistrationModule.buDescription).sendKeys(BUDesc);
		driver.findElement(SEBIRegistrationModule.empDetailsComment).sendKeys(EmpComment);
		driver.findElement(SEBIRegistrationModule.empDetailsSave).click();
		permitWait(3);
		driver.findElement(SEBIRegistrationModule.empDetailsOk).click();
		permitWait(1);
   //SEBI Registration
		driver.findElement(SEBIRegistrationModule.sebiRegTab).click();
		permitWait(3);
		driver.findElement(SEBIRegistrationModule.sebiRegAddNew).click();
		permitWait(2);
		driver.findElement(SEBIRegistrationModule.licenseNo).sendKeys(LicNum);
		driver.findElement(SEBIRegistrationModule.raType).sendKeys(RAType);
		driver.findElement(SEBIRegistrationModule.sebiRegDate).click();
		permitWait(1);
		driver.findElement(SEBIRegistrationModule.sebiRegDateSelect).click();
		driver.findElement(SEBIRegistrationModule.sebiCessDate).click();
		permitWait(1);
		driver.findElement(SEBIRegistrationModule.sebiCessDateSelect).click();
		driver.findElement(SEBIRegistrationModule.sebiRenewalDate).click();
        permitWait(1);
		driver.findElement(SEBIRegistrationModule.sebiRenewalDateSelect).click();
		driver.findElement(SEBIRegistrationModule.sebiRegComment).sendKeys(RegComment);
		driver.findElement(SEBIRegistrationModule.sebiSave).click();
		permitWait(3);
		driver.findElement(SEBIRegistrationModule.sebiOkButton).click();	
}
	@BeforeTest
	public void beforeTest() throws InterruptedException
	{
		OpenBrowser();
		permitWait(3);
		Spoof();
		/*driver.findElement(SGRegistrationModule.spoof).click();
		permitWait(2);
		driver.findElement(SGRegistrationModule.searchUser).sendKeys("lipika mahunta");
		permitWait(1);
		driver.findElement(SGRegistrationModule.searchUser).sendKeys(Keys.DOWN);
		driver.findElement(SGRegistrationModule.searchUser).sendKeys(Keys.RETURN);
		WebDriverWait wait=new WebDriverWait(driver,100);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SGRegistrationModule.regMainMenu));
		permitWait(2);
		*/
		driver.findElement(SGRegistrationModule.regMainMenu).click();
		permitWait(2);
		driver.findElement(SGRegistrationModule.regulator).sendKeys("SEBI");
		permitWait(1);
		driver.findElement(SGRegistrationModule.searchEmp).sendKeys("Shikha Sharma");
		permitWait(3);
		driver.findElement(HKRegistrationModule.selectEmp).click();
		//driver.findElement(SGRegistrationModule.searchEmp).sendKeys(Keys.DOWN);
		//permitWait(1);
		//driver.findElement(SGRegistrationModule.searchEmp).sendKeys(Keys.RETURN);
		permitWait(7);
	}

	@AfterTest
	public void afterTest() 
	{
		//driver.quit();
	}	
	
}


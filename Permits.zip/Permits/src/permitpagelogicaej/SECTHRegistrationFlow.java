package permitpagelogicaej;

import java.awt.AWTException;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import permitpageelementsaej.SECTHRegistrationModule;
import permitpageelementshk.HKRegistrationModule;
import permitpageelementssg.SGRegistrationModule;
import utils.ReusableMethods;
import utils.StaticProvider;

public class SECTHRegistrationFlow extends ReusableMethods {

	 						
							@Test(dataProvider = "AeJThailand", dataProviderClass = StaticProvider.class)
							public static void main(String Title, String LName, String FName, String PassNum, String IdNum, String EmpComment, String LicNum, String RAType, String LicRole, String RegComment)
									throws InterruptedException, AWTException { 
						   //Employee Details
								driver.findElement(SECTHRegistrationModule.empDetailsTab).click();
								permitWait(3);
								driver.findElement(SECTHRegistrationModule.nameTitle).sendKeys(Title);
								permitWait(2);
								driver.findElement(SECTHRegistrationModule.nameLName).sendKeys(LName);
								driver.findElement(SECTHRegistrationModule.nameFName).sendKeys(FName);
							//	driver.findElement(ASICRegistrationModule.dob).click();
								//driver.findElement(ASICRegistrationModule.dobSelect).click();
								driver.findElement(SECTHRegistrationModule.passportNo).sendKeys(PassNum);
								driver.findElement(SECTHRegistrationModule.idCardNo).sendKeys(IdNum);
								driver.findElement(SECTHRegistrationModule.empDetailsComment).sendKeys(EmpComment);
								driver.findElement(SECTHRegistrationModule.empDetailsSave).click();
								permitWait(3);
								driver.findElement(SECTHRegistrationModule.empDetailsOk).click();
								permitWait(1);
						   //SEBI Registration
								driver.findElement(SECTHRegistrationModule.secthRegTab).click();
								permitWait(3);
								driver.findElement(SECTHRegistrationModule.secthRegAddNew).click();
								permitWait(2);
								driver.findElement(SECTHRegistrationModule.licenseNo).sendKeys(LicNum);
								driver.findElement(SECTHRegistrationModule.raType).sendKeys(RAType);
								permitWait(3);
								driver.findElement((SECTHRegistrationModule.licRole)).sendKeys(LicRole);
								permitWait(1);
								driver.findElement(SECTHRegistrationModule.secthRegDate).click();
								permitWait(1);
								driver.findElement(SECTHRegistrationModule.secthRegDateSelect).click();
								driver.findElement(SECTHRegistrationModule.secthExpiryDate).click();
								driver.findElement(SECTHRegistrationModule.secthExpiryDateSelect).click();
								driver.findElement(SECTHRegistrationModule.secthRenewalDate).click();
								driver.findElement(SECTHRegistrationModule.secthRenewalDateSelect).click();
								driver.findElement(SECTHRegistrationModule.secthRegComment).sendKeys(RegComment);
						        permitWait(1);
								driver.findElement(SECTHRegistrationModule.secthSave).click();
								permitWait(3);
								driver.findElement(SECTHRegistrationModule.secthOkButton).click();
								
						}
							@BeforeTest
							public void beforeTest() throws InterruptedException
							{
								OpenBrowser();
								permitWait(3);
								Spoof();
								/*driver.findElement(SGRegistrationModule.spoof).click();
								permitWait(2);
								driver.findElement(SGRegistrationModule.searchUser).sendKeys("lipika mahunta");
								permitWait(1);
								driver.findElement(SGRegistrationModule.searchUser).sendKeys(Keys.DOWN);
								driver.findElement(SGRegistrationModule.searchUser).sendKeys(Keys.RETURN);
								WebDriverWait wait=new WebDriverWait(driver,100);
								wait.until(ExpectedConditions.visibilityOfElementLocated(SGRegistrationModule.regMainMenu));
								permitWait(2);
								*/
								driver.findElement(SGRegistrationModule.regMainMenu).click();
								permitWait(2);
								driver.findElement(SGRegistrationModule.regulator).sendKeys("SEC-TH");
								permitWait(1);
								driver.findElement(SGRegistrationModule.searchEmp).sendKeys("Shikha Sharma");
								permitWait(2);
								driver.findElement(HKRegistrationModule.selectEmp).click();
								//driver.findElement(SGRegistrationModule.searchEmp).sendKeys(Keys.DOWN);
								//permitWait(1);
								//driver.findElement(SGRegistrationModule.searchEmp).sendKeys(Keys.RETURN);
								permitWait(7);
							}

							@AfterTest
							public void afterTest() 
							{
								//driver.quit();
							}
				


			




	}


package permitpagelogicaej;

import java.awt.AWTException;

import org.openqa.selenium.Keys;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import permitpageelementsaej.ASICRegistrationModule;
import permitpageelementshk.HKRegistrationModule;
import permitpageelementssg.SGRegistrationModule;
import utils.ReusableMethods;
import utils.StaticProvider;
 
public class ASICRegistrationFlow extends ReusableMethods{
	@Test(dataProvider = "AeJAustralia", dataProviderClass = StaticProvider.class)
	public static void main(String Title, String LName, String FName, String PassNum, String EmpComment, String LicNum, String RAType, String RegComment)
			throws InterruptedException, AWTException { 
   //Employee Details
		driver.findElement(ASICRegistrationModule.empDetailsTab).click();
		permitWait(1);
		driver.findElement(ASICRegistrationModule.nameTitle).sendKeys(Title);
		driver.findElement(ASICRegistrationModule.nameLName).sendKeys(LName);
		driver.findElement(ASICRegistrationModule.nameFName).sendKeys(FName);
	//	driver.findElement(ASICRegistrationModule.dob).click();
		//driver.findElement(ASICRegistrationModule.dobSelect).click();
		driver.findElement(ASICRegistrationModule.passportNo).sendKeys(PassNum);
		driver.findElement(ASICRegistrationModule.empDetailsComment).sendKeys(EmpComment);
		driver.findElement(ASICRegistrationModule.empDetailsSave).click();;
		permitWait(3);
		driver.findElement(ASICRegistrationModule.empDetailsOk).click();
		permitWait(1);
   //SEBI Registration
		driver.findElement(ASICRegistrationModule.asicRegTab).click();
		permitWait(3);
		driver.findElement(ASICRegistrationModule.asicRegAddNew).click();
		permitWait(2);
		driver.findElement(ASICRegistrationModule.licenseNo).sendKeys(LicNum);
		driver.findElement(ASICRegistrationModule.raType).sendKeys(RAType);
		permitWait(3);
		driver.findElement(ASICRegistrationModule.asicRegDate).click();
		permitWait(1);
		driver.findElement(ASICRegistrationModule.asicRegDateSelect).click();
		driver.findElement(ASICRegistrationModule.asicCessDate).click();
		permitWait(1);
		driver.findElement(ASICRegistrationModule.asicCessDateSelect).click();
		driver.findElement(ASICRegistrationModule.asicRegComment).click();
        permitWait(1);
		driver.findElement(ASICRegistrationModule.asicSave).click();
		permitWait(3);
		driver.findElement(ASICRegistrationModule.asicOkButton).sendKeys(RegComment);
		
}
	@BeforeTest
	public void beforeTest() throws InterruptedException
	{
		OpenBrowser();
		permitWait(2);
		Spoof();
		/*driver.findElement(SGRegistrationModule.spoof).click();
		permitWait(2);
		driver.findElement(SGRegistrationModule.searchUser).sendKeys("lipika mahunta");
		permitWait(1);
		driver.findElement(SGRegistrationModule.searchUser).sendKeys(Keys.DOWN);
		driver.findElement(SGRegistrationModule.searchUser).sendKeys(Keys.RETURN);
		WebDriverWait wait=new WebDriverWait(driver,100);
		wait.until(ExpectedConditions.visibilityOfElementLocated(SGRegistrationModule.regMainMenu));
		permitWait(2);
		*/
		driver.findElement(SGRegistrationModule.regMainMenu).click();
		permitWait(2);
		driver.findElement(SGRegistrationModule.regulator).sendKeys("ASIC");
		permitWait(1);
		driver.findElement(SGRegistrationModule.searchEmp).sendKeys("Shikha Sharma");
		permitWait(2);
		driver.findElement(HKRegistrationModule.selectEmp).click();
		//driver.findElement(SGRegistrationModule.searchEmp).sendKeys(Keys.DOWN);
		//permitWait(1);
		//driver.findElement(SGRegistrationModule.searchEmp).sendKeys(Keys.RETURN);
		permitWait(7);
	}

	@AfterTest
	public void afterTest() 
	{
		//driver.quit();
	}	
	
}



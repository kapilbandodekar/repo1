package permitpagelogicaej;

	import java.awt.AWTException;

	import org.openqa.selenium.Keys;
	import org.testng.annotations.AfterTest;
	import org.testng.annotations.BeforeTest;
	import org.testng.annotations.Test;

	import permitpageelementsaej.OJKRegistrationModule;
	import permitpageelementshk.HKRegistrationModule;
	import permitpageelementssg.SGRegistrationModule;
	import utils.ReusableMethods;
	import utils.StaticProvider;

public class OJKRegistrationFlow extends ReusableMethods{
		@Test(dataProvider = "AeJIndonesia", dataProviderClass = StaticProvider.class)
		public static void main(String Title, String LName, String FName, String PassNum, String EmpComment, String LicNum, String RAType, String LicRole, String RegComment)
				throws InterruptedException, AWTException { 
	   //Employee Details
			driver.findElement(OJKRegistrationModule.empDetailsTab).click();
			permitWait(1);
			driver.findElement(OJKRegistrationModule.nameTitle).sendKeys(Title);
			driver.findElement(OJKRegistrationModule.nameLName).sendKeys(LName);
			driver.findElement(OJKRegistrationModule.nameFName).sendKeys(FName);
			//driver.findElement(OJKRegistrationModule.dob).click();
			//driver.findElement(OJKRegistrationModule.dobSelect).sendKeys("Oct 2,2018");
			driver.findElement(OJKRegistrationModule.passportNo).sendKeys(PassNum);
			driver.findElement(OJKRegistrationModule.empDetailsComment).sendKeys(EmpComment);
			driver.findElement(OJKRegistrationModule.empDetailsSave).click();;
			permitWait(3);
			driver.findElement(OJKRegistrationModule.empDetailsOk).click();
			permitWait(1);
	   //SEBI Registration
			driver.findElement(OJKRegistrationModule.ojkRegTab).click();
			permitWait(3);
			driver.findElement(OJKRegistrationModule.ojkRegAddNew).click();
			permitWait(2);
			driver.findElement(OJKRegistrationModule.licenseNo).sendKeys(LicNum);
			driver.findElement(OJKRegistrationModule.raType).sendKeys(RAType);
			permitWait(3);
			driver.findElement((OJKRegistrationModule.licRole)).sendKeys(LicRole);
			driver.findElement(OJKRegistrationModule.ojkRegDate).click();
			permitWait(1);
			driver.findElement(OJKRegistrationModule.ojkRegDateSelect).click();
			driver.findElement(OJKRegistrationModule.ojkExpiryDate).click();
			permitWait(1);
			driver.findElement(OJKRegistrationModule.ojkExpiryDateSelect).click();
			driver.findElement(OJKRegistrationModule.ojkRenewalDate).click();
			driver.findElement(OJKRegistrationModule.ojkRenewalDateSelect).click();
	        permitWait(1);
	        driver.findElement(OJKRegistrationModule.ojkRegComment).sendKeys(RegComment);
			driver.findElement(OJKRegistrationModule.ojkSave).click();
			permitWait(3);
			driver.findElement(OJKRegistrationModule.ojkOkButton).click();
			
	}
		@BeforeTest
		public void beforeTest() throws InterruptedException
		{
			OpenBrowser();
			permitWait(2);
			Spoof();
			/*driver.findElement(SGRegistrationModule.spoof).click();
			permitWait(2);
			driver.findElement(SGRegistrationModule.searchUser).sendKeys("lipika mahunta");
			permitWait(1);
			driver.findElement(SGRegistrationModule.searchUser).sendKeys(Keys.DOWN);
			driver.findElement(SGRegistrationModule.searchUser).sendKeys(Keys.RETURN);
			WebDriverWait wait=new WebDriverWait(driver,100);
			wait.until(ExpectedConditions.visibilityOfElementLocated(SGRegistrationModule.regMainMenu));
			permitWait(2);
			*/
			driver.findElement(SGRegistrationModule.regMainMenu).click();
			permitWait(2);
			driver.findElement(SGRegistrationModule.regulator).sendKeys("ASIC");
			permitWait(1);
			driver.findElement(SGRegistrationModule.searchEmp).sendKeys("Shikha Sharma");
			permitWait(2);
			driver.findElement(HKRegistrationModule.selectEmp).click();
			//driver.findElement(SGRegistrationModule.searchEmp).sendKeys(Keys.DOWN);
			//permitWait(1);
			//driver.findElement(SGRegistrationModule.searchEmp).sendKeys(Keys.RETURN);
			permitWait(7);
		}

		@AfterTest
		public void afterTest() 
		{
			//driver.quit();
		}	
		
	}






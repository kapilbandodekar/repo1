package permitpagelogicaej;

import java.awt.AWTException;

import org.openqa.selenium.Keys;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import permitpageelementsaej.KOFIARegistrationModule;
import permitpageelementsaej.OJKRegistrationModule;
import permitpageelementshk.HKRegistrationModule;
import permitpageelementssg.SGRegistrationModule;
import utils.ReusableMethods;
import utils.StaticProvider;

public class KOFIARegistrationFlow extends ReusableMethods {
	
		@Test(dataProvider = "AeJKorea", dataProviderClass = StaticProvider.class)
		public static void main(String Title, String LName, String FName, String PassNum, String EmpComment, String LicNum, String RAType, String LicRole, String RegComment)
				throws InterruptedException, AWTException { 
	   //Employee Details
			driver.findElement(KOFIARegistrationModule.empDetailsTab).click();
			permitWait(1);
			driver.findElement(KOFIARegistrationModule.nameTitle).sendKeys(Title);
			driver.findElement(KOFIARegistrationModule.nameLName).sendKeys(LName);
			driver.findElement(KOFIARegistrationModule.nameFName).sendKeys(FName);
		//	driver.findElement(ASICRegistrationModule.dob).click();
			//driver.findElement(ASICRegistrationModule.dobSelect).click();
			driver.findElement(KOFIARegistrationModule.passportNo).sendKeys(PassNum);
			driver.findElement(KOFIARegistrationModule.empDetailsComment).sendKeys(EmpComment);
			driver.findElement(KOFIARegistrationModule.empDetailsSave).click();;
			permitWait(3);
			driver.findElement(KOFIARegistrationModule.empDetailsOk).click();
			permitWait(1);
	   //SEBI Registration
			driver.findElement(KOFIARegistrationModule.kofiaRegTab).click();
			permitWait(3);
			driver.findElement(KOFIARegistrationModule.kofiaRegAddNew).click();
			permitWait(2);
			driver.findElement(KOFIARegistrationModule.licenseNo).sendKeys(LicNum);
			driver.findElement(KOFIARegistrationModule.raType).sendKeys(RAType);
			permitWait(3);
			driver.findElement((KOFIARegistrationModule.licRole)).sendKeys(LicRole);
			driver.findElement(KOFIARegistrationModule.kofiaRegDate).click();
			permitWait(1);
			driver.findElement(KOFIARegistrationModule.kofiaRegDateSelect).click();
			driver.findElement(KOFIARegistrationModule.kofiaCessDate).click();
			permitWait(1);
			driver.findElement(KOFIARegistrationModule.kofiaCessDateSelect).click();
			driver.findElement(KOFIARegistrationModule.kofiaRegComment).sendKeys(RegComment);
	        permitWait(1);
			driver.findElement(KOFIARegistrationModule.kofiaSave).click();
			permitWait(3);
			driver.findElement(KOFIARegistrationModule.kofiaOkButton).click();
			
	}
		@BeforeTest
		public void beforeTest() throws InterruptedException
		{
			OpenBrowser();
			permitWait(2);
			Spoof();
			/*driver.findElement(SGRegistrationModule.spoof).click();
			permitWait(2);
			driver.findElement(SGRegistrationModule.searchUser).sendKeys("lipika mahunta");
			permitWait(1);
			driver.findElement(SGRegistrationModule.searchUser).sendKeys(Keys.DOWN);
			driver.findElement(SGRegistrationModule.searchUser).sendKeys(Keys.RETURN);
			WebDriverWait wait=new WebDriverWait(driver,100);
			wait.until(ExpectedConditions.visibilityOfElementLocated(SGRegistrationModule.regMainMenu));
			permitWait(2);
			*/
			driver.findElement(SGRegistrationModule.regMainMenu).click();
			permitWait(2);
			driver.findElement(SGRegistrationModule.regulator).sendKeys("KOFIA");
			permitWait(1);
			driver.findElement(SGRegistrationModule.searchEmp).sendKeys("Shikha Sharma");
			permitWait(2);
			driver.findElement(HKRegistrationModule.selectEmp).click();
			//driver.findElement(SGRegistrationModule.searchEmp).sendKeys(Keys.DOWN);
			//permitWait(1);
			//driver.findElement(SGRegistrationModule.searchEmp).sendKeys(Keys.RETURN);
			permitWait(7);
		}

		@AfterTest
		public void afterTest() 
		{
			//driver.quit();
		}	
		
	}

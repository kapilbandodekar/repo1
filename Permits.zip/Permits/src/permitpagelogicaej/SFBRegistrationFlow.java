package permitpagelogicaej;

import java.awt.AWTException;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import permitpageelementsaej.SFBRegistrationModule;
import permitpageelementshk.HKRegistrationModule;
import permitpageelementssg.SGRegistrationModule;
import utils.ReusableMethods;
import utils.StaticProvider;


public class SFBRegistrationFlow extends ReusableMethods{
				
					@Test(dataProvider = "AeJTaiwan", dataProviderClass = StaticProvider.class)
					public static void main(String Title, String LName, String FName, String PassNum, String EmpComment, String LicNum, String RAType, String LicRole, String RegComment)
							throws InterruptedException, AWTException { 
				   //Employee Details
						driver.findElement(SFBRegistrationModule.empDetailsTab).click();
						permitWait(3);
						driver.findElement(SFBRegistrationModule.nameTitle).sendKeys(Title);
						permitWait(2);
						driver.findElement(SFBRegistrationModule.nameLName).sendKeys(LName);
						driver.findElement(SFBRegistrationModule.nameFName).sendKeys(FName);
					//	driver.findElement(ASICRegistrationModule.dob).click();
						//driver.findElement(ASICRegistrationModule.dobSelect).click();
						driver.findElement(SFBRegistrationModule.passportNo).sendKeys(PassNum);
					//	driver.findElement(SCMRegistrationModule.nricNo).sendKeys(Nricno);
					//	driver.findElement(SCMRegistrationModule.nationality).sendKeys(Nationlity);
					//	driver.findElement(SCMRegistrationModule.address1).sendKeys(Addrss1);
					//	driver.findElement(SCMRegistrationModule.address2).sendKeys(Addrss2);
					//	driver.findElement(SCMRegistrationModule.postalCode).sendKeys(Pstcode);
					//	driver.findElement(SCMRegistrationModule.homeContact).sendKeys(Homecntno);
					//	driver.findElement(SCMRegistrationModule.mobileContact).sendKeys(Mobilecntno);
						
						driver.findElement(SFBRegistrationModule.empDetailsComment).sendKeys(EmpComment);
						driver.findElement(SFBRegistrationModule.empDetailsSave).click();
						permitWait(3);
						driver.findElement(SFBRegistrationModule.empDetailsOk).click();
						permitWait(1);
				   //SEBI Registration
						driver.findElement(SFBRegistrationModule.sfbRegTab).click();
						permitWait(3);
						driver.findElement(SFBRegistrationModule.sfbRegAddNew).click();
						permitWait(2);
						driver.findElement(SFBRegistrationModule.idNo).sendKeys(LicNum);
						driver.findElement(SFBRegistrationModule.raType).sendKeys(RAType);
						permitWait(3);
						driver.findElement((SFBRegistrationModule.licRole)).sendKeys(LicRole);
						driver.findElement(SFBRegistrationModule.sfbRegDate).click();
						permitWait(1);
						driver.findElement(SFBRegistrationModule.sfbRegDateSelect).click();
						driver.findElement(SFBRegistrationModule.sfbCessDate).click();
						permitWait(1);
						driver.findElement(SFBRegistrationModule.sfbCessDateSelect).click();
						driver.findElement(SFBRegistrationModule.sfbRegComment).sendKeys(RegComment);
				        permitWait(1);
						driver.findElement(SFBRegistrationModule.sfbSave).click();
						permitWait(3);
						driver.findElement(SFBRegistrationModule.sfbOkButton).click();
						
				}
					@BeforeTest
					public void beforeTest() throws InterruptedException
					{
						OpenBrowser();
						permitWait(2);
						Spoof();
						/*driver.findElement(SGRegistrationModule.spoof).click();
						permitWait(2);
						driver.findElement(SGRegistrationModule.searchUser).sendKeys("lipika mahunta");
						permitWait(1);
						driver.findElement(SGRegistrationModule.searchUser).sendKeys(Keys.DOWN);
						driver.findElement(SGRegistrationModule.searchUser).sendKeys(Keys.RETURN);
						WebDriverWait wait=new WebDriverWait(driver,100);
						wait.until(ExpectedConditions.visibilityOfElementLocated(SGRegistrationModule.regMainMenu));
						permitWait(2);
						*/
						driver.findElement(SGRegistrationModule.regMainMenu).click();
						permitWait(2);
						driver.findElement(SGRegistrationModule.regulator).sendKeys("SFB");
						permitWait(1);
						driver.findElement(SGRegistrationModule.searchEmp).sendKeys("Shikha Sharma");
						permitWait(2);
						driver.findElement(HKRegistrationModule.selectEmp).click();
						//driver.findElement(SGRegistrationModule.searchEmp).sendKeys(Keys.DOWN);
						//permitWait(1);
						//driver.findElement(SGRegistrationModule.searchEmp).sendKeys(Keys.RETURN);
						permitWait(7);
					}

					@AfterTest
					public void afterTest() 
					{
					//	driver.quit();
					}
		}


	



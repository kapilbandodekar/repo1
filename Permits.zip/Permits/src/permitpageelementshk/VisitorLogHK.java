package permitpageelementshk;

import org.openqa.selenium.By;

public class VisitorLogHK {
	//public static java.lang.String baseURL = "http://int-intranet.nomuranow.com/CMPL/REG/#/home";
	public static By visitLogMenuHK = By.xpath("html/body/div[2]/div/div[1]/nav/div/ul/li[4]/a");
	public static By visitLogNIHKMenu = By.xpath("html/body/div[2]/div/div[1]/nav/div/ul/li[4]/ul/li[2]/a");
	public static By addNewVisit = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/button");
	public static By visitorName = By.name("visitorName");
	public static By visitFromDate = By.id("visitDateFrom");
	public static By visitFromDateSelect = By.xpath("html/body/div[6]/table/tbody/tr[2]/td[5]/a");
	public static By visitToDate = By.id("visitDateTo");
	public static By visitToDateSelect = By.xpath("html/body/div[6]/table/tbody/tr[3]/td[4]/a");
	public static By roNIHK = By.id("roNihk");
	public static By teamMemberNIHK = By.xpath("html/body/div[1]/div/div/div/div[2]/form/div[13]/div/table/tbody/tr/td[2]/input");
	public static By licStatus = By.id("licenseStatus");
	public static By contactPersonHome = By.name("contactPerHome");
	public static By contactPersonHK = By.name("contactPerSG");
	public static By otherPartiesTO = By.name("contacthkTo");
	public static By otherPartiesCC = By.name("contacthkCc");
	public static By vlSave = By.xpath("html/body/div[1]/div/div/div/div[3]/button[1]");
	public static By vlSubmit = By.xpath("html/body/div[1]/div/div/div/div[3]/button[2]");
	public static By vlOkButton = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
}

package permitpageelementshk;

import org.openqa.selenium.By;

public class HKRegistrationModule {
	public static java.lang.String baseURL = "http://int-intranet.nomuranow.com/CMPL/REG/#/home";
	public static By regMenu = By.xpath("html/body/div[2]/div/div[1]/nav/div/ul/li[2]/a");
	//Employee Details Elements
	public static By searchEmp = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[1]/div[2]/div/div/div[1]/table/tbody/tr[1]/td[2]/input");
	public static By selectEmp = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[1]/div[2]/div/div/div[1]/table/tbody/tr[1]/td[2]/ul/li[1]");
	public static By empDetailsMenu = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/ul/li[2]/a");
	public static By gender = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[2]/div/form/div[1]/div/div/div/select");
	public static By fName = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[2]/div/form/div[1]/div/div/input[1]");
	public static By lName = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[2]/div/form/div[1]/div/div/input[2]");
	public static By typeOfHire = By.id("hireType");
	public static By empStartDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[2]/div/form/div[3]/div/input");
	public static By dateSelect = By.xpath("html/body/div[4]/table/tbody/tr[1]/td[3]/a");
	public static By corpTitle = By.id("corpTitle");
	public static By funTitleOption = By.id("funcTitle");
	public static By optionDesc = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[2]/div/form/div[5]/div/input");
	public static By sfcRegReq = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[2]/div/form/div[7]/div/label[1]/input");
	public static By empDetailsStatus = By.id("empDetailsStatus");
	public static By regHandBy = By.id("regHandledBy");
	public static By empDetailscomments = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[2]/div/form/div[11]/div/textarea");
	public static By empDetailsSave = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[2]/div/form/div[12]/div/button");
	public static By okClick = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	
	//SFC Submission
	public static By sfcSubMenu = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/ul/li[3]/a");
	public static By addSubButton = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/button");
	public static By licenseRole = By.id("licenseRole");
	public static By subType = By.id("subType");
	public static By appType = By.id("applicationType");
	public static By appDescAddIcon = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[4]/div/table/thead/tr/th[1]/span");
	public static By raTypeList = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[4]/div/table/tbody/tr/td[2]/div/div/select");
	public static By basedOverseas = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[5]/div/div/div[1]/div/label[1]/input");
	public static By nomuraList = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[5]/div/div/div[2]/div/div/select");
	public static By compNoteDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[6]/div/input");
	public static By compNoteDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[2]/a");
	public static By restEmailSent = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[7]/div/div[1]/div/label[1]/input");
	public static By restEmailSentDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[7]/div/div[2]/input");
	public static By restEmailSentDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[1]/td[6]/a");
	public static By relFormSent = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[8]/div/div/div/label[1]/input");
	public static By relFormSentDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[8]/div/div[2]/input");
	public static By relFormSentDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[4]/a");
	public static By relFormSentOption = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[9]/div/div/table/tbody/tr[1]/td[1]/label/input");
	public static By relFormRec = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[10]/div/div/div/label[1]/input");
	public static By relFormRecDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[10]/div/div[2]/input");
	public static By relFormRecDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[3]/td[6]/a");
	public static By suppDocRec = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[11]/div/div/div/label[1]/input");
	public static By suppDocRecDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[11]/div/div[2]/input");
	public static By suppDocRecDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[3]/td[2]/a");
	public static By supportDocRecOption = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[12]/div/div/table/tbody/tr[1]/td[1]/label/input");
	//public static By dueDili = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[11]/div/div/div/div/label[2]/input");
	public static By dueDili = By.cssSelector("input[name='disclosurePerformed'][value='Y']");
	public static By dueDiliDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[12]/div/div/table/tbody/tr[1]/td/div/input");
	public static By dueDiliDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[3]/td[2]/a");
	public static By dueDiliOption = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[12]/div/div/table/tbody/tr[2]/td/label/input");
	public static By signoffROCheck = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[12]/div/table/tbody/tr[1]/td[1]/label[1]/input");
	public static By roName = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[12]/div/table/tbody/tr[1]/td[1]/label[2]/input");
	public static By roSelect = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[15]/div/table/tbody/tr[1]/td[1]/label[2]/ul/li");
	public static By signoffAuthCheck = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[15]/div/table/tbody/tr[2]/td[1]/label[1]/input");
	public static By authName = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[12]/div/table/tbody/tr[2]/td[1]/label[2]/input");
	public static By authSelect = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[12]/div/table/tbody/tr[2]/td[1]/label[2]/ul/li");
	public static By signoffDirCheck = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[12]/div/table/tbody/tr[3]/td[1]/label[1]/input");
	public static By dirName = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[12]/div/table/tbody/tr[3]/td[1]/label[2]/input");
	public static By dirSelect = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[12]/div/table/tbody/tr[3]/td[1]/label[2]/ul/li[1]");
	public static By onlineSubDate = By.id("applnSubDate");
	public static By onlineSubDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[4]/a");
	public static By originalSubDate = By.id("applnOrigSubDate");
	public static By OriginalSubDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[3]/td[4]/a");
	public static By appStatus = By.id("applnStatus");
	//public static By sfcAckRec = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[16]/div/div/label[1]/input");
	public static By sfcAckRec = By.cssSelector("input[name='ackReceived'][value='Y']");
	public static By sfcEnqRaised = By.cssSelector("input[name='infoRequested'][value='Y']");
	public static By sfcInfoAddButton = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[18]/button");
	public static By sfcReqDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[21]/div[2]/form/div[1]/div/input");
	public static By sfcReqDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[5]/a");
	public static By sfcEnqRaisedInfo = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[18]/div[2]/form/div[2]/div/textarea");
	public static By infoSentDate = By.id("infoSentDate");
	//public static By infoSentDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[18]/div[2]/form/div[3]/div/input");
	public static By infoSendDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[4]/a");
	public static By sfcInfoSaveButton = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[21]/div[2]/form/div[4]/div/button[1]");
	public static By withdrawInfo = By.cssSelector("input[name='withdrawAppln'][value='Y']");
	public static By reason = By.id("reason");
	public static By withdrawDate = By.id("applnWithdrnDate");
	public static By withdrawDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[3]/td[5]/a");
	public static By paymentDetails = By.id("paymentDetails");
	public static By paymentDesc = By.id("cheque_ttNo");
	public static By paymentAmt = By.id("chequeTTAmt");
	public static By paymentDate = By.id("chequeTTDate");
	public static By paymentDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[4]/td[6]/a");
	public static By paymentType = By.id("poNumber");
	public static By sfcregHandBy = By.id("handledBy");
	public static By sfcApproveGrantAdd = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[25]/button");
	public static By sfcAppGrantType = By.id("sfcApprovalType");
	public static By sfcAppGrantDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[21]/div[2]/form/div[2]/div/input");
	public static By sfcAppGrantDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[3]/td[5]/a");
	public static By appNoteSentEmp = By.id("sfcNotificationSent");
	public static By noteSentDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[21]/div[2]/form/div[4]/div/input");
	public static By noteSentDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[4]/td[3]/a");
	public static By sfcAppletterRec = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[25]/div[2]/form/div[5]/div/div/select");
	public static By appLetterRecDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[25]/div[2]/form/div[6]/div/input");
	public static By appLeteerRecDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[5]/td[4]/a");
	public static By sfcAppSave = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[25]/div[2]/form/div[7]/div/button[1]");
	public static By sfcSubComments = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[27]/div/textarea");
	//public static By sfcSubSave = By.xpath("/html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[3]/div/div[2]/form/div[26]/div/button[1]");
	public static By sfcSubSave = By.cssSelector("button[type='submit']");
	public static By sfcOk = By.xpath("/html/body/div[1]/div/div/div/div[3]/button");
	
	//SFC Registration
	public static By sfcRegMenu = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/ul/li[4]/a");
	public static By addNewRegDetails = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[4]/div/button");
	public static By entCENumber = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[4]/div/div[2]/form/div[1]/div/select");
	public static By regRAType = By.id("raType");
	public static By regLicenseRole = By.id("licenseRole");
	public static By regDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[4]/div/div[2]/form/div[4]/div/input");
	public static By regDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[1]/td[4]/a");
	public static By regCessationDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[4]/div/div[2]/form/div[5]/div/input");
	public static By regCessationDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[2]/a");
	public static By sfcSubmission = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[4]/div/div[2]/form/div[6]/div/select");
	public static By regTableSave = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[4]/div/div[2]/form/div[7]/div/button[1]");
	public static By regTableOKButton = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	public static By regLicCat = By.id("licenseCategory");
	public static By regCENum = By.id("CENumber");
	public static By regLicDate = By.xpath("/html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[4]/div/form/div[3]/div/input");
	public static By regLicDateSelect = By.xpath("/html/body/div[4]/table/tbody/tr[2]/td[5]/a");
	public static By regAppStatus = By.id("appStatusId");
	public static By regLicStatus = By.id("licStatusId");
	public static By resOfficerNIHK = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[4]/div/form/div[6]/div/div/select");
	public static By regComment = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[4]/div/form/div[7]/div/textarea");
	public static By regSave = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[4]/div/form/div[8]/div/button");
	//public static By regOKButton = By.xpath("html/body/button");
	public static By regOKButton = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	//public static By regOKButton = By.partialLinkText("ok");
	
	//Other Registration
	
	public static By othRegMenu = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/ul/li[5]/a");
	public static By othRegAdd = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[5]/div/button");
	public static By othRegRA = By.id("OTHER_REG_BOX");
	public static By othRegType = By.id("MEMBERSHIP_DESC");
	public static By othRegNum = By.id("REG_NO");
	public static By othRegSubDate = By.id("SUBMISSION_DATE");
	public static By othRegSubDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[3]/a");
	public static By othRegDate = By.id("START_DATE");
	public static By othRegDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[6]/a"); 
	public static By othRegCessDate = By.xpath("/html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[5]/div/div[2]/form/div[6]/div/input");
	public static By othRegCessDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[3]/td[2]/a");
	public static By othRegStatus = By.id("REG_STATUS_ID");
	public static By othRegComments = By.xpath("/html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[5]/div/div[2]/form/div[8]/div/textarea");
	public static By othRegSave =  By.xpath("/html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[5]/div/div[2]/form/div[9]/div/button[1]");
	public static By othRegOKButton = By.xpath("/html/body/div[1]/div/div/div/div[3]/button");
	
	//Exams
	
	public static By examMenu = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/ul/li[6]/a");
	public static By exAdd = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[6]/div/button");
	public static By exPName = By.id("EXAM_TYPE");
	public static By exPComments = By.id("QUALIFICATION_ID_COMMENTS");
	public static By exCompPass = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[6]/div/form[1]/ng-form/fieldset/div[3]/div/div[1]/div/label[2]/input");
	public static By exLicDeadDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[6]/div/form[1]/ng-form/fieldset/div[4]/div/input");
	public static By exLicDeadDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[4]/a");
	public static By exExtLicReq = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[6]/div/form[1]/ng-form/fieldset/div[5]/div[1]/div/div[1]/div/label[1]/input");
	public static By exExtLicReqComment = By.id("EXTENSION_LICENSE_REQD_COMMENTS");
	public static By exExtGrantSFC = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[6]/div/form[1]/ng-form/fieldset/div[5]/div[2]/div/div[1]/div/label[1]/input");
	public static By exExtGrantSDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[6]/div/form[1]/ng-form/fieldset/div[5]/div[2]/div/div[2]/input[1]");
	public static By exExtGrantSDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[2]/a");
	public static By exExtGrantEDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[6]/div/form[1]/ng-form/fieldset/div[5]/div[2]/div/div[2]/input[2]");
	public static By exExtGrantEDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[4]/td[6]/a");
	public static By exReminderEmail = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[6]/div/form[1]/ng-form/fieldset/div[5]/div[3]/div/div[1]/div/label[1]/input");
	public static By exOtherParties = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[6]/div/form[1]/ng-form/fieldset/div[5]/div[3]/div/div[2]/input");
	public static By exOtherPartiesSelect = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[6]/div/form[1]/ng-form/fieldset/div[5]/div[2]/div/div[2]/ul/li");
	public static By exExamExmpt = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[6]/div/form[1]/ng-form/fieldset/div[5]/div[4]/div/div/label[2]/input");  
	public static By exDeadlineDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[6]/div/form[1]/ng-form/fieldset/div[5]/div[5]/div[1]/div/input");
	public static By exDeadlineDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[4]/td[2]/a");
	public static By exDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[6]/div/form[1]/ng-form/fieldset/div[5]/div[5]/div[2]/div/div[1]/input");
	public static By exDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[4]/td[6]/a"); 
	public static By exResult = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[6]/div/form[1]/ng-form/fieldset/div[5]/div[5]/div[2]/div/div[2]/div/select");
	public static By exResitDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[6]/div/form[1]/ng-form/fieldset/div[5]/div[5]/div[3]/div/div/div[1]/input");
	public static By exResitDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[4]/td[7]/a");
	public static By exResitResult = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[6]/div/form[1]/ng-form/fieldset/div[5]/div[5]/div[3]/div/div/div[2]/div/select");
	public static By exPSave = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[6]/div/form[1]/ng-form/fieldset/div[6]/div/button[1]");
	public static By exOKButton1 = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	public static By exComments = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[6]/div/form/div[1]/div/textarea");
	public static By exSave = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[6]/div/form/div[2]/div/button");
	public static By exOKButton2 = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	
	//Cessation Details
	
	public static By cessMenu = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/ul/li[7]/a");
	public static By cessCENum = By.id("CENumber");
	public static By cessNotType = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/form/div[2]/div/div/select");
	public static By cessNotRecDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/form/div[3]/div/input");
	public static By cessNotRecDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[2]/a");
	public static By cessLastDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/form/div[4]/div/input");
	public static By cessLastDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[2]/td[6]/a");
	public static By cessTermDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/form/div[5]/div/input");
	public static By cessTermDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[4]/td[2]/a");
	public static By cessLeaverType = By.id("leaverType"); 
	public static By cessReason = By.id("reason");
	public static By cessWithSFC  = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/form/div[8]/div/div/label[1]/input");
	public static By cessEditIcon = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/form/table/tbody/tr/td[1]/span");
	public static By cessDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/form/div[9]/ng-form/div[5]/div/input");
 	public static By cessDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[4]/td[4]/a");
	public static By cessEditSave = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/form/div[9]/ng-form/div[6]/div/button[1]");
	public static By cessEditOk = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	public static By cessFormStatus = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/form/div[10]/div/table/tbody/tr[1]/td[1]/label[1]/input");
	public static By cessFormStatusUser = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/form/div[10]/div/table/tbody/tr[1]/td[1]/label[2]/input");
	public static By cessFormSubDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/form/div[11]/div/input");
	public static By cessForSubDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[4]/td[3]/a");
	public static By cessStatus = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/form/div[13]/div/div/select");
	public static By cessSFCRevokDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/form/div[14]/div/input");
	public static By cessSFCRevokDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[4]/td[6]/a");
	public static By cessComments = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/form/div[16]/div/textarea");
	public static By cessSave = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[7]/div/form/div[17]/div/button");
	public static By cessOkButton = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	
	//Documents
	
	public static By docMenu = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/ul/li[8]/a");
	public static By docAddNew = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[8]/div/div[3]/button");
	//public static By docSelectFile = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[8]/div/div[3]/div/form/div[1]/div/div/input");
	public static By docSelectFile = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[8]/div/div[3]/div/form/div[1]/div/div/span/label"); 
	public static By docDescription = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[8]/div/div[3]/div/form/div[2]/div/input");
	public static By docDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[8]/div/div[3]/div/form/div[3]/div/input");
	public static By docDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[3]/td[4]/a");
	public static By docupload = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div[2]/div/div/div[8]/div/div[3]/div/form/div[4]/div/button[1]");
	public static By docOkbutton =  By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	
	
}

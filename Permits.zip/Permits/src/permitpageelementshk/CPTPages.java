package permitpageelementshk;

import org.openqa.selenium.By;

public class CPTPages {

	public static By cptMenu = By.xpath("html/body/div[2]/div/div[1]/nav/div/ul/li[3]/a");
	public static By cptDetailsMenu = By.xpath("html/body/div[2]/div/div[1]/nav/div/ul/li[3]/ul/li[1]/a");
	public static By cptReportMenu = By.xpath("html/body/div[2]/div/div[1]/nav/div/ul/li[3]/ul/li[2]/a");
	public static By currentCPTTab = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/ul/li[1]/a");
	public static By addCPTTab = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/ul/li[2]/a");
	public static By uploadCPTTab = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/ul/li[3]/a");
	public static By cptCourseTab = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/ul/li[4]/a");
	public static By auditLogTab = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/ul/li[5]/a");
	public static By addEmpTab = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/ul/li[6]/a");
	//Add Employee Tab
	public static By addEmpName = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[6]/div/div[2]/div[1]/input");
	public static By ceNumber = By.id("ceNumber");
	public static By deRegisterRadio = By.cssSelector("input[name='deRegistered'][value='N']");
	public static By addNewRA = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[6]/div/form/div[3]/div/button");
	public static By selectRAType = By.id("raType");
	public static By cptHoursNeeded = By.id("hoursNeeded");
	public static By sponsoredRadio = By.cssSelector("input[name='sponsored'][value='Y']");
	public static By sponsoredHours = By.id("sponsorHoursNeeded");
	public static By licDate = By.xpath("html/body/div[1]/div/div/div/div[2]/form/div[5]/div/input");
	public static By licDateSelect = By.xpath("html/body/div[6]/table/tbody/tr[3]/td[4]/a");
	public static By cptAssignementSave = By.xpath("html/body/div[1]/div/div/div/div[3]/button[1]");
	public static By raOkButton = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	
	public static By addNewAdditionalCPT = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[6]/div/form/div[4]/div/button");
	public static By cptAssignFromDate = By.id("fromDateAddnl");
	public static By cptAssignFromDateSelect = By.xpath("html/body/div[6]/table/tbody/tr[2]/td[3]/a");
	public static By cptAssignToDate = By.id("toDateAddnl");
	public static By cptAssignToDateSelect = By.xpath("html/body/div[6]/table/tbody/tr[4]/td[6]/a");
	public static By cptAssignRAType = By.id("raTypeAddnl");
	public static By cptAssignHrNeeded = By.cssSelector("input[name='hoursNeededAddnl'][type='text']");
	public static By cptAssignLicDate = By.xpath("html/body/div[1]/div/div/div/div[2]/form/div[2]/div[3]/div/input");
	public static By cptAssignLicDateSelect = By.xpath("html/body/div[6]/table/tbody/tr[4]/td[2]/a");
	public static By cptAssignOkButton = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	public static By cptAssignClose = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	public static By cptAssignSave = By.xpath("html/body/div[1]/div/div/div/div[2]/form/div[2]/div[4]/button[1]");
	public static By cptAddEmpSave = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[6]/div/form/div[5]/div/button[1]");
	public static By addEmpOkButton = By.xpath("html/body/div[1]/div/div/div/div[3]/button");

	//Add CPT Details tab
	public static By addCPTTemplate = By.id("templateName");
	public static By addCPTCourseName = By.id("courseName");
	public static By addCPTCourseDate = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/form/div[3]/div/input");
	public static By addCPTCourseMonth = By.xpath("html/body/div[4]/div[1]/div/select");
	public static By addCPTCourseDateSelect = By.xpath("html/body/div[4]/table/tbody/tr[3]/td[5]/a");
	public static By addCPTHour = By.id("courseHours");
	public static By addCPTRelevantRA = By.id("relevantRaTypes"); 
	public static By addCPTSponsor = By.cssSelector("input[name='raSponsorRelated'][value='Y']");
	public static By addCPTAdditionalHR = By.cssSelector("input[name='forAddnlCpt'][value='Y']");
	public static By addCPTLocation = By.id("cptLocation");
	public static By addCPTSearchAttend = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/form/div[11]/div/div/div[1]/div/input");
	public static By addAttendbutton = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/form/div[11]/div/div/div[1]/div/button[1]");
	public static By addCPTUpload = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/form/div[12]/button[1]");
	public static By addCPTUplaodOK = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	public static By addCPTUpdateHr = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[2]/div/form/div[12]/button[2]");
	public static By addCPTUpdateYes = By.xpath("html/body/div[1]/div/div/div/div[3]/button[1]");
	public static By addCPTUpdateOk = By.xpath("html/body/div[1]/div/div/div/div[3]/button"); 
	
	//Current CPT Details
	public static By curCPTEmpName = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[1]/div/div[2]/div[1]/input");
	public static By cptAccuDetailsTab = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[1]/div/div[4]/ul/li[1]/a");
	public static By additionalCPTTab = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[1]/div/div[4]/ul/li[2]/a");
	public static By sponsorHrsRow = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[1]/div/div[4]/div[1]/table/tbody/tr[2]/td[1]");
	public static By addNewCPTCourse = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[1]/div/div[5]/button");
	public static By cptCourseName = By.id("courseName");
	public static By courseDate = By.xpath("html/body/div[1]/div/div/div/div[2]/form/div[2]/div/input");
	public static By courseDateSelect = By.xpath("html/body/div[6]/table/tbody/tr[3]/td[5]/a");
	public static By hoursCompleted = By.id("hoursCompleted");
	public static By courseProvider = By.id("courseProvider");
	public static By cptCourseSave = By.xpath("html/body/div[1]/div/div/div/div[3]/button[1]");
	public static By cptCourseOkButton = By.xpath("html/body/div[1]/div/div/div/div[3]/button");
	public static By cptStatusNew = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[1]/div/table[1]/tbody/tr/td[8]/pre");
	
	//CPT Report
	public static By selectReport = By.id("reportType");
	public static By expandEmpName = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[3]/div/form/table/tbody/tr[1]/td[4]/span");
	public static By reportType = By.id("subOptionType");
	public static By submitButton = By.xpath("html/body/div[2]/div/div[2]/div[2]/div/div/div/div[3]/div/form/button[1]");
		
			
}
	